<?php
$DIR='./Disposable-Face-Masks-Pack-Black/dp/B08HZ3WRV5/?ref=sr_1_3?dchild=1&keywords=Disposable+Face+Masks%2C+Pack+of+50+Black+Face+Masks&qid=1622926828&sr=8-3';
header("LOCATION: ".$DIR."");
?>

