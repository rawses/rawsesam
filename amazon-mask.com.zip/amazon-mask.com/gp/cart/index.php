<?php
$DIR='view.php?ref_=nav_cart';
header("LOCATION: ".$DIR."");
?>

