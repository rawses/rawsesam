<?php

/* ONline
$hostDB = "45.87.80.103";
$dbname = "u311868038_Mohammed";
$usernameDB = "u311868038_zainidd";
$passwordDB = "Zain1999";	
*/

/* Offline */
$hostDB = "localhost";
$dbname = "Amazon";
$usernameDB = "root";
$passwordDB = "Zain1999";

$database = new PDO("mysql:host=$hostDB; dbname=$dbname;",$usernameDB,$passwordDB);
?>